# MyDesignRule - THE SUPERMOUSE UI & HEADER DESIGN STANDARDS

MANDATORY DESIGN RULES TO FOLLOW ACROSS ALL WINDOWS AND SUBMENUS:

1. **Header Icons Right-Aligned (Left of Cross):**
   - Action icons (Back Arrow, Home Icon, Tool Buttons, Badges) MUST NEVER be placed on the left of the header.
   - They MUST ALWAYS be positioned on the right side, directly to the left of the Cross (Close) button.
   - The Cross (Close) button is ALWAYS the final element at the far right.

2. **Logo & Brand Title on Far Left:**
   - The App Logo and Brand Title (e.g., 'THE' in White + Component Name in #FFFF00 -> #00FF85 gradient) MUST ALWAYS be positioned on the far left of the header.
   - Exact unified typography: Font 'Segoe UI Variable', Style 'Display Bold', Size 11.4pt, Letter Spacing 0.35px.

3. **Dynamic Search Box Standards (Device Hub Bar Style):**
   - Search box MUST be identical across windows: height 38px pill, border-radius 19px, background `#0E1013`, border `1px solid rgba(255, 255, 255, 0.08)`, on focus-within border-color `rgba(163, 230, 53, 0.55)`.
   - At start (left): Circular green badge (30x30, `#a3e635`, border-radius 15px) with pitch dark `#040405` 14px search icon.
   - At last (right): Dynamic clear action icon ('close' icon) appears only when typing, to reset text.

4. **Clean Showcase Tiles & Typography (Zero Blur, No Image Overlay Badges):**
   - No size or format badges drawn inside the image area. Images must remain 100% clean and unobstructed.
   - File size is displayed in the bottom metadata line alongside date/time.
   - All text rendered using native `QFont.PreferQuality` and `p.drawText` with subpixel ClearType antialiasing (no vector `addText` path fills for body text).
   - Date sections must have 24px vertical separation with clean editorial title and subtle divider line.
