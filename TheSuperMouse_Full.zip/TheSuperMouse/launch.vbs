Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "D:\THESUPERMOUSE\VERSION 1.0"
WshShell.Run """C:\Users\mytre\AppData\Local\Programs\Python\Python313\python.exe"" main_app.py --supershare", 0, False
