from .common import *
# -*- coding: utf-8 -*-
import os
import sys
import time
import json
import random
import re
import socket
import hashlib
import subprocess
import threading
import urllib.request
import math
import struct
import wave
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from PySide6.QtCore import (
    QEasingCurve,
    QObject,
    QPoint,
    QPropertyAnimation,
    QRect,
    QRectF,
    Qt,
    QTimer,
    QVariantAnimation,
    Signal,
)
from PySide6.QtGui import (
    QBrush,
    QIcon,
    QImage,
    QColor,
    QCursor,
    QFont,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QTransform,
    QLinearGradient,
)
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from ui_theme import (
    ACCENT_LIME,
    TEXT_MUTED,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    native_dpr,
    CleanBackButton,
    CleanCloseButton,
    CleanHeaderIconButton,
    render_common_icon,
    COMMON_ICONS,
    format_count_label,
)

from .common import (
    BASE_DIR, DEFAULT_SAVE_DIR, _load_or_create_config, _save_config,
    _load_app_logo_pix, _draw_vector_brand, _format_bytes
)


def play_calm_chime():
    """
    Play a calm, addictive acoustic chime (silky glass bell harmonic chord)
    instead of harsh robotic system beeps.
    """
    try:
        import winsound
        chime_path = os.path.join(tempfile.gettempdir(), "supershare_calm_chime.wav")
        if not os.path.exists(chime_path) or os.path.getsize(chime_path) < 1000:
            sample_rate = 44100
            duration = 0.45
            n_samples = int(sample_rate * duration)
            with wave.open(chime_path, "wb") as wav:
                wav.setnchannels(1)
                wav.setsampwidth(2)
                wav.setframerate(sample_rate)
                frames = bytearray()
                for i in range(n_samples):
                    t = i / sample_rate
                    env = min(1.0, t / 0.015) * math.exp(-t * 6.5)
                    val = 0.45 * math.sin(2 * math.pi * 1046.5 * t) + 0.35 * math.sin(2 * math.pi * 1318.5 * t) + 0.20 * math.sin(2 * math.pi * 1567.98 * t)
                    sample = int(max(-32767, min(32767, val * env * 22000)))
                    frames.extend(struct.pack("<h", sample))
                wav.writeframes(frames)
        winsound.PlaySound(chime_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
    except Exception:
        pass


class IncomingBeamToastWindow(QWidget):
    """
    Open-Canvas Floating Photo Popup (Centered, Borderless, Text below image):
      - Appears in screen center with smooth emergence
      - Strictly preserves original photo aspect-ratio frame
      - Details and metadata rendered cleanly BELOW the image
      - Zero outer border (clean obsidian borderless canvas)
      - Automatically dismisses previous toast when new image arrives
      - Click to open immediately, auto-dismisses smoothly after 4.5s
    """
    _active_instance = None

    def __init__(self, file_path: str, sender_name: str, size_bytes: int, parent=None):
        if IncomingBeamToastWindow._active_instance and IncomingBeamToastWindow._active_instance != self:
            try:
                IncomingBeamToastWindow._active_instance._dismiss_smoothly()
            except Exception:
                pass
        IncomingBeamToastWindow._active_instance = self

        super().__init__(parent)
        self.file_path = file_path
        self.sender_name = sender_name
        self.size_bytes = size_bytes
        self.file_name = os.path.basename(file_path)

        self.setWindowFlags(
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.setCursor(Qt.PointingHandCursor)

        dpr = native_dpr(self)
        self._thumb = QPixmap()
        self._img_w = 280
        self._img_h = 200

        # Exact Proportional Aspect-Ratio Framing
        if os.path.exists(file_path):
            pix = QPixmap(file_path)
            if not pix.isNull():
                pw, ph = max(1, pix.width()), max(1, pix.height())
                aspect = float(pw) / float(ph)

                max_w, max_h = 340, 240
                min_w, min_h = 240, 160

                if aspect >= 1.0:  # Landscape or Square
                    calc_w = min(max_w, max(min_w, int(max_h * aspect)))
                    if calc_w > max_w:
                        calc_w = max_w
                    calc_h = int(calc_w / aspect)
                else:  # Vertical portrait
                    calc_h = min(max_h, max(min_h, int(max_w / aspect)))
                    if calc_h > max_h:
                        calc_h = max_h
                    calc_w = int(calc_h * aspect)

                self._img_w = max(min_w, calc_w)
                self._img_h = max(min_h, calc_h)

                self._thumb = pix.scaled(
                    int(self._img_w * dpr), int(self._img_h * dpr),
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation
                )
                self._thumb.setDevicePixelRatio(dpr)

        # Card dimensions: natural image + frosted glass details bar below (Zero black container background)
        self._card_w = max(310, self._img_w)
        self._card_h = self._img_h + 10 + 54
        self.setFixedSize(self._card_w, self._card_h)

        # Centered at Bottom of Screen (Above Taskbar)
        scr = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = scr.availableGeometry()
        self.target_x = avail.center().x() - self.width() // 2
        self.target_y = avail.bottom() - self.height() - 36
        self.move(self.target_x, self.target_y + 35)

        self._progress = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(300)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.valueChanged.connect(self._on_anim_val)

        self._close_timer = QTimer(self)
        self._close_timer.setSingleShot(True)
        self._close_timer.timeout.connect(self._dismiss_smoothly)

    def _on_anim_val(self, v):
        self._progress = float(v)
        cur_y = int(self.target_y + 35 * (1.0 - self._progress))
        self.move(self.target_x, cur_y)
        self.update()

    def launch_emergence(self):
        play_calm_chime()
        self.show()
        self.raise_()
        self.activateWindow()
        self._anim.start()
        self._close_timer.start(4500)

    def _dismiss_smoothly(self):
        if IncomingBeamToastWindow._active_instance == self:
            IncomingBeamToastWindow._active_instance = None
        try:
            self._anim.stop()
        except Exception:
            pass
        self._anim.setDuration(190)
        self._anim.setStartValue(self._progress)
        self._anim.setEndValue(0.0)
        self._anim.setEasingCurve(QEasingCurve.InCubic)
        self._anim.finished.connect(self.close)
        self._anim.start()

    def mousePressEvent(self, e):
        try:
            os.startfile(self.file_path)
        except Exception:
            try:
                subprocess.Popen(["explorer", "/select,", self.file_path])
            except Exception:
                pass
        self._dismiss_smoothly()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)

        t = max(0.0, min(1.0, self._progress))
        p.setOpacity(t)
        w, h = float(self.width()), float(self.height())

        # 1. Image (Natural aspect-ratio, Rounded corners, ZERO black container background)
        img_w = float(self._img_w)
        img_h = float(self._img_h)
        img_x = (w - img_w) / 2.0
        img_rect = QRectF(img_x, 0.0, img_w, img_h)
        img_path = QPainterPath()
        img_path.addRoundedRect(img_rect, 16.0, 16.0)

        p.save()
        p.setClipPath(img_path)
        if not self._thumb.isNull():
            tw = self._thumb.width() / self._thumb.devicePixelRatio()
            th = self._thumb.height() / self._thumb.devicePixelRatio()
            ox = img_rect.left() + (img_rect.width() - tw) / 2.0
            oy = img_rect.top() + (img_rect.height() - th) / 2.0
            p.drawPixmap(int(ox), int(oy), self._thumb)
        else:
            p.fillRect(img_rect, QColor(24, 27, 34, 255))
        p.restore()

        # 2. Details Bar below image (Frosted Blur Overlay Background matching user image)
        bar_y = img_h + 8.0
        bar_h = 52.0
        bar_rect = QRectF(0.0, bar_y, w, bar_h)
        bar_path = QPainterPath()
        bar_path.addRoundedRect(bar_rect, 26.0, 26.0)

        # Frosted glass blur overlay background (matching user reference design)
        bar_grad = QLinearGradient(bar_rect.left(), bar_rect.top(), bar_rect.left(), bar_rect.bottom())
        bar_grad.setColorAt(0.0, QColor(32, 38, 48, 235))
        bar_grad.setColorAt(1.0, QColor(14, 17, 24, 245))
        p.fillPath(bar_path, bar_grad)
        p.setPen(QPen(QColor(255, 255, 255, 45), 1.0))
        p.drawPath(bar_path)

        # Left: Circular Avatar with vibrant gradient ring
        av_size = 36.0
        av_x = 9.0
        av_y = bar_y + (bar_h - av_size) / 2.0
        av_rect = QRectF(av_x, av_y, av_size, av_size)

        av_grad = QLinearGradient(av_rect.left(), av_rect.top(), av_rect.right(), av_rect.bottom())
        av_grad.setColorAt(0.0, QColor(163, 230, 53))
        av_grad.setColorAt(1.0, QColor(0, 255, 133))
        p.setPen(QPen(av_grad, 2.0))
        p.setBrush(QColor(10, 12, 16))
        p.drawEllipse(av_rect)

        # Avatar initial or glyph
        p.setFont(QFont("Segoe UI Variable Display", 11, QFont.Bold))
        p.setPen(QColor(255, 255, 255))
        init_char = (self.sender_name[:1] if self.sender_name else "U").upper()
        p.drawText(av_rect, Qt.AlignCenter, init_char)

        # Middle: Sender Handle + Timestamp / Size
        clean_handle = self.sender_name.lower().replace(" ", "")
        p.setFont(QFont("Segoe UI Variable Display", 10, QFont.Bold))
        p.setPen(QColor(255, 255, 255))
        p.drawText(int(av_x + av_size + 10.0), int(bar_y + 22.0), f"@{clean_handle}")

        p.setFont(QFont("Segoe UI Variable Text", 8, QFont.Normal))
        p.setPen(QColor(156, 163, 175, 230))
        meta_txt = f"Just now  ·  {_format_bytes(self.size_bytes)}"
        p.drawText(int(av_x + av_size + 10.0), int(bar_y + 38.0), meta_txt)

        # Right: Solid White Pill Button "Open" (Matching user reference image style)
        btn_w = 68.0
        btn_h = 32.0
        btn_x = w - btn_w - 10.0
        btn_y = bar_y + (bar_h - btn_h) / 2.0
        btn_rect = QRectF(btn_x, btn_y, btn_w, btn_h)
        btn_path = QPainterPath()
        btn_path.addRoundedRect(btn_rect, 16.0, 16.0)

        p.fillPath(btn_path, QColor(255, 255, 255))
        p.setFont(QFont("Segoe UI Variable Display", 9, QFont.Bold))
        p.setPen(QColor(10, 12, 16))
        p.drawText(btn_rect, Qt.AlignCenter, "Open")

        p.end()


class IncomingRequestToast(QWidget):
    """
    Cursor Window UI Style Session Request Toast:
      - Bottom-right corner above Windows taskbar with smooth slide-up animation
      - Pitch Obsidian Black canvas (#07080B), 14px rounded corners
      - SUPER SHARE PAIR REQUEST tag (no dot)
      - Device Name in big bold white, Device ID in true neutral grey below
      - Razor-sharp Decline & Accept Vibe buttons side-by-side
      - Wider top Cyber-Lime gradient accent line
    """

    def __init__(self, device_name: str, device_id: str, on_decide, parent=None):
        super().__init__(parent)
        self.device_name = device_name
        self.device_id = device_id
        self.on_decide = on_decide

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.setFixedSize(364, 146)

        scr = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = scr.availableGeometry()
        self.target_x = avail.right() - self.width() - 20
        self.target_y = avail.bottom() - self.height() - 20
        self.move(self.target_x, self.target_y + 40)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 16, 20, 16)
        lay.setSpacing(0)

        # Top row: SUPER SHARE PAIR REQUEST tag (Zero green dot, Zero close button!)
        lbl_tag = QLabel("SUPER SHARE PAIR REQUEST", self)
        lbl_tag.setStyleSheet(
            "color: #a3e635; font-size: 11px; font-weight: 800; letter-spacing: 0.9px; "
            "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;"
        )
        lay.addWidget(lbl_tag)

        # Perfectly equal top spacing
        lay.addSpacing(13)

        # Big White Bold Device Name
        t = QLabel(self.device_name, self)
        t.setStyleSheet("color: #FFFFFF; font-family: 'Segoe UI Variable Display', sans-serif; font-size: 16px; font-weight: 800; letter-spacing: 0.2px;")
        lay.addWidget(t)

        lay.addSpacing(4)

        # Subtitle: Device ID only in true neutral grey (NOT navy grey!)
        s = QLabel(self.device_id, self)
        s.setStyleSheet("color: #9CA3AF; font-family: 'Segoe UI Variable Text', sans-serif; font-size: 12px; font-weight: 600;")
        lay.addWidget(s)

        # Exactly equal bottom spacing to the buttons row
        lay.addSpacing(13)

        # Action Buttons: Decline next to Accept Vibe, razor sharp crisp styling
        row = QHBoxLayout()
        row.setSpacing(10)
        row.addStretch(1)

        b_dec = QPushButton("Decline", self)
        b_dec.setCursor(Qt.PointingHandCursor)
        b_dec.setFixedHeight(34)
        b_dec.setStyleSheet(
            "QPushButton { background: rgba(255, 255, 255, 0.08); color: #E4E4E7; border: 1px solid rgba(255, 255, 255, 0.24); "
            "border-radius: 9px; padding: 0 18px; font-size: 12px; font-weight: 700; font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; } "
            "QPushButton:hover { background: rgba(239, 68, 68, 0.22); border-color: #EF4444; color: #EF4444; }"
        )

        b_acc = QPushButton("Accept Vibe", self)
        b_acc.setCursor(Qt.PointingHandCursor)
        b_acc.setFixedHeight(34)
        b_acc.setStyleSheet(
            "QPushButton { background: #a3e635; color: #040405; border: 1px solid #a3e635; "
            "border-radius: 9px; padding: 0 22px; font-size: 12.5px; font-weight: 800; font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; } "
            "QPushButton:hover { background: #bbf45c; border-color: #bbf45c; } QPushButton:pressed { background: #8cd622; border-color: #8cd622; }"
        )

        def _on_dec():
            b_dec.setEnabled(False)
            b_acc.setEnabled(False)
            self._finish(False, False)

        def _on_acc():
            b_dec.setEnabled(False)
            b_acc.setEnabled(False)
            self._finish(True, False)

        b_dec.clicked.connect(_on_dec)
        b_acc.clicked.connect(_on_acc)

        row.addWidget(b_dec)
        row.addWidget(b_acc)
        lay.addLayout(row)

        self._progress = 0.0
        self.anim = QVariantAnimation(self)
        self.anim.setDuration(300)
        self.anim.setStartValue(0.0)
        self.anim.setEndValue(1.0)
        self.anim.setEasingCurve(QEasingCurve.OutCubic)
        self.anim.valueChanged.connect(self._on_slide_val)

        # Held for 5 minutes only, else auto-dismissed
        self._auto_close_timer = QTimer(self)
        self._auto_close_timer.setSingleShot(True)
        self._auto_close_timer.timeout.connect(lambda: self._finish(False, False))

    def _on_slide_val(self, v):
        self._progress = float(v)
        cur_y = int(self.target_y + 40 * (1.0 - self._progress))
        self.move(self.target_x, cur_y)
        self.update()

    def _finish(self, accepted, trusted):
        if getattr(self, "_finished", False):
            return
        self._finished = True
        try:
            self._auto_close_timer.stop()
        except Exception:
            pass
        try:
            self.on_decide(accepted, trusted, False)
        except Exception:
            pass
        self.close()

    def showEvent(self, e):
        super().showEvent(e)
        self.raise_()
        self.activateWindow()
        self.anim.start()
        self._auto_close_timer.start(300000)  # 5 minutes hold limit
        play_calm_chime()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        t = max(0.0, min(1.0, self._progress))
        p.setOpacity(t)
        w, h = float(self.width()), float(self.height())
        path = QPainterPath()
        path.addRoundedRect(QRectF(1.0, 1.0, w - 2.0, h - 2.0), 14.0, 14.0)

        # Pure Pitch Obsidian Black canvas (Zero navy tint!)
        p.fillPath(path, QColor(7, 8, 11, 253))
        p.setPen(QPen(QColor(255, 255, 255, 20), 1.0))
        p.drawPath(path)

        # Centered glowing Cyber-Lime accent gradient line at top (enlarged & punchy)
        accent_w = 76.0
        accent_x = (w - accent_w) / 2.0
        accent_rect = QRectF(accent_x, 2.0, accent_w, 3.0)
        accent_path = QPainterPath()
        accent_path.addRoundedRect(accent_rect, 1.5, 1.5)
        accent_grad = QLinearGradient(accent_rect.left(), 0.0, accent_rect.right(), 0.0)
        accent_grad.setColorAt(0.0, QColor(163, 230, 53, 0))
        accent_grad.setColorAt(0.25, QColor(163, 230, 53, 235))
        accent_grad.setColorAt(0.5, QColor(163, 230, 53, 255))
        accent_grad.setColorAt(0.75, QColor(0, 255, 133, 235))
        accent_grad.setColorAt(1.0, QColor(0, 255, 133, 0))
        p.fillPath(accent_path, accent_grad)
        p.end()


class SessionStartedToastWindow(QWidget):
    """
    Clean Cursor Window UI Toast for Session Confirmation (Single-Line, Borderless):
      - Smooth slide-up emergence from bottom right
      - Pure Pitch Obsidian Black canvas (#07080B) with 14px rounded corners
      - Clean single-line message: "Vibe Session started with {device_name} [{device_id}]"
      - Zero border (clean borderless style matching user requirement!)
      - Calm harmonic chime on appearance
      - Auto-dismisses smoothly after 4.5 seconds
    """

    def __init__(self, device_name: str, device_id: str, parent=None):
        super().__init__(parent)
        self.device_name = device_name
        self.device_id = device_id

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.setFixedSize(380, 52)

        scr = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = scr.availableGeometry()
        self.target_x = avail.right() - self.width() - 20
        self.target_y = avail.bottom() - self.height() - 20
        self.move(self.target_x, self.target_y + 35)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(18, 0, 18, 0)
        lay.setSpacing(10)

        # Single-line message with green indicator dot
        lbl_dot = QLabel("●", self)
        lbl_dot.setStyleSheet("color: #a3e635; font-size: 10px; font-weight: 800;")
        lay.addWidget(lbl_dot)

        line_txt = f"Vibe Session started with {device_name} [{device_id}]"
        self.lbl_msg = QLabel(line_txt, self)
        self.lbl_msg.setStyleSheet(
            "color: #FFFFFF; font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; "
            "font-size: 12.5px; font-weight: 700; letter-spacing: 0.1px;"
        )
        lay.addWidget(self.lbl_msg, 1)

        self._progress = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(280)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.valueChanged.connect(self._on_anim_val)

        self._close_timer = QTimer(self)
        self._close_timer.setSingleShot(True)
        self._close_timer.timeout.connect(self._dismiss_smoothly)

    def _on_anim_val(self, v):
        self._progress = float(v)
        cur_y = int(self.target_y + 35 * (1.0 - self._progress))
        self.move(self.target_x, cur_y)
        self.update()

    def launch_emergence(self):
        self.show()
        self.raise_()
        self.activateWindow()
        self._anim.start()
        self._close_timer.start(4500)

    def _dismiss_smoothly(self):
        try:
            self._anim.stop()
        except Exception:
            pass
        self._anim.setDuration(180)
        self._anim.setStartValue(self._progress)
        self._anim.setEndValue(0.0)
        self._anim.setEasingCurve(QEasingCurve.InCubic)
        self._anim.finished.connect(self.close)
        self._anim.start()

    def mousePressEvent(self, e):
        self._dismiss_smoothly()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        t = max(0.0, min(1.0, self._progress))
        p.setOpacity(t)
        w, h = float(self.width()), float(self.height())
        path = QPainterPath()
        path.addRoundedRect(QRectF(1.0, 1.0, w - 2.0, h - 2.0), 14.0, 14.0)

        # Pure Pitch Obsidian Black canvas, ZERO border!
        p.fillPath(path, QColor(7, 8, 11, 253))
        p.setPen(Qt.NoPen)

        # Top glowing accent gradient line (enlarged & punchy)
        accent_w = 68.0
        accent_x = (w - accent_w) / 2.0
        accent_rect = QRectF(accent_x, 2.0, accent_w, 2.8)
        accent_path = QPainterPath()
        accent_path.addRoundedRect(accent_rect, 1.4, 1.4)
        accent_grad = QLinearGradient(accent_rect.left(), 0.0, accent_rect.right(), 0.0)
        accent_grad.setColorAt(0.0, QColor(163, 230, 53, 0))
        accent_grad.setColorAt(0.25, QColor(163, 230, 53, 235))
        accent_grad.setColorAt(0.5, QColor(163, 230, 53, 255))
        accent_grad.setColorAt(0.75, QColor(0, 255, 133, 235))
        accent_grad.setColorAt(1.0, QColor(0, 255, 133, 0))
        p.fillPath(accent_path, accent_grad)
        p.end()


class SingleLineNoticeToast(QWidget):
    """
    Normal Minimal 1-Line Popup Alert at bottom center:
    'Waiting for the device to accept the connection'
    """
    _active_instance = None

    def __init__(self, message: str = "Waiting for the device to accept the connection", parent=None):
        super().__init__(parent)
        if SingleLineNoticeToast._active_instance:
            try:
                SingleLineNoticeToast._active_instance.close()
            except Exception:
                pass
        SingleLineNoticeToast._active_instance = self
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.setFixedSize(430, 48)

        scr = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = scr.availableGeometry()
        self.target_x = avail.center().x() - self.width() // 2
        self.target_y = avail.bottom() - self.height() - 36
        self.move(self.target_x, self.target_y + 30)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(18, 0, 18, 0)
        lay.setSpacing(10)

        lbl_dot = QLabel("●", self)
        lbl_dot.setStyleSheet("color: #a3e635; font-size: 10px; font-weight: 800;")
        lay.addWidget(lbl_dot)

        lbl_msg = QLabel(message, self)
        lbl_msg.setStyleSheet(
            "color: #FFFFFF; font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; "
            "font-size: 12.5px; font-weight: 600; letter-spacing: 0.1px;"
        )
        lay.addWidget(lbl_msg, 1)

        self._progress = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(260)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.valueChanged.connect(self._on_anim_val)

        self._close_timer = QTimer(self)
        self._close_timer.setSingleShot(True)
        self._close_timer.timeout.connect(self._dismiss_smoothly)

    def _on_anim_val(self, v):
        self._progress = float(v)
        cur_y = int(self.target_y + 30 * (1.0 - self._progress))
        self.move(self.target_x, cur_y)
        self.update()

    def launch(self):
        self.show()
        self.raise_()
        self.activateWindow()
        self._anim.start()
        self._close_timer.start(5000)

    def _dismiss_smoothly(self):
        if SingleLineNoticeToast._active_instance == self:
            SingleLineNoticeToast._active_instance = None
        self.close()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        t = max(0.0, min(1.0, self._progress))
        p.setOpacity(t)
        w, h = float(self.width()), float(self.height())
        path = QPainterPath()
        path.addRoundedRect(QRectF(1.0, 1.0, w - 2.0, h - 2.0), 14.0, 14.0)
        p.fillPath(path, QColor(8, 10, 14, 238))
        p.setPen(Qt.NoPen)

        # Top glowing accent line
        accent_w = 64.0
        accent_x = (w - accent_w) / 2.0
        accent_rect = QRectF(accent_x, 2.0, accent_w, 2.4)
        accent_path = QPainterPath()
        accent_path.addRoundedRect(accent_rect, 1.2, 1.2)
        accent_grad = QLinearGradient(accent_rect.left(), 0.0, accent_rect.right(), 0.0)
        accent_grad.setColorAt(0.0, QColor(163, 230, 53, 0))
        accent_grad.setColorAt(0.5, QColor(163, 230, 53, 255))
        accent_grad.setColorAt(1.0, QColor(0, 255, 133, 0))
        p.fillPath(accent_path, accent_grad)
        p.end()



# ──────────────────────────────────────────────────────────────────────────────
#  VECTOR BRAND DRAWING & LOGO HELPER (Matching Super Snap & Pin / My Box)
# ──────────────────────────────────────────────────────────────────────────────

