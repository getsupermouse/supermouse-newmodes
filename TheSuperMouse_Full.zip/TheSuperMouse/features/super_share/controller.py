from .common import *
# -*- coding: utf-8 -*-
import os
import sys
import time
import json
import random
import re
import socket
import hashlib
import subprocess
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from PySide6.QtCore import (
    QEasingCurve,
    QObject,
    QPoint,
    QPropertyAnimation,
    QRect,
    QRectF,
    Qt,
    QTimer,
    QVariantAnimation,
    Signal,
)
from PySide6.QtGui import (
    QIcon,
    QImage,
    QColor,
    QCursor,
    QFont,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QTransform,
    QLinearGradient,
)
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from ui_theme import (
    ACCENT_LIME,
    TEXT_MUTED,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    native_dpr,
    CleanBackButton,
    CleanCloseButton,
    CleanHeaderIconButton,
    render_common_icon,
    COMMON_ICONS,
    format_count_label,
)

from .common import count_stored_share_items, _load_or_create_config, _save_config
from .engine import SuperShareEngine
from .device_hub import SuperShareDeviceWindow
from .memory_space import SuperShareStoredWindow
from .settings import SuperShareSettingsWindow
from .menu_window import SuperShareMenuWindow
from .toasts import IncomingBeamToastWindow, IncomingRequestToast, SessionStartedToastWindow


class SuperShareController:
    """Owns shared SuperShareEngine, DeviceWindow, StoredWindow, SettingsWindow, and beam notifications."""

    def __init__(self, on_back_to_menu=None):
        self.engine = SuperShareEngine()
        self._active_widgets: list[QWidget] = []
        self._on_back_to_menu = on_back_to_menu

        self.stored_window = SuperShareStoredWindow(
            self.engine,
            on_back_to_menu=on_back_to_menu,
        )
        self.device_window = SuperShareDeviceWindow(
            self.engine,
            on_back_to_menu=on_back_to_menu,
            on_open_stored=self.stored_window.open_window,
        )
        self.settings_window = SuperShareSettingsWindow(
            self.engine,
            on_back_to_menu=on_back_to_menu,
        )
        self.menu_window = SuperShareMenuWindow(
            on_back_to_menu=on_back_to_menu,
            on_open_device=self.device_window.open_asmr_switch,
            on_open_stored=self.stored_window.open_asmr_switch,
            on_open_settings=self.settings_window.open_asmr_switch,
        )
        self.on_back_to_share_menu = self.menu_window.open_asmr_switch

        self.stored_window.on_open_devices = self.device_window.open_window
        self.stored_window.on_open_settings = self.settings_window.open_window
        self.device_window.on_open_settings = self.settings_window.open_window
        self.settings_window.on_settings_changed = self.device_window._refresh_identity_card

        self.engine.signals.incoming_prompt.connect(self._on_incoming_prompt)
        self.engine.signals.file_received.connect(self._on_file_received)
        self.engine.signals.session_started.connect(self._on_session_started)
        self.engine.start()

    @property
    def on_back_to_menu(self):
        return self._on_back_to_menu

    @on_back_to_menu.setter
    def on_back_to_menu(self, fn):
        self._on_back_to_menu = fn
        if hasattr(self, "menu_window"):
            self.menu_window.on_back_to_menu = fn
        self.device_window.on_back_to_menu = fn
        self.device_window.on_main_menu = fn
        self.stored_window.on_back_to_menu = fn
        self.stored_window.on_main_menu = fn
        self.settings_window.on_back_to_menu = fn
        self.settings_window.on_main_menu = fn

    @property
    def on_back_to_share_menu(self):
        return getattr(self, "_on_back_to_share_menu", None)

    @on_back_to_share_menu.setter
    def on_back_to_share_menu(self, fn):
        self._on_back_to_share_menu = fn
        self.device_window.on_back_to_share_menu = fn
        self.stored_window.on_back_to_share_menu = fn
        self.settings_window.on_back_to_share_menu = fn

    def _on_incoming_prompt(self, req_id: str, kind: str, sender_id: str, label: str, size_bytes: int):
        for w in list(self._active_widgets):
            if isinstance(w, IncomingRequestToast):
                try:
                    w.close()
                except Exception:
                    pass
        dev_name = label if label else "Nearby Device"
        dev_id = f"[{sender_id}]" if sender_id else ""
        toast = IncomingRequestToast(
            device_name=dev_name,
            device_id=dev_id,
            on_decide=lambda allow, trust, continuous=False, rid=req_id: self.engine.resolve_prompt(rid, allow, trust, continuous),
        )
        self._active_widgets.append(toast)
        toast.destroyed.connect(lambda *_: self._active_widgets.remove(toast) if toast in self._active_widgets else None)
        toast.show()
        toast.raise_()

    def _on_file_received(self, path: str, sender: str, size_bytes: int, _mime: str):
        for w in list(self._active_widgets):
            if isinstance(w, IncomingBeamToastWindow):
                try:
                    w._dismiss_smoothly()
                except Exception:
                    pass
        toast = IncomingBeamToastWindow(path, sender, size_bytes)
        self._active_widgets.append(toast)
        toast.destroyed.connect(lambda *_: self._active_widgets.remove(toast) if toast in self._active_widgets else None)
        toast.launch_emergence()
        if self.stored_window.isVisible():
            self.stored_window.refresh_gallery()

    def _on_session_started(self, device_name: str, device_id: str):
        toast = SessionStartedToastWindow(device_name, device_id)
        self._active_widgets.append(toast)
        toast.destroyed.connect(lambda *_: self._active_widgets.remove(toast) if toast in self._active_widgets else None)
        toast.launch_emergence()
