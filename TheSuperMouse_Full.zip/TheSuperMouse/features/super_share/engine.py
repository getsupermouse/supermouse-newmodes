from .common import *
# -*- coding: utf-8 -*-
import os
import sys
import time
import json
import random
import re
import socket
import hashlib
import subprocess
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from PySide6.QtCore import (
    QEasingCurve,
    QObject,
    QPoint,
    QPropertyAnimation,
    QRect,
    QRectF,
    Qt,
    QTimer,
    QVariantAnimation,
    Signal,
)
from PySide6.QtGui import (
    QIcon,
    QImage,
    QColor,
    QCursor,
    QFont,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QTransform,
    QLinearGradient,
)
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from ui_theme import (
    ACCENT_LIME,
    TEXT_MUTED,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    native_dpr,
    CleanBackButton,
    CleanCloseButton,
    CleanHeaderIconButton,
    render_common_icon,
    COMMON_ICONS,
    format_count_label,
)

from .common import (
    BASE_DIR, CONFIG_PATH, DEFAULT_SAVE_DIR, UDP_DISCOVERY_PORT,
    HTTP_PORT_START, HTTP_PORT_END, _DEVICE_ID_PATTERN, _IMAGE_EXTS, _MEDIA_EXTS,
    generate_8char_device_id, compute_linked_12_code, format_12_code,
    count_stored_share_items, _load_or_create_config, _save_config, _format_bytes,
    _get_local_ipv4
)


class _EngineSignals(QObject):
    peers_updated = Signal(list)
    pair_result = Signal(bool, str, dict)
    incoming_prompt = Signal(str, str, str, str, int)  # req_id, kind('pair'|'transfer'), sender_id, sender_name, size
    file_received = Signal(str, str, int, str)
    session_started = Signal(str, str)  # device_name, device_id


class SuperShareEngine:
    """Thread-safe UDP beacon + HTTP/TCP Normal/Trusted permission handshake + binary receiver."""

    def __init__(self):
        self.cfg = _load_or_create_config()
        self.device_id: str = self.cfg["device_id"]
        self.device_name: str = self.cfg["device_name"]
        self.save_dir: str = self.cfg.get("save_dir") or DEFAULT_SAVE_DIR
        self.trusted_ids: set[str] = {str(x).strip().upper() for x in self.cfg.get("trusted_ids", []) if x}
        os.makedirs(self.save_dir, exist_ok=True)

        self.signals = _EngineSignals()
        self.http_port: int = HTTP_PORT_START
        self._running = False
        self._lock = threading.Lock()
        self._peers: dict[str, dict] = {}
        # Start fresh each run for normal connections; trusted_ids remain persisted
        self._connected_modes: dict[str, str] = {}  # pid -> "NORMAL" | "TRUSTED"
        self._linked_codes: dict[str, str] = {}     # pid -> 12-digit code
        self._session_activity: dict[str, float] = {} # pid -> timestamp of last item sent/received
        self.continuous_sharing_ids: set[str] = set() # pid -> continuous sharing toggle
        self._pending_decisions: dict[str, dict] = {}  # req_id -> {event, allow, trust}
        self._http_server = None
        self._udp_sock = None

    def start(self):
        if self._running:
            return
        self._running = True
        self._start_http_server()
        threading.Thread(target=self._udp_listener_loop, daemon=True).start()
        threading.Thread(target=self._udp_beacon_loop, daemon=True).start()

    def stop(self):
        self._running = False
        try:
            if self._http_server:
                self._http_server.shutdown()
        except Exception:
            pass
        try:
            if self._udp_sock:
                self._udp_sock.close()
        except Exception:
            pass

    def is_session_active(self, peer_id: str) -> bool:
        pid = (peer_id or "").strip().upper()
        if not pid:
            return False
        if pid in self.continuous_sharing_ids:
            return True
        if pid in self.trusted_ids or self._connected_modes.get(pid) == "TRUSTED":
            return True
        last_t = self._session_activity.get(pid, 0.0)
        return (time.time() - last_t) < 300.0  # 5-minute active vibe session

    def touch_session(self, peer_id: str):
        pid = (peer_id or "").strip().upper()
        if pid:
            self._session_activity[pid] = time.time()

    def toggle_continuous_sharing(self, pid: str, enable: bool | None = None):
        clean = (pid or "").strip().upper()
        if not clean:
            return
        if enable is None:
            enable = clean not in self.continuous_sharing_ids
        if enable:
            self.continuous_sharing_ids.add(clean)
            self.touch_session(clean)
        else:
            self.continuous_sharing_ids.discard(clean)
        target = self._peers.get(clean)
        if target:
            def _notify():
                try:
                    body = json.dumps({"session_active": True, "continuous": enable, "id": self.device_id}).encode("utf-8")
                    req = urllib.request.Request(
                        f"http://{target.get('ip')}:{target.get('httpPort', 8765)}/session_update",
                        data=body,
                        headers={"Content-Type": "application/json"},
                        method="POST"
                    )
                    urllib.request.urlopen(req, timeout=1.5)
                except Exception:
                    pass
            threading.Thread(target=_notify, daemon=True).start()
        self.signals.peers_updated.emit(self.get_peers_snapshot())

    def kill_session(self, peer_id: str):
        pid = (peer_id or "").strip().upper()
        if pid in self._session_activity:
            del self._session_activity[pid]
        self.continuous_sharing_ids.discard(pid)
        target = self._peers.get(pid)
        if target:
            def _notify_close():
                try:
                    body = json.dumps({"session_active": False, "continuous": False, "id": self.device_id}).encode("utf-8")
                    req = urllib.request.Request(
                        f"http://{target.get('ip')}:{target.get('httpPort', 8765)}/session_update",
                        data=body,
                        headers={"Content-Type": "application/json"},
                        method="POST"
                    )
                    urllib.request.urlopen(req, timeout=1.5)
                except Exception:
                    pass
            threading.Thread(target=_notify_close, daemon=True).start()

    def resolve_prompt(self, req_id: str, allow: bool, trust: bool = False, continuous: bool = False):
        with self._lock:
            entry = self._pending_decisions.get(req_id)
            if not entry and self._pending_decisions:
                # Fallback to any pending decision to prevent orphaned requests
                entry = next(iter(self._pending_decisions.values()))
        pid = entry.get("sender_id", "") if entry else ""
        if not pid and "_" in req_id:
            parts = req_id.split("_")
            if len(parts) >= 2:
                pid = parts[1]

        if allow and trust and pid:
            self.set_peer_trusted(pid, True)

        if allow and pid:
            self.touch_session(pid)
            mode = "TRUSTED" if trust else "NORMAL"
            with self._lock:
                if pid in self._peers:
                    self._peers[pid]["connected"] = True
                    self._peers[pid]["mode"] = mode
                self._connected_modes[pid] = mode

            target = self._peers.get(pid)
            if target:
                def _notify_start():
                    try:
                        body = json.dumps({"session_active": True, "continuous": False, "id": self.device_id}).encode("utf-8")
                        req = urllib.request.Request(
                            f"http://{target.get('ip')}:{target.get('httpPort', 8765)}/session_update",
                            data=body,
                            headers={"Content-Type": "application/json"},
                            method="POST"
                        )
                        urllib.request.urlopen(req, timeout=3.0)
                    except Exception:
                        pass
                threading.Thread(target=_notify_start, daemon=True).start()

            self.signals.peers_updated.emit(self.get_peers_snapshot())
            pname = self._peers.get(pid, {}).get("name", pid)
            self.signals.session_started.emit(pname, pid)

        if entry:
            entry["allow"] = bool(allow)
            entry["trust"] = bool(trust)
            entry["event"].set()

    def set_peer_trusted(self, pid: str, trusted: bool):
        clean = pid.strip().upper()
        target_info = None
        with self._lock:
            if trusted:
                self.trusted_ids.add(clean)
                if clean in self._connected_modes:
                    self._connected_modes[clean] = "TRUSTED"
            else:
                self.trusted_ids.discard(clean)
                self._connected_modes.pop(clean, None)
                self.kill_session(clean)
            self.cfg["trusted_ids"] = sorted(self.trusted_ids)
            _save_config(self.cfg)
            target_info = dict(self._peers.get(clean, {}))

        # Immediately notify the peer device over HTTP so its state flips to "Let's Vibe" in milliseconds!
        if not trusted and target_info:
            pip = target_info.get("ip")
            pport = int(target_info.get("httpPort") or 8765)
            if pip:
                def _notify_untrust(ip, port, my_id):
                    try:
                        req = urllib.request.Request(
                            f"http://{ip}:{port}/trust_update",
                            data=json.dumps({"id": my_id, "trusted": False, "mode": "NORMAL"}).encode("utf-8"),
                            headers={"Content-Type": "application/json"},
                            method="POST",
                        )
                        with urllib.request.urlopen(req, timeout=2.5) as resp:
                            pass
                    except Exception:
                        pass
                threading.Thread(target=_notify_untrust, args=(pip, pport, self.device_id), daemon=True).start()

        self.broadcast_now()
        self.signals.peers_updated.emit(self.get_peers_snapshot())

    def get_peers_snapshot(self) -> list[dict]:
        now = time.time()
        with self._lock:
            alive = {}
            seen_ips = {}
            stale_pids = []
            for pid, info in list(self._peers.items()):
                is_conn = pid in self._connected_modes
                age = now - info.get("last_seen", 0.0)
                # Real-time liveness: If peer has not been seen within 14s, drop from active list!
                if age > 14.0:
                    if is_conn:
                        stale_pids.append(pid)
                    continue
                ip_key = f"{info.get('ip')}:{info.get('httpPort')}"
                # Deduplicate identical device endpoint entries if ID changed cleanly
                if ip_key in seen_ips and seen_ips[ip_key] in alive:
                    prev_pid = seen_ips[ip_key]
                    if info.get("last_seen", 0.0) >= alive[prev_pid].get("last_seen", 0.0):
                        del alive[prev_pid]
                    else:
                        continue
                copy_info = dict(info)
                copy_info["connected"] = is_conn
                copy_info["mode"] = "TRUSTED" if pid in self.trusted_ids else self._connected_modes.get(pid, "NORMAL")
                copy_info["linked_code"] = self._linked_codes.get(pid) or (
                    compute_linked_12_code(self.device_id, pid) if is_conn else ""
                )
                alive[pid] = copy_info
                seen_ips[ip_key] = pid

            for spid in stale_pids:
                self._connected_modes.pop(spid, None)
                self._linked_codes.pop(spid, None)
                self._peers.pop(spid, None)

            self._peers = alive
            return sorted(
                alive.values(),
                key=lambda d: (not d.get("connected", False), -d.get("last_seen", 0.0)),
            )

    def broadcast_now(self):
        ip = _get_local_ipv4()
        avatar_id = int(self.cfg.get("avatar_id", 2))
        grad_idx = int(self.cfg.get("avatar_gradient_idx", 0))
        dev_name = self.cfg.get("device_name") or self.device_name
        payload = json.dumps(
            {
                "app": "SuperShare",
                "id": self.device_id,
                "name": dev_name,
                "platform": "Windows",
                "ip": ip,
                "httpPort": self.http_port,
                "avatar_id": avatar_id,
                "avatar_gradient_idx": grad_idx,
                "trusted_ids": list(self.trusted_ids),
                "session_ids": [p for p in self._session_activity if self.is_session_active(p)],
            }
        ).encode("utf-8")
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            s.sendto(payload, ("255.255.255.255", UDP_DISCOVERY_PORT))
            if "." in ip and not ip.startswith("127."):
                s.sendto(payload, (ip.rsplit(".", 1)[0] + ".255", UDP_DISCOVERY_PORT))
            with self._lock:
                for p in self._peers.values():
                    pip = p.get("ip")
                    if pip and pip != ip:
                        try:
                            s.sendto(payload, (pip, UDP_DISCOVERY_PORT))
                        except Exception:
                            pass
            s.close()
        except Exception:
            pass

    def check_and_connect_id(self, target_id: str):
        clean_id = target_id.strip().upper()
        if not clean_id:
            self.signals.pair_result.emit(False, "Enter an 8-char Device ID first", {})
            return
        if clean_id == self.device_id.upper():
            self.signals.pair_result.emit(False, "That is this PC's own ID", {})
            return

        def _worker():
            target = None
            for _ in range(5):
                with self._lock:
                    target = self._peers.get(clean_id)
                if target:
                    break
                self.broadcast_now()
                time.sleep(0.22)

            if not target:
                self.signals.pair_result.emit(False, f"ID {clean_id} not found on same Wi-Fi signal", {})
                return

            peer_ip = target.get("ip", "")
            peer_port = int(target.get("httpPort", 8765))
            linked_code = compute_linked_12_code(self.device_id, clean_id)
            body = json.dumps(
                {
                    "id": self.device_id,
                    "name": self.device_name,
                    "platform": "Windows",
                    "ip": _get_local_ipv4(),
                    "httpPort": self.http_port,
                    "linkedCode": linked_code,
                    "mode": "TRUSTED" if clean_id in self.trusted_ids else "NORMAL",
                }
            ).encode("utf-8")
            try:
                req = urllib.request.Request(
                    f"http://{peer_ip}:{peer_port}/pair",
                    data=body,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=30.0) as resp:
                    raw = json.loads(resp.read().decode("utf-8"))
                    status = str(raw.get("status", "CONNECTED")).upper()
                    if resp.status in (200, 201) and status == "CONNECTED":
                        mode = "TRUSTED" if (clean_id in self.trusted_ids or raw.get("mode") == "TRUSTED") else "NORMAL"
                        self.touch_session(clean_id)
                        pname = target.get("name", clean_id)
                        self.signals.session_started.emit(pname, clean_id)
                        with self._lock:
                            self._connected_modes[clean_id] = mode
                            self._linked_codes[clean_id] = linked_code
                            target["connected"] = True
                            target["mode"] = mode
                            target["linked_code"] = linked_code
                            target["last_seen"] = time.time()
                        self.signals.peers_updated.emit(self.get_peers_snapshot())
                        self.signals.pair_result.emit(
                            True,
                            f"-- CONNECT -- ({format_12_code(linked_code)})",
                            dict(target),
                        )
                        return
                    self.signals.pair_result.emit(False, f"Declined by {clean_id}", {})
                    return
            except Exception as exc:
                self.signals.pair_result.emit(False, f"Signal error ({exc})", {})

        threading.Thread(target=_worker, daemon=True).start()

    def send_file_to_connected(self, file_path: str, peer: dict | None = None, progress_cb=None, sync: bool = False):
        if not os.path.exists(file_path):
            return
        if peer is None:
            snaps = self.get_peers_snapshot()
            peer = next((p for p in snaps if p.get("connected")), None)
        if not peer:
            self.signals.pair_result.emit(False, "Connect a device (-- CONNECT --) first", {})
            return

        def _sender():
            pid = peer["id"]
            ip = peer["ip"]
            port = int(peer.get("httpPort", 8765))
            fname = os.path.basename(file_path)
            size = os.path.getsize(file_path)

            is_fast = (
                (pid in self.trusted_ids)
                or self.is_session_active(pid)
                or (self._connected_modes.get(pid) in ("TRUSTED", "NORMAL"))
                or bool(peer.get("connected"))
                or (peer.get("mode") in ("TRUSTED", "NORMAL"))
            )
            if not is_fast:
                try:
                    preq = urllib.request.Request(
                        f"http://{ip}:{port}/transfer_request",
                        data=json.dumps(
                            {
                                "id": self.device_id,
                                "name": self.device_name,
                                "filename": fname,
                                "sizeBytes": size,
                            }
                        ).encode("utf-8"),
                        headers={"Content-Type": "application/json"},
                        method="POST",
                    )
                    with urllib.request.urlopen(preq, timeout=28.0) as pr:
                        pdata = json.loads(pr.read().decode("utf-8"))
                        if not pdata.get("allow", False):
                            self.signals.pair_result.emit(False, f"{peer.get('name')} declined transfer", {})
                            return
                        if pdata.get("trusted"):
                            self.set_peer_trusted(pid, True)
                except Exception as exc:
                    self.signals.pair_result.emit(False, f"Receiver did not accept ({exc})", {})
                    return

            import mimetypes
            mime = mimetypes.guess_type(fname)[0] or "image/jpeg"
            try:
                with open(file_path, "rb") as f:
                    data = f.read()
                req = urllib.request.Request(
                    f"http://{ip}:{port}/receive",
                    data=data,
                    headers={
                        "Content-Type": "application/octet-stream",
                        "X-Filename": fname,
                        "X-Mime-Type": mime,
                        "X-Sender-Name": self.device_name,
                        "X-Sender-Id": self.device_id,
                    },
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=30.0) as resp:
                    if resp.status in (200, 201):
                        self.touch_session(pid)
                        if progress_cb:
                            progress_cb(100.0)
                        self.signals.pair_result.emit(True, f"Sent {fname} → {peer.get('name')}", peer)
            except Exception as exc:
                self.signals.pair_result.emit(False, f"Send failed ({exc})", {})

        if sync:
            _sender()
        else:
            threading.Thread(target=_sender, daemon=True).start()

    def _start_http_server(self):
        engine = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def _send_json(self, code: int, obj: dict):
                try:
                    payload = json.dumps(obj).encode("utf-8")
                    self.send_response(code)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                except Exception:
                    pass

            def do_GET(self):
                if self.path.startswith("/ping") or self.path.startswith("/status"):
                    self._send_json(
                        200,
                        {
                            "app": "SuperShare",
                            "id": engine.device_id,
                            "name": engine.device_name,
                            "platform": "Windows",
                            "ip": _get_local_ipv4(),
                            "httpPort": engine.http_port,
                            "connectedIds": list(engine._connected_modes.keys()),
                        },
                    )
                else:
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b"SuperShare VER 2 Ready")

            def do_POST(self):
                length = int(self.headers.get("Content-Length", "0") or 0)
                if self.path.startswith("/pair"):
                    raw = self.rfile.read(min(length, 65536)) if length > 0 else b"{}"
                    info = json.loads(raw.decode("utf-8")) if raw else {}
                    pid = str(info.get("id") or "").strip().upper()
                    pname = str(info.get("name") or pid)
                    peer_ip = str(info.get("ip") or self.client_address[0])
                    pport = int(info.get("httpPort") or 8765)
                    linked = str(info.get("linkedCode") or compute_linked_12_code(engine.device_id, pid))

                    allow = False
                    trusted = pid in engine.trusted_ids
                    if trusted or engine.is_session_active(pid):
                        allow = True
                        engine.touch_session(pid)
                    elif pid:
                        # Receiver must approve a new Normal connect request once!
                        req_id = f"pair_{pid}_{int(time.time() * 1000)}"
                        ev = threading.Event()
                        with engine._lock:
                            engine._pending_decisions[req_id] = {
                                "event": ev,
                                "allow": False,
                                "trust": False,
                                "sender_id": pid,
                            }
                        engine.signals.incoming_prompt.emit(req_id, "pair", pid, pname, 0)
                        ev.wait(timeout=300.0)  # 5 minutes hold limit
                        with engine._lock:
                            res = engine._pending_decisions.pop(req_id, {})
                        allow = bool(res.get("allow", False))
                        trusted = trusted or bool(res.get("trust", False))

                    if allow and pid:
                        mode = "TRUSTED" if trusted else "NORMAL"
                        engine.touch_session(pid)
                        with engine._lock:
                            engine._peers[pid] = {
                                "id": pid,
                                "name": pname,
                                "platform": info.get("platform") or "Phone",
                                "ip": peer_ip,
                                "httpPort": pport,
                                "last_seen": time.time(),
                                "connected": True,
                                "mode": mode,
                                "linked_code": linked,
                            }
                            engine._connected_modes[pid] = mode
                            engine._linked_codes[pid] = linked
                        engine.signals.peers_updated.emit(engine.get_peers_snapshot())
                        engine.signals.session_started.emit(pname, pid)
                        engine.signals.pair_result.emit(True, f"-- CONNECT -- ({format_12_code(linked)})", {})
                        self._send_json(
                            200,
                            {
                                "status": "CONNECTED",
                                "id": engine.device_id,
                                "name": engine.device_name,
                                "platform": "Windows",
                                "httpPort": engine.http_port,
                                "linkedCode": linked,
                                "mode": mode,
                            },
                        )
                    else:
                        self._send_json(200, {"status": "DECLINED"})
                    return

                if self.path.startswith("/session_update"):
                    raw = self.rfile.read(min(length, 4096)) if length > 0 else b"{}"
                    info = json.loads(raw.decode("utf-8")) if raw else {}
                    from_id = str(info.get("id") or "").strip().upper()
                    sess_active = bool(info.get("session_active", True))
                    if from_id:
                        if sess_active:
                            engine.touch_session(from_id)
                            pname = engine._peers.get(from_id, {}).get("name", from_id)
                            engine.signals.session_started.emit(pname, from_id)
                        else:
                            engine.kill_session(from_id)
                        engine.signals.peers_updated.emit(engine.get_peers_snapshot())
                    self._send_json(200, {"status": "OK"})
                    return

                if self.path.startswith("/transfer_request"):
                    raw = self.rfile.read(min(length, 65536)) if length > 0 else b"{}"
                    info = json.loads(raw.decode("utf-8")) if raw else {}
                    pid = str(info.get("id") or "").strip().upper()
                    pname = str(info.get("name") or pid)
                    fname = str(info.get("filename") or "Photo")
                    fsize = int(info.get("sizeBytes") or 0)

                    if pid in engine.trusted_ids or engine._connected_modes.get(pid) == "TRUSTED" or engine.is_session_active(pid):
                        engine.touch_session(pid)
                        self._send_json(200, {"allow": True, "trusted": bool(pid in engine.trusted_ids)})
                        return

                    req_id = f"xfer_{pid}_{int(time.time() * 1000)}"
                    ev = threading.Event()
                    with engine._lock:
                        engine._pending_decisions[req_id] = {
                            "event": ev,
                            "allow": False,
                            "trust": False,
                            "sender_id": pid,
                        }
                    engine.signals.incoming_prompt.emit(req_id, "transfer", pid, f"{pname} · {fname}", fsize)
                    ev.wait(timeout=28.0)
                    with engine._lock:
                        res = engine._pending_decisions.pop(req_id, {})
                    allow = bool(res.get("allow", False))
                    trusted = bool(res.get("trust", False))
                    self._send_json(200, {"allow": allow, "trusted": trusted})
                    return

                if self.path.startswith("/receive"):
                    filename = os.path.basename(self.headers.get("X-Filename") or f"beam_{int(time.time())}.jpg").replace("..", "_")
                    sender_name = self.headers.get("X-Sender-Name") or "Phone"
                    sender_id = (self.headers.get("X-Sender-Id") or "").strip().upper()
                    mime = self.headers.get("X-Mime-Type") or "image/jpeg"

                    os.makedirs(engine.save_dir, exist_ok=True)
                    dest = os.path.join(engine.save_dir, filename)
                    if os.path.exists(dest):
                        stem, ext = os.path.splitext(filename)
                        dest = os.path.join(engine.save_dir, f"{stem}_{int(time.time()) % 10000}{ext}")

                    remaining = length
                    written = 0
                    try:
                        with open(dest, "wb") as f:
                            while remaining > 0:
                                buf = self.rfile.read(min(262144, remaining))
                                if not buf:
                                    break
                                f.write(buf)
                                written += len(buf)
                                remaining -= len(buf)
                    except Exception:
                        self.send_response(500)
                        self.end_headers()
                        return

                    if sender_id and sender_id in engine._peers:
                        engine._peers[sender_id]["last_seen"] = time.time()
                    if sender_id:
                        engine.touch_session(sender_id)
                    engine.signals.file_received.emit(dest, sender_name, written, mime)
                    self._send_json(200, {"status": "SAVED", "path": dest, "bytes": written})
                    return

                self.send_response(404)
                self.end_headers()

        for port in range(HTTP_PORT_START, HTTP_PORT_END + 1):
            try:
                srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
                srv.daemon_threads = True
                self._http_server = srv
                self.http_port = port
                threading.Thread(target=srv.serve_forever, daemon=True).start()
                break
            except Exception:
                continue

    def _udp_beacon_loop(self):
        while self._running:
            self.broadcast_now()
            self.signals.peers_updated.emit(self.get_peers_snapshot())
            time.sleep(1.5)

    def _udp_listener_loop(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("0.0.0.0", UDP_DISCOVERY_PORT))
            sock.settimeout(1.5)
            self._udp_sock = sock
        except Exception:
            return

        my_ip = _get_local_ipv4()
        while self._running:
            try:
                data, addr = sock.recvfrom(4096)
                info = json.loads(data.decode("utf-8"))
                if info.get("app") != "SuperShare":
                    continue
                pid = str(info.get("id") or "").strip().upper()
                peer_ip = str(info.get("ip") or addr[0])
                if not pid or pid == self.device_id.upper() or peer_ip == my_ip or peer_ip.startswith("127."):
                    continue
                with self._lock:
                    is_conn = pid in self._connected_modes
                    mode = "TRUSTED" if pid in self.trusted_ids else self._connected_modes.get(pid, "NORMAL")
                    self._peers[pid] = {
                        "id": pid,
                        "name": info.get("name") or pid,
                        "platform": info.get("platform") or "Device",
                        "ip": peer_ip,
                        "httpPort": int(info.get("httpPort") or 8765),
                        "avatar_id": int(info.get("avatar_id") or 1),
                        "avatar_gradient_idx": int(info.get("avatar_gradient_idx") or 0),
                        "last_seen": time.time(),
                        "connected": is_conn,
                        "mode": mode,
                        "linked_code": self._linked_codes.get(pid, ""),
                    }
                self.signals.peers_updated.emit(self.get_peers_snapshot())
            except socket.timeout:
                continue
            except Exception:
                continue


