# -*- coding: utf-8 -*-
"""
SUPER SHARE: MEMORY SPACE (STORED FILES & MEDIA SHOWCASE)
=========================================================
ARCHITECTURAL MINDMAP & COMPONENT MAP (Modeled 1:1 after MY BOX):
  [1] Header Buttons & Navigation
      ├── Back: CleanBackButton -> routes to Super Share Submenu Hub (SuperShareMenuWindow)
      ├── Home: CleanHeaderIconButton -> routes to Quick Menu (at cursor)
      ├── Brand: Logo + 'MEMORY SPACE' Vector Title (Painted at x=88.0)
      ├── Right Actions: File Count Badge + Open Folder in Explorer + Close Button
  
  [2] Search & Format Switcher Row
      ├── Search Box: Obsidian input with live filter, Lucide search icon & clear button
      └── _FormatModeBar: Minimalist toggle between 'Complete Show' (grid) and 'One-Line Scroll' (horizontal strips)

  [3] Dynamic File Showcase Tiles
      ├── _FramelessFileTile: High-DPI thumbnails (Images/Videos/Docs/Files)
      │    ├── Extension & Size badge
      │    ├── Live clean file name
      │    └── Hover Pill Dock: Open (launch) / Copy (to clipboard) / Delete (file removal)
      └── _HorizontalFileStrip: Smooth mouse-wheel driven horizontal scrolling row

  [4] Layout, Date Grouping & ASMR Transitions
      ├── Groups by date: Today, Yesterday, Specific Date
      └── Smooth ASMR Switch & Pull animations identical to My Box
"""

import os
import sys
import time
import shutil
from datetime import datetime

from PySide6.QtCore import (
    Qt,
    QPoint,
    QRect,
    QRectF,
    QSize,
    QTimer,
    Signal,
    QPropertyAnimation,
    QParallelAnimationGroup,
    QEasingCurve,
)
from PySide6.QtGui import (
    QColor,
    QCursor,
    QFont,
    QFontMetrics,
    QIcon,
    QImage,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
)
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QToolTip,
    QVBoxLayout,
    QWidget,
)

from ui_theme import (
    COMMON_ICONS,
    SLIM_SCROLLBAR_QSS,
    CleanBackButton,
    CleanCloseButton,
    CleanHeaderIconButton,
    format_count_label,
    native_dpr,
    render_common_icon,
)
from .common import (
    BASE_DIR,
    DEFAULT_SAVE_DIR,
    _load_app_logo_pix,
    _draw_vector_brand,
)
from features.super_snap_and_pin.common import _render_lucide_pix


def _draw_crisp_text(p, rect, centered, font, color, text):
    """Render razor-sharp text with native subpixel antialiasing and ClearType font hinting."""
    f = QFont(font)
    f.setStyleStrategy(QFont.PreferQuality)
    p.setFont(f)
    p.setPen(QColor(color))
    flags = (Qt.AlignCenter if centered else (Qt.AlignLeft | Qt.AlignVCenter)) | Qt.TextSingleLine
    p.drawText(rect, flags, text)


def _format_file_size(size_bytes: int) -> str:
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"


class _FormatModeBar(QWidget):
    """Minimalist borderless view toggle: 'complete' (grid) vs 'oneline' (horizontal scroll)."""
    mode_changed = Signal(str)

    def __init__(self, initial_mode="complete", parent=None):
        super().__init__(parent)
        self.mode = initial_mode
        self._hover = None
        self.setFixedSize(68, 34)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)

    def _rect_complete(self):
        return QRectF(0.0, 1.0, 32.0, 32.0)

    def _rect_oneline(self):
        return QRectF(36.0, 1.0, 32.0, 32.0)

    def mouseMoveEvent(self, e):
        pos = e.position()
        nh = "complete" if self._rect_complete().contains(pos) else ("oneline" if self._rect_oneline().contains(pos) else None)
        if nh != self._hover:
            self._hover = nh
            self.setToolTip("Complete Show — display all files nicely" if nh == "complete" else "One-Line Scroll — horizontal timeline row")
            self.update()
        super().mouseMoveEvent(e)

    def leaveEvent(self, e):
        self._hover = None
        self.update()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            pos = e.position()
            new_m = None
            if self._rect_complete().contains(pos):
                new_m = "complete"
            elif self._rect_oneline().contains(pos):
                new_m = "oneline"
            if new_m and new_m != self.mode:
                self.mode = new_m
                self.update()
                self.mode_changed.emit(new_m)
            e.accept()
            return
        super().mousePressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        dpr = native_dpr(self)
        for key, rect, ico in (
            ("complete", self._rect_complete(), "grid"),
            ("oneline", self._rect_oneline(), "oneline"),
        ):
            active = self.mode == key
            hov = self._hover == key
            if hov and not active:
                hp = QPainterPath()
                hp.addRoundedRect(rect.adjusted(2.0, 2.0, -2.0, -2.0), 8.0, 8.0)
                p.fillPath(hp, QColor(255, 255, 255, 16))

            col = "#FFFFFF" if active else ("#D4D4D8" if hov else "#71717A")
            pix = _render_lucide_pix(ico, col, 16, dpr=dpr)
            p.drawPixmap(int(round(rect.center().x() - 8.0)), int(round(rect.center().y() - 9.0)), pix)

            if active:
                bar = QPainterPath()
                bar.addRoundedRect(QRectF(rect.center().x() - 6.0, rect.bottom() - 4.0, 12.0, 2.0), 1.0, 1.0)
                p.fillPath(bar, QColor("#a3e635"))
        p.end()


class _HorizontalFileStrip(QScrollArea):
    """Smooth wheel-enabled single-row horizontal container for One-Line Scroll format."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setFixedHeight(208)
        self.setStyleSheet(SLIM_SCROLLBAR_QSS)
        self.inner = QWidget()
        self.row_lay = QHBoxLayout(self.inner)
        self.row_lay.setContentsMargins(0, 0, 0, 8)
        self.row_lay.setSpacing(18)
        self.row_lay.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.setWidget(self.inner)

    def wheelEvent(self, e):
        sb = self.horizontalScrollBar()
        if sb.maximum() > 0:
            delta = e.angleDelta().y() or e.angleDelta().x()
            sb.setValue(sb.value() - delta)
            e.accept()
            return
        super().wheelEvent(e)


_CURSOR_OUTLINE_ICONS = {
    "super_edit": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z"/></g></svg>',
    "edit_name": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></g></svg>',
    "copy": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></g></svg>',
    "info": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4m0-4h.01"/></g></svg>',
    "delete": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></g></svg>',
}


class _FramelessFileTile(QWidget):
    """
    Open-Canvas Clean Showcase Tile (Matching My Box & Cursor Window aesthetic):
      - Clean standalone rounded thumbnail surface (NO outer container wrapping image & text!)
      - Crisp file title with inline rename support
      - Calm date/time label on bottom line
      - 5 sleek Lucide vector action icons: Open in Super Edit, Edit Name, Copy, Info (i button), Delete
      - Info button shows complete details tooltip (Size, Type, Date, Time) without visual clutter!
    """
    open_clicked = Signal(str)
    super_edit_clicked = Signal(str)
    copy_clicked = Signal(str)
    delete_clicked = Signal(str)
    renamed = Signal(str, str)

    TILE_W = 224
    IMG_H = 132
    TILE_H = 192

    def __init__(self, file_path, dt, file_size, parent=None):
        super().__init__(parent)
        self.file_path = file_path
        self.file_name = os.path.basename(file_path)
        self.dt = dt
        self.file_size = file_size
        self._hover_btn = None
        self._h = 0.0
        self._target_h = 0.0
        self._dpr = native_dpr(self)
        self._rendered_img = self._build_thumbnail(self.file_path, self._dpr)

        self.setFixedSize(self.TILE_W, self.TILE_H)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)

        self._edit_box = QLineEdit(self)
        self._edit_box.setVisible(False)
        self._edit_box.setStyleSheet(
            "QLineEdit { "
            "  background: #14161C; "
            "  color: #FFFFFF; "
            "  border: 1px solid rgba(163, 230, 53, 0.6); "
            "  border-radius: 4px; "
            "  padding: 1px 4px; "
            "  font-size: 11px; "
            "  font-weight: 600; "
            "  font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif; "
            "}"
        )
        self._edit_box.returnPressed.connect(self._commit_rename)
        self._edit_box.editingFinished.connect(self._commit_rename)

        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def _build_thumbnail(self, fp, dpr):
        ext = os.path.splitext(fp)[1].lower()
        if ext in (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"):
            try:
                img = QImage(fp)
                if not img.isNull():
                    tw = int(round(self.TILE_W * dpr))
                    th = int(round(self.IMG_H * dpr))
                    scaled = img.scaled(tw, th, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                    sx = max(0, (scaled.width() - tw) // 2)
                    sy = max(0, (scaled.height() - th) // 2)
                    cropped = scaled.copy(sx, sy, tw, th)
                    pix = QPixmap.fromImage(cropped)
                    pix.setDevicePixelRatio(dpr)
                    return pix
            except Exception:
                pass
        return None

    def _step(self):
        diff = self._target_h - self._h
        if abs(diff) > 0.005:
            self._h += diff * 0.25
            self.update()
        else:
            self._h = self._target_h
            self.update()
            self._timer.stop()

    def enterEvent(self, e):
        self._target_h = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target_h = 0.0
        self._hover_btn = None
        QToolTip.hideText()
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def _action_rects(self):
        w = float(self.width())
        y = float(self.IMG_H) + 31.0
        return {
            "super_edit": QRectF(w - 126.0, y, 22.0, 22.0),
            "edit_name":  QRectF(w - 101.0, y, 22.0, 22.0),
            "copy":       QRectF(w - 76.0,  y, 22.0, 22.0),
            "info":       QRectF(w - 51.0,  y, 22.0, 22.0),
            "delete":     QRectF(w - 26.0,  y, 22.0, 22.0),
        }

    def mouseMoveEvent(self, e):
        pos = e.position()
        acts = self._action_rects() if self._h > 0.1 else {}
        nh = None
        for k, r in acts.items():
            if r.contains(pos):
                nh = k
                break
        if nh != self._hover_btn:
            self._hover_btn = nh
            if nh == "info":
                ext = os.path.splitext(self.file_path)[1].upper().replace(".", "") or "FILE"
                sz_str = _format_file_size(self.file_size)
                d_str = self.dt.strftime('%B %d, %Y')
                t_str = self.dt.strftime('%I:%M:%S %p')
                tip = (
                    "<table style='font-family: Segoe UI, sans-serif; font-size: 11.5px; color: #FFFFFF; line-height: 1.5;'>"
                    f"<tr><td colspan='2' style='font-size: 12.5px; font-weight: 700; color: #A3E635; padding-bottom: 4px;'>{self.file_name}</td></tr>"
                    f"<tr><td style='color: #8E95A2; padding-right: 12px;'>Type:</td><td style='font-weight: 600;'>{ext} File</td></tr>"
                    f"<tr><td style='color: #8E95A2; padding-right: 12px;'>Size:</td><td style='font-weight: 600; color: #E2E8F0;'>{sz_str}</td></tr>"
                    f"<tr><td style='color: #8E95A2; padding-right: 12px;'>Date:</td><td style='font-weight: 600;'>{d_str}</td></tr>"
                    f"<tr><td style='color: #8E95A2; padding-right: 12px;'>Time:</td><td style='font-weight: 600;'>{t_str}</td></tr>"
                    "</table>"
                )
                QToolTip.showText(QCursor.pos(), tip, self)
            else:
                QToolTip.hideText()
                if nh == "super_edit":
                    self.setToolTip("Open in Super Edit")
                elif nh == "edit_name":
                    self.setToolTip("Rename File")
                elif nh == "copy":
                    self.setToolTip("Copy File to Clipboard")
                elif nh == "delete":
                    self.setToolTip("Delete File")
                else:
                    self.setToolTip("")
            self.update()
        super().mouseMoveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            acts = self._action_rects()
            pos = e.position()
            for k, r in acts.items():
                if r.contains(pos):
                    if k == "super_edit":
                        self.super_edit_clicked.emit(self.file_path)
                    elif k == "edit_name":
                        self._start_rename()
                    elif k == "copy":
                        self.copy_clicked.emit(self.file_path)
                    elif k == "info":
                        pass
                    elif k == "delete":
                        self.delete_clicked.emit(self.file_path)
                    e.accept()
                    return
            img_rect = QRectF(0.5, 0.5, float(self.width()) - 1.0, float(self.IMG_H) - 1.0)
            if img_rect.contains(pos):
                self.open_clicked.emit(self.file_path)
                e.accept()
                return
        super().mousePressEvent(e)

    def _start_rename(self):
        w = float(self.width())
        self._edit_box.setGeometry(2, int(self.IMG_H + 6), int(w - 4), 22)
        self._edit_box.setText(self.file_name)
        self._edit_box.setVisible(True)
        self._edit_box.selectAll()
        self._edit_box.setFocus()

    def _commit_rename(self):
        if not self._edit_box.isVisible():
            return
        new_name = self._edit_box.text().strip()
        self._edit_box.setVisible(False)
        if new_name and new_name != self.file_name:
            try:
                old_dir = os.path.dirname(self.file_path)
                new_path = os.path.join(old_dir, new_name)
                os.rename(self.file_path, new_path)
                old_path = self.file_path
                self.file_path = new_path
                self.file_name = new_name
                self.renamed.emit(old_path, new_path)
            except Exception:
                pass
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w = float(self.width())
        hv = self._h
        dpr = native_dpr(self)

        # 1. Pure Standalone Rounded Thumbnail Surface (NO outer container wrapping details!)
        img_rect = QRectF(0.5, 0.5, w - 1.0, float(self.IMG_H) - 1.0)
        img_path = QPainterPath()
        img_path.addRoundedRect(img_rect, 10.0, 10.0)

        p.save()
        p.setClipPath(img_path)
        if self._rendered_img and not self._rendered_img.isNull():
            p.drawPixmap(0, 0, self._rendered_img)
        else:
            p.fillPath(img_path, QColor(14, 15, 19))
            ext = os.path.splitext(self.file_path)[1].upper().replace(".", "") or "FILE"
            ico = render_common_icon("folder", "#A3E635", size_px=36, dpr=dpr)
            if not ico.isNull():
                cx = img_rect.center().x() - (ico.width() / dpr) * 0.5
                cy = img_rect.center().y() - (ico.height() / dpr) * 0.5 - 6.0
                p.drawPixmap(int(round(cx)), int(round(cy)), ico)
            badge_f = QFont("Segoe UI Variable Text", 8.5)
            badge_f.setStyleStrategy(QFont.PreferQuality)
            badge_r = QRectF(0.0, img_rect.center().y() + 14.0, w, 18.0)
            _draw_crisp_text(p, badge_r, True, badge_f, QColor("#A1A7B3"), f".{ext}")
        p.restore()

        # Cyber-lime hover border perimeter only around the thumbnail
        rim_col = QColor(163, 230, 53, int(150 * hv)) if hv > 0.1 else QColor(255, 255, 255, 20)
        p.setPen(QPen(rim_col, 1.0))
        p.drawPath(img_path)

        # 2. File Name on Open Canvas below Image
        bot_y = float(self.IMG_H) + 8.0
        if not self._edit_box.isVisible():
            f_name = QFont("Segoe UI Variable Text")
            f_name.setPointSizeF(9.4)
            f_name.setWeight(QFont.DemiBold)
            f_name.setStyleStrategy(QFont.PreferQuality)
            fm = QFontMetrics(f_name)
            name_rect = QRectF(2.0, bot_y, w - 4.0, 18.0)
            elided_name = fm.elidedText(self.file_name, Qt.ElideMiddle, int(name_rect.width()))
            p.setFont(f_name)
            p.setPen(QColor("#FFFFFF") if hv > 0.2 else QColor("#EDEDEF"))
            p.drawText(name_rect, Qt.AlignLeft | Qt.AlignVCenter | Qt.TextSingleLine, elided_name)

        # 3. Bottom Strip: Calm Date Left + 5 Sleek Vector Icons Right (Icons reveal on hover)
        time_y = float(self.IMG_H) + 32.0
        f_time = QFont("Segoe UI Variable Display")
        f_time.setPointSizeF(9.6)
        f_time.setWeight(QFont.DemiBold)
        f_time.setStyleStrategy(QFont.PreferQuality)
        time_str = self.dt.strftime("%I:%M %p")
        time_rect = QRectF(2.0, time_y, w - 134.0, 22.0)
        p.setFont(f_time)
        p.setPen(QColor("#CBD5E1") if hv > 0.2 else QColor("#94A3B8"))
        p.drawText(time_rect, Qt.AlignLeft | Qt.AlignVCenter | Qt.TextSingleLine, time_str)

        # 4. 5 Sleek Vector Action Icons (Smoothly reveal on hover)
        if hv > 0.05:
            p.save()
            p.setOpacity(min(1.0, hv * 1.3))
            acts = self._action_rects()
            buttons_spec = (
                ("super_edit", acts["super_edit"], _CURSOR_OUTLINE_ICONS["super_edit"], "#94A3B8", "#A3E635", QColor(163, 230, 53, 30)),
                ("edit_name",  acts["edit_name"],  _CURSOR_OUTLINE_ICONS["edit_name"],  "#94A3B8", "#FFFFFF", QColor(255, 255, 255, 24)),
                ("copy",       acts["copy"],       _CURSOR_OUTLINE_ICONS["copy"],       "#94A3B8", "#A3E635", QColor(163, 230, 53, 30)),
                ("info",       acts["info"],       _CURSOR_OUTLINE_ICONS["info"],       "#94A3B8", "#60A5FA", QColor(96, 165, 250, 30)),
                ("delete",     acts["delete"],     _CURSOR_OUTLINE_ICONS["delete"],     "#94A3B8", "#F87171", QColor(248, 113, 113, 32)),
            )
            for key, rect, svg, col_idle, col_hov, bg_hov in buttons_spec:
                active = self._hover_btn == key
                if active:
                    bp = QPainterPath()
                    bp.addRoundedRect(rect, 5.0, 5.0)
                    p.fillPath(bp, bg_hov)
                col = col_hov if active else col_idle
                pix = render_common_icon(svg, col, 15, dpr=dpr)
                cx = rect.center().x() - (pix.width() / dpr) * 0.5
                cy = rect.center().y() - (pix.height() / dpr) * 0.5
                p.drawPixmap(int(round(cx)), int(round(cy)), pix)
            p.restore()

        p.end()


class _MemorySpaceBrandTitle(QWidget):
    """Vector-crisp brand title: Logo (20px) + 'THE' (White) + 'MEMORY SPACE' (#FFFF00->#00FF85 gradient)."""
    def __init__(self, logo_pix=None, parent=None):
        super().__init__(parent)
        self.logo_pix = logo_pix
        self.setFixedHeight(30)
        self.setFixedWidth(280)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        bx = 0.0
        by_c = float(self.height()) * 0.5
        if self.logo_pix and not self.logo_pix.isNull():
            ldpr = max(1.0, float(self.logo_pix.devicePixelRatio() or 1.0))
            lw = self.logo_pix.width() / ldpr
            lh = self.logo_pix.height() / ldpr
            p.drawPixmap(int(round(bx)), int(round(by_c - lh * 0.5)), self.logo_pix)
            bx += lw + 8.0

        f_logo = QFont("Segoe UI Variable")
        f_logo.setStyleName("Display Bold")
        f_logo.setPointSizeF(11.4)
        f_logo.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
        f_logo.setHintingPreference(QFont.PreferNoHinting)

        probe = QPainterPath()
        probe.addText(0.0, 0.0, f_logo, "THE MEMORY SPACE")
        br = probe.boundingRect()
        baseline_y = by_c - (br.top() + br.height() * 0.5)

        p1 = QPainterPath()
        p1.addText(bx, baseline_y, f_logo, "THE")
        p.fillPath(p1, QColor("#FFFFFF"))

        w1 = p1.boundingRect().width()
        smx = bx + w1 + 5.5

        p2 = QPainterPath()
        p2.addText(smx, baseline_y, f_logo, "MEMORY SPACE")
        b2 = p2.boundingRect()
        g_sm = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
        g_sm.setColorAt(0.0, QColor("#FFFF00"))
        g_sm.setColorAt(1.0, QColor("#00FF85"))
        p.fillPath(p2, g_sm)
        p.end()


class SuperShareStoredWindow(QWidget):
    """
    MEMORY SPACE Showcase Window modeled 1:1 after MY BOX:
      - Header navigation: Back, Main Menu, vector 'MEMORY SPACE' brand, Open Folder, Count Badge, Close
      - Real-time search bar + Format Switcher (Complete Show vs One-Line Scroll)
      - Frameless sharp file cards with live thumbnails, size badges & hover action dock (Open/Copy/Delete)
    """

    def __init__(self, engine, on_back_to_menu=None, on_back_to_share_menu=None, on_open_devices=None, on_open_settings=None, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.on_back_to_menu = on_back_to_menu
        self.on_back_to_share_menu = on_back_to_share_menu
        self.on_main_menu = on_back_to_menu
        self.on_open_devices = on_open_devices
        self.on_open_settings = on_open_settings
        self.view_mode = "complete"

        self._dragging = False
        self._drag_offset = QPoint()

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.resize(766, 588)

        from ui_theme import apply_window_identity
        apply_window_identity(self, "TheSuperMouse - Memory Space")

        self.logo_pix = _load_app_logo_pix(self)
        self._build_ui()
        self.refresh_gallery()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # 1. Header Navigation Bar (Brand on left, tools & navigation on right, Cross last!)
        header = QWidget(self)
        header.setFixedHeight(54)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(16, 0, 14, 0)
        hdr.setSpacing(4)

        self.brand_title = _MemorySpaceBrandTitle(self.logo_pix, header)
        hdr.addWidget(self.brand_title, alignment=Qt.AlignVCenter)

        hdr.addStretch(1)

        self.lbl_count = QLabel("0 Files", header)
        self.lbl_count.setStyleSheet(
            "color: #848A95; background: transparent; border: none; "
            "padding: 2px 6px; font-size: 11px; font-weight: 600; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        hdr.addWidget(self.lbl_count, alignment=Qt.AlignVCenter)
        hdr.addSpacing(2)

        self.btn_dir = CleanHeaderIconButton("folder", "Open Folder in Explorer", box_size=32, icon_size=16, parent=header)
        self.btn_dir.clicked.connect(self._open_folder)
        hdr.addWidget(self.btn_dir, alignment=Qt.AlignVCenter)
        hdr.addSpacing(2)

        self.btn_back = CleanBackButton("Back to Super Share", box_size=32, icon_size=16, parent=header)
        self.btn_back.clicked.connect(self._go_back)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)

        self.btn_menu = CleanHeaderIconButton("home", "Main Menu", box_size=32, icon_size=16, parent=header)
        self.btn_menu.clicked.connect(self._go_menu)
        hdr.addWidget(self.btn_menu, alignment=Qt.AlignVCenter)

        self.btn_close = CleanCloseButton("Close Memory Space", box_size=32, icon_size=16, parent=header)
        self.btn_close.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(self.btn_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        # 2. Search + Borderless View Mode Icons Row (Device Hub Search Bar Style)
        ctrl_wrap = QWidget(self)
        ctrl_wrap.setFixedHeight(50)
        cw_lay = QHBoxLayout(ctrl_wrap)
        cw_lay.setContentsMargins(18, 4, 18, 10)
        cw_lay.setSpacing(10)

        self.search_box = QFrame(ctrl_wrap)
        self.search_box.setFixedHeight(38)
        self.search_box.setAttribute(Qt.WA_StyledBackground, True)
        self.search_box.setStyleSheet(
            "QFrame { "
            "  background: #0E1013; "
            "  border: 1px solid rgba(255, 255, 255, 0.08); "
            "  border-radius: 19px; "
            "} "
            "QFrame:focus-within { "
            "  border-color: rgba(163, 230, 53, 0.55); "
            "}"
        )
        sb_lay = QHBoxLayout(self.search_box)
        sb_lay.setContentsMargins(4, 0, 8, 0)
        sb_lay.setSpacing(8)

        # Device Hub style circular green badge at start (left) with crisp dark search icon
        self.search_circle = QLabel(self.search_box)
        self.search_circle.setFixedSize(30, 30)
        self.search_circle.setAlignment(Qt.AlignCenter)
        self.search_circle.setStyleSheet("background-color: #a3e635; border-radius: 15px; border: none;")
        s_pix = render_common_icon("search", "#040405", 14, dpr=native_dpr(self))
        self.search_circle.setPixmap(s_pix)
        sb_lay.addWidget(self.search_circle, alignment=Qt.AlignVCenter)

        self.search_input = QLineEdit(self.search_box)
        self.search_input.setAttribute(Qt.WA_StyledBackground, True)
        self.search_input.setPlaceholderText("Search received files by name, type, Today, Yesterday...")
        f_in = QFont("Segoe UI Variable Text", 9)
        f_in.setStyleStrategy(QFont.PreferQuality)
        self.search_input.setFont(f_in)
        self.search_input.setStyleSheet(
            "QLineEdit { "
            "  background: transparent; "
            "  border: none; "
            "  color: #FFFFFF; "
            "  font-size: 11.5px; "
            "  font-weight: 600; "
            "  font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif; "
            "} "
            "QLineEdit::placeholder { "
            "  color: #A1A1AA; "
            "  font-weight: 500; "
            "}"
        )
        self.search_input.textChanged.connect(self._on_search_changed)
        sb_lay.addWidget(self.search_input, stretch=1)

        self.btn_clear_search = QPushButton("", self.search_box)
        self.btn_clear_search.setFixedSize(22, 22)
        self.btn_clear_search.setIcon(QIcon(render_common_icon("close", "#A1A7B3", 12, dpr=native_dpr(self))))
        self.btn_clear_search.setIconSize(QSize(12, 12))
        self.btn_clear_search.setCursor(Qt.PointingHandCursor)
        self.btn_clear_search.setVisible(False)
        self.btn_clear_search.setStyleSheet(
            "QPushButton { background: rgba(255, 255, 255, 0.08); border: none; border-radius: 11px; } "
            "QPushButton:hover { background: rgba(255, 255, 255, 0.18); }"
        )
        self.btn_clear_search.clicked.connect(lambda: self.search_input.setText(""))
        sb_lay.addWidget(self.btn_clear_search, alignment=Qt.AlignVCenter)
        cw_lay.addWidget(self.search_box, stretch=1)

        self.mode_bar = _FormatModeBar(initial_mode=self.view_mode, parent=ctrl_wrap)
        self.mode_bar.mode_changed.connect(self._on_mode_changed)
        cw_lay.addWidget(self.mode_bar)

        root.addWidget(ctrl_wrap)

        # 3. Media Showcase Scroll Container
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet(SLIM_SCROLLBAR_QSS)

        self.content = QWidget()
        self.content_lay = QVBoxLayout(self.content)
        self.content_lay.setContentsMargins(18, 10, 18, 14)
        self.content_lay.setSpacing(10)
        self.content_lay.setAlignment(Qt.AlignTop)
        self.scroll.setWidget(self.content)
        root.addWidget(self.scroll, stretch=1)

    def _open_folder(self):
        save_dir = getattr(self.engine, "save_dir", DEFAULT_SAVE_DIR)
        os.makedirs(save_dir, exist_ok=True)
        os.startfile(save_dir)

    def _go_back(self):
        target = getattr(self, "on_back_to_share_menu", None) or self.on_back_to_menu
        if callable(target):
            self.switch_out_asmr_animation(on_finished=target)
        else:
            self.close_with_pull_animation()

    def _go_menu(self):
        target = getattr(self, "on_main_menu", None) or self.on_back_to_menu
        if callable(target):
            self.switch_out_asmr_animation(on_finished=target)
        else:
            self.close_with_pull_animation()

    def _on_mode_changed(self, mode):
        self.view_mode = mode
        self.refresh_gallery(self.search_input.text())

    def _on_search_changed(self, text):
        self.btn_clear_search.setVisible(bool(text.strip()))
        self.refresh_gallery(text)

    def _date_heading(self, dt: datetime) -> str:
        d = dt.date()
        today = datetime.now().date()
        if d == today:
            return f"TODAY, {dt.strftime('%b %d, %Y').upper()}"
        yesterday = today.replace(day=today.day - 1) if today.day > 1 else None
        if yesterday and d == yesterday:
            return f"YESTERDAY, {dt.strftime('%b %d, %Y').upper()}"
        return dt.strftime("%B %d, %Y").upper()

    def _open_in_super_edit(self, fp):
        try:
            os.startfile(fp)
        except Exception:
            pass

    def _on_copy_file(self, fp):
        from PySide6.QtCore import QMimeData, QUrl
        md = QMimeData()
        md.setUrls([QUrl.fromLocalFile(fp)])
        ext = os.path.splitext(fp)[1].lower()
        if ext in (".png", ".jpg", ".jpeg", ".webp", ".bmp"):
            img = QImage(fp)
            if not img.isNull():
                md.setImageData(img)
        QApplication.clipboard().setMimeData(md)

    def _on_delete_file(self, fp):
        try:
            if os.path.exists(fp):
                os.remove(fp)
            self.refresh_gallery(self.search_input.text())
        except Exception:
            pass

    def refresh_gallery(self, query=""):
        while self.content_lay.count():
            it = self.content_lay.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)
                w.deleteLater()

        save_dir = getattr(self.engine, "save_dir", DEFAULT_SAVE_DIR)
        os.makedirs(save_dir, exist_ok=True)

        files = []
        try:
            for fn in os.listdir(save_dir):
                if fn.startswith("."):
                    continue
                fp = os.path.join(save_dir, fn)
                if os.path.isfile(fp):
                    if query and query.lower() not in fn.lower():
                        continue
                    stat = os.stat(fp)
                    dt = datetime.fromtimestamp(stat.st_mtime)
                    files.append((fp, fn, dt, stat.st_size))
        except Exception:
            pass

        files.sort(key=lambda x: x[2], reverse=True)
        self.lbl_count.setText(format_count_label(len(files), "File", "Files"))

        if not files:
            empty = QLabel("No received files found in Memory Space", self.content)
            empty.setAlignment(Qt.AlignCenter)
            empty.setStyleSheet("color: #71717A; font-size: 13px; font-weight: 500; padding: 60px 0;")
            self.content_lay.addWidget(empty)
            return

        group_map = {}
        for item in files:
            lbl = self._date_heading(item[2])
            group_map.setdefault(lbl, []).append(item)

        for gl, group_files in group_map.items():
            sec = QWidget(self.content)
            sl = QVBoxLayout(sec)
            sl.setContentsMargins(0, 0, 0, 2)
            sl.setSpacing(10)

            # Clean Editorial Date Header (Today / Yesterday / Date) matching My Box
            hdr_row = QHBoxLayout()
            hdr_row.setSpacing(10)
            lbl_g = QLabel(gl, sec)
            lbl_g.setStyleSheet(
                "color: #FFFFFF; font-size: 17px; font-weight: 800; letter-spacing: 0.4px; "
                "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; background: transparent;"
            )
            hdr_row.addWidget(lbl_g)

            cnt_lbl = QLabel(format_count_label(len(group_files), "file", "files"), sec)
            cnt_lbl.setStyleSheet(
                "color: #94A3B8; background: transparent; border: none; "
                "font-size: 13px; font-weight: 600; "
                "font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif;"
            )
            hdr_row.addWidget(cnt_lbl)
            hdr_row.addStretch(1)
            sl.addLayout(hdr_row)

            if self.view_mode == "oneline":
                strip = _HorizontalFileStrip(sec)
                for it in group_files:
                    tile = _FramelessFileTile(it[0], it[2], it[3], strip.inner)
                    tile.open_clicked.connect(lambda p: os.startfile(p))
                    tile.super_edit_clicked.connect(self._open_in_super_edit)
                    tile.copy_clicked.connect(self._on_copy_file)
                    tile.delete_clicked.connect(self._on_delete_file)
                    tile.renamed.connect(lambda old_p, new_p: self.refresh_gallery(self.search_input.text()))
                    strip.row_lay.addWidget(tile)
                sl.addWidget(strip)
            else:
                grid_wrap = QWidget(sec)
                g_lay = QVBoxLayout(grid_wrap)
                g_lay.setContentsMargins(0, 0, 0, 0)
                g_lay.setSpacing(16)

                cols = 3
                row_widget = None
                r_lay = None
                for idx, it in enumerate(group_files):
                    if idx % cols == 0:
                        row_widget = QWidget(grid_wrap)
                        r_lay = QHBoxLayout(row_widget)
                        r_lay.setContentsMargins(0, 0, 0, 0)
                        r_lay.setSpacing(18)
                        r_lay.setAlignment(Qt.AlignLeft)
                        g_lay.addWidget(row_widget)
                    tile = _FramelessFileTile(it[0], it[2], it[3], row_widget)
                    tile.open_clicked.connect(lambda p: os.startfile(p))
                    tile.super_edit_clicked.connect(self._open_in_super_edit)
                    tile.copy_clicked.connect(self._on_copy_file)
                    tile.delete_clicked.connect(self._on_delete_file)
                    tile.renamed.connect(lambda old_p, new_p: self.refresh_gallery(self.search_input.text()))
                    if r_lay:
                        r_lay.addWidget(tile)
                sl.addWidget(grid_wrap)

            self.content_lay.addWidget(sec)

    def open_window(self):
        self.refresh_gallery(self.search_input.text())
        self._center_or_cursor()
        self.show()
        self.raise_()
        self.activateWindow()

    def open_asmr_switch(self):
        self.refresh_gallery(self.search_input.text())
        self._center_or_cursor()
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(135)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        af.start()
        self._anim = af

    def switch_out_asmr_animation(self, on_finished=None):
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        def _done():
            self.hide()
            if on_finished:
                on_finished()

        af.finished.connect(_done)
        af.start()
        self._anim = af

    def close_with_pull_animation(self, on_finished=None):
        if not self.isVisible():
            if on_finished:
                on_finished()
            return

        screen = QApplication.screenAt(self.pos()) or QApplication.primaryScreen()
        full = screen.geometry()
        curr = self.geometry()
        end_geom = QRect(curr.x(), full.bottom() + 15, curr.width(), curr.height())

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(280)
        ag.setStartValue(curr)
        ag.setEndValue(end_geom)
        ag.setEasingCurve(QEasingCurve.InCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(250)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.InCubic)

        group = QParallelAnimationGroup(self)
        group.addAnimation(ag)
        group.addAnimation(af)

        def _done():
            self.hide()
            if on_finished:
                on_finished()

        group.finished.connect(_done)
        group.start()
        self._pull_anim = group

    def _center_or_cursor(self):
        scr = (QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry()
        w, h = self.width(), self.height()
        tx = max(scr.left() + 20, min(scr.right() - w - 20, scr.center().x() - w // 2))
        ty = max(scr.top() + 20, min(scr.bottom() - h - 20, scr.center().y() - h // 2))
        self.setGeometry(tx, ty, w, h)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 54.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
            return
        elif e.button() == Qt.RightButton:
            self.close_with_pull_animation()
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        card = QPainterPath()
        card.addRoundedRect(rect, 14.0, 14.0)

        p.fillPath(card, QColor(4, 4, 5, 254))
        p.setPen(QPen(QColor(255, 255, 255, 32), 1.0))
        p.drawPath(card)
        p.end()
