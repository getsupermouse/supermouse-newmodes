# -*- coding: utf-8 -*-
"""
SUPER CLIPBOARD / SUPER SNAP & PIN - MODULAR RE-EXPORT SHIM
===========================================================
Modularized into package 'super_snap_and_pin/':
- take_snap.py (Snip overlay & capture)
- markup_editor.py (Annotation editor & tools)
- my_box.py (My Box saved snaps gallery)
- pin_window.py (Floating pin lightbox)
- text_extractor.py (Text extractor module)
- store_text.py (Store text module)
- window.py (SuperClipboardWindow)
"""
from super_snap_and_pin import *
from super_snap_and_pin.common import *
