# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE — PatchChecker & SHA-256 Delta Updater Engine
  - Checks GitHub Releases version.json silently once daily at 7:00 PM IST (UTC+5:30).
  - Supports SHA-256 diff manifests: add, replace, delete, skip.
  - Downloads patch zip with live progress, verifies SHA-256, swaps files cleanly, and restarts.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import urllib.request
import zipfile
from datetime import datetime, timedelta, timezone

from PySide6.QtCore import QObject, QTimer, Signal

CURRENT_APP_VERSION = "1.02"
IST_TZ = timezone(timedelta(hours=5, minutes=30))

# Official version.json URL on GitHub
DEFAULT_MANIFEST_URL = "https://api.github.com/repos/getsupermouse/supermousenewnupdates/contents/updates/version.json"

DEMO_PREVIEW_MODE = False
DEMO_FAKE_REMOTE = {"version": CURRENT_APP_VERSION, "date": "", "updates": []}


def _app_root_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _state_dir() -> str:
    base = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "TheSuperMouse")
    os.makedirs(base, exist_ok=True)
    return base


def _config_path() -> str:
    return os.path.join(_state_dir(), "patch_checker_state.json")


def _parse_version(v: str):
    parts = []
    for tok in str(v or "0").strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in tok if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def compute_sha256(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest().lower()


class PatchChecker(QObject):
    """Daily 7:00 PM IST GitHub PatchChecker + Safe SHA-256 Patch Applier."""

    status_changed = Signal(dict)
    download_progress = Signal(int, str)
    update_finished = Signal(bool, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._lock = threading.Lock()
        self._checking = False
        self._installing = False
        self._demo_installed_versions: set[str] = set()
        self._state = self._load_state()
        self._status = self._build_initial_status()

        # Check periodically every 30 minutes for updates from GitHub
        self._periodic_timer = QTimer(self)
        self._periodic_timer.setInterval(30 * 60 * 1000)
        self._periodic_timer.timeout.connect(lambda: self.check_now(mark_daily_slot=False))
        self._periodic_timer.start()

        # Instant check 4s after launch so users get new updates immediately without waiting
        QTimer.singleShot(4000, lambda: self.check_now(mark_daily_slot=False))

    def _load_state(self) -> dict:
        fp = _config_path()
        data = {}
        if os.path.exists(fp):
            try:
                with open(fp, "r", encoding="utf-8-sig") as f:
                    data = json.load(f) or {}
            except Exception:
                data = {}
        # Force migrate stale Netlify or placeholder URLs to the live official GitHub manifest
        cur_url = str(data.get("manifest_url") or "").strip()
        if not cur_url or "netlify.app" in cur_url or "YOUR_GITHUB_USERNAME" in cur_url or "supermousenewnupdates" in cur_url or "thesupermouse-releases" in cur_url:
            data["manifest_url"] = DEFAULT_MANIFEST_URL
        data.setdefault("installed_version", self._read_local_version())
        data.setdefault("last_checked_ist_date", "")
        data.setdefault("last_checked_display", "Scheduled daily · 7:00 PM IST")
        data.setdefault("cached_remote", None)
        return data

    def _save_state(self):
        try:
            with open(_config_path(), "w", encoding="utf-8") as f:
                json.dump(self._state, f, indent=2)
        except Exception:
            pass

    def _read_local_version(self) -> str:
        ver_file = os.path.join(_app_root_dir(), "version.json")
        if os.path.exists(ver_file):
            try:
                with open(ver_file, "r", encoding="utf-8") as f:
                    v = (json.load(f) or {}).get("version")
                    if v:
                        return str(v)
            except Exception:
                pass
        return CURRENT_APP_VERSION

    def _get_demo_remote(self) -> dict | None:
        if not DEMO_PREVIEW_MODE:
            return None
        remaining = [
            u for u in DEMO_FAKE_REMOTE["updates"]
            if str(u.get("version")) not in self._demo_installed_versions
        ]
        if not remaining:
            return None
        return {
            "version": remaining[-1]["version"],
            "date": DEMO_FAKE_REMOTE["date"],
            "updates": remaining,
        }

    def _build_initial_status(self) -> dict:
        local_v = self._read_local_version()
        url = self._state.get("manifest_url") or DEFAULT_MANIFEST_URL
        if "YOUR_GITHUB_USERNAME" in url or "github.com" in url:
            url = DEFAULT_MANIFEST_URL
            self._state["manifest_url"] = url
        remote = self._state.get("cached_remote")
        return self._evaluate_remote(local_v, remote)

    def _parse_mb(self, val) -> float:
        if isinstance(val, (int, float)):
            return round(float(val), 2)
        s = str(val or "0").upper().replace("MB", "").strip()
        try:
            return round(float(s), 2)
        except Exception:
            return 0.0

    def _evaluate_remote(self, local_v: str, remote: dict | None, error: str = "") -> dict:
        base = {
            "current_version": local_v,
            "latest_version": local_v,
            "pending_count": 0,
            "has_update": False,
            "headline": "You are up-to-date",
            "subtext": "THE SUPER MOUSE is synced with the latest build. PatchChecker checks GitHub automatically when online.",
            "size_mb": "0 MB",
            "total_size_mb": 0.0,
            "date": datetime.now(IST_TZ).strftime("%d %b %Y"),
            "updates": [],
            "patch_url": "",
            "full_url": "",
            "add": [],
            "replace": [],
            "delete": [],
            "skip_count": 0,
            "sha256": {},
            "last_checked": self._state.get("last_checked_display", "Scheduled daily · 7:00 PM IST"),
            "checking": self._checking,
            "installing": self._installing,
            "error": error,
        }
        if not isinstance(remote, dict):
            return base

        remote_v = str(remote.get("version") or local_v)
        # Unified v1.02 baseline
        is_newer = _parse_version(remote_v) > _parse_version(local_v)
        raw_list = remote.get("updates")
        pending_items = []

        if isinstance(raw_list, list) and raw_list:
            for item in raw_list:
                if not isinstance(item, dict):
                    continue
                iv = str(item.get("version") or remote_v)
                if _parse_version(iv) <= _parse_version(local_v):
                    continue
                sz = self._parse_mb(item.get("size_mb"))
                pending_items.append({
                        "version": iv,
                        "headline": str(item.get("headline") or item.get("title") or f"Update v{iv}"),
                        "subtext": str(item.get("subtext") or item.get("summary") or "Bug fixes and improvements."),
                        "date": str(item.get("date") or remote.get("date") or datetime.now(IST_TZ).strftime("%d %b %Y")),
                        "size_mb": sz,
                        "patch_url": str(item.get("patch_url") or remote.get("patch_url") or ""),
                        "full_url": str(item.get("full_url") or remote.get("full_url") or ""),
                        "add": list(item.get("add") or remote.get("add") or []),
                        "replace": list(item.get("replace") or remote.get("replace") or []),
                        "delete": list(item.get("delete") or remote.get("delete") or []),
                        "sha256": dict(item.get("sha256") or remote.get("sha256") or {}),
                    })
        elif is_newer:
            sz = self._parse_mb(remote.get("size_mb"))
            pending_items.append({
                "version": remote_v,
                "headline": str(remote.get("headline") or f"Update v{remote_v}"),
                "subtext": str(remote.get("subtext") or "Performance upgrades and bug fixes."),
                "date": str(remote.get("date") or datetime.now(IST_TZ).strftime("%d %b %Y")),
                "size_mb": sz,
                "patch_url": str(remote.get("patch_url") or ""),
                "full_url": str(remote.get("full_url") or ""),
                "add": list(remote.get("add") or []),
                "replace": list(remote.get("replace") or []),
                "delete": list(remote.get("delete") or []),
                "sha256": dict(remote.get("sha256") or {}),
            })

        if pending_items:
            total_mb = round(sum(x["size_mb"] for x in pending_items), 2)
            top = pending_items[0]
            base.update({
                "latest_version": pending_items[-1]["version"],
                "pending_count": len(pending_items),
                "has_update": True,
                "updates": pending_items,
                "total_size_mb": total_mb,
                "headline": top["headline"],
                "subtext": top["subtext"],
                "size_mb": f"{total_mb:g} MB",
                "date": top["date"],
                "patch_url": top["patch_url"],
                "full_url": top["full_url"],
                "add": top["add"],
                "replace": top["replace"],
                "delete": top["delete"],
                "skip_count": int(remote.get("skip_count") or 0),
                "sha256": top["sha256"],
            })
        return base

    def get_status(self) -> dict:
        with self._lock:
            return dict(self._status)

    def _check_daily_ist_schedule(self):
        """Triggers automatically once daily at or after 7:00 PM IST (19:00)."""
        now_ist = datetime.now(IST_TZ)
        today_str = now_ist.strftime("%Y-%m-%d")
        if now_ist.hour >= 19 and self._state.get("last_checked_ist_date") != today_str:
            self.check_now(mark_daily_slot=True)

    def check_now(self, mark_daily_slot: bool = False):
        with self._lock:
            if self._checking or self._installing:
                return
            self._checking = True
            self._status["checking"] = True
            self._status["error"] = ""
            snap = dict(self._status)
        self.status_changed.emit(snap)

        def _worker():
            url = self._state.get("manifest_url") or DEFAULT_MANIFEST_URL
            if "netlify.app" in url or "YOUR_GITHUB_USERNAME" in url:
                url = DEFAULT_MANIFEST_URL
                self._state["manifest_url"] = url
            local_v = self._read_local_version()
            now_ist = datetime.now(IST_TZ)
            remote = None
            err = ""
            try:
                # Zero-cache GitHub contents raw endpoint
                fetch_url = url if ("github.com" in url) else DEFAULT_MANIFEST_URL
                req = urllib.request.Request(
                    fetch_url,
                    headers={
                        "User-Agent": "TheSuperMouse-PatchChecker/1.0",
                        "Accept": "application/vnd.github.v3.raw",
                        "Cache-Control": "no-cache",
                    },
                )
                with urllib.request.urlopen(req, timeout=10) as resp:
                    raw = resp.read().decode("utf-8", errors="replace")
                    remote = json.loads(raw)
            except Exception as exc:
                try:
                    fallback_url = f"https://raw.githubusercontent.com/getsupermouse/supermouse-updates/main/updates/version.json?t={int(now_ist.timestamp())}"
                    req2 = urllib.request.Request(
                        fallback_url,
                        headers={"User-Agent": "TheSuperMouse-PatchChecker/1.0", "Cache-Control": "no-cache"},
                    )
                    with urllib.request.urlopen(req2, timeout=10) as resp2:
                        raw = resp2.read().decode("utf-8", errors="replace")
                        remote = json.loads(raw)
                except Exception as exc2:
                    err = f"Offline or unreachable ({type(exc2).__name__})"

            with self._lock:
                self._checking = False
                if mark_daily_slot or not err:
                    self._state["last_checked_ist_date"] = now_ist.strftime("%Y-%m-%d")
                self._state["last_checked_display"] = now_ist.strftime("Checked %I:%M %p IST")
                if isinstance(remote, dict):
                    self._state["cached_remote"] = remote
                self._save_state()
                self._status = self._evaluate_remote(local_v, self._state.get("cached_remote"), error=err)
                snap_out = dict(self._status)

            self.status_changed.emit(snap_out)

        threading.Thread(target=_worker, daemon=True).start()

    def install_single_update(self, update_item: dict):
        """Downloads and applies one particular pending update cleanly."""
        self._install_items([update_item])

    def install_all_updates(self):
        """Downloads and applies all pending updates sequentially."""
        with self._lock:
            items = list(self._status.get("updates") or [])
        if items:
            self._install_items(items)

    def install_pending_update(self):
        self.install_all_updates()

    def _install_items(self, items: list):
        """Downloads patch zip(s), verifies SHA-256, applies add/replace/delete/skip, and updates version."""
        with self._lock:
            if self._installing or not items:
                return
            self._installing = True
            self._status["installing"] = True
            st = dict(self._status)
        self.status_changed.emit(st)

        def _apply_worker():
            locked_swaps = []
            tmp_dirs = []
            try:
                app_root = _app_root_dir()
                total_items = len(items)
                final_ver = st.get("current_version", CURRENT_APP_VERSION)

                for idx, item in enumerate(items):
                    dl_url = item.get("patch_url") or item.get("full_url")
                    label = item.get("headline") or f"v{item.get('version', '')}"
                    base_pct = int((idx / total_items) * 100)
                    span_pct = max(10, int(100 / total_items))

                    # Demo Preview Simulation when no real GitHub patch URL is attached yet
                    if not dl_url and DEMO_PREVIEW_MODE:
                        import time as _t
                        for step in range(0, 72, 4):
                            pct = min(95, base_pct + int((step / 100.0) * span_pct))
                            self.download_progress.emit(pct, f"Downloading {label}... {pct}%")
                            _t.sleep(0.055)
                        for step in range(72, 100, 7):
                            pct = min(98, base_pct + int((step / 100.0) * span_pct))
                            self.download_progress.emit(pct, f"Installing {label}... {pct}%")
                            _t.sleep(0.075)
                        if item.get("version"):
                            self._demo_installed_versions.add(str(item["version"]))
                            final_ver = str(item["version"])
                        continue

                    if not dl_url:
                        raise RuntimeError(f"No download URL for {label}.")

                    self.download_progress.emit(base_pct + 2, f"Downloading {label}...")
                    tmp_dir = tempfile.mkdtemp(prefix="tsm_patch_")
                    tmp_dirs.append(tmp_dir)
                    zip_path = os.path.join(tmp_dir, "update_patch.zip")

                    req = urllib.request.Request(dl_url, headers={"User-Agent": "TheSuperMouse-PatchChecker/1.0"})
                    with urllib.request.urlopen(req, timeout=30) as resp:
                        total = int(resp.headers.get("Content-Length") or 0)
                        downloaded = 0
                        with open(zip_path, "wb") as out_f:
                            while True:
                                chunk = resp.read(65536)
                                if not chunk:
                                    break
                                out_f.write(chunk)
                                downloaded += len(chunk)
                                if total > 0:
                                    pct = base_pct + 2 + int((downloaded / total) * (span_pct * 0.65))
                                    self.download_progress.emit(min(96, pct), f"Downloading {label}... {min(99, pct)}%")

                    self.download_progress.emit(min(97, base_pct + int(span_pct * 0.72)), f"Verifying SHA-256 ({label})...")
                    extract_dir = os.path.join(tmp_dir, "extracted")
                    os.makedirs(extract_dir, exist_ok=True)
                    with zipfile.ZipFile(zip_path, "r") as zf:
                        zf.extractall(extract_dir)

                    manifest_file = os.path.join(extract_dir, "manifest.json")
                    manifest = {}
                    if os.path.exists(manifest_file):
                        with open(manifest_file, "r", encoding="utf-8") as mf:
                            manifest = json.load(mf) or {}

                    sha_map = manifest.get("sha256") or item.get("sha256") or {}
                    add_list = manifest.get("add") or item.get("add") or []
                    replace_list = manifest.get("replace") or item.get("replace") or []
                    delete_list = manifest.get("delete") or item.get("delete") or []

                    payload_root = os.path.join(extract_dir, "files")
                    if not os.path.isdir(payload_root):
                        payload_root = extract_dir

                    for rel in list(add_list) + list(replace_list):
                        src = os.path.join(payload_root, rel)
                        expected = sha_map.get(rel)
                        if expected and os.path.exists(src):
                            if compute_sha256(src) != expected.lower():
                                raise RuntimeError(f"SHA-256 mismatch on {rel}")

                    targets = list(add_list) + list(replace_list)
                    if not targets:
                        for root_d, _, files in os.walk(payload_root):
                            for fn in files:
                                full = os.path.join(root_d, fn)
                                rel = os.path.relpath(full, payload_root).replace("\\", "/")
                                if rel != "manifest.json":
                                    targets.append(rel)

                    for rel in targets:
                        src = os.path.join(payload_root, rel)
                        if not os.path.exists(src):
                            continue
                        dst = os.path.join(app_root, rel)
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        try:
                            shutil.copy2(src, dst)
                        except PermissionError:
                            staged = dst + ".tsm_new"
                            shutil.copy2(src, staged)
                            locked_swaps.append((staged, dst))

                    for rel in delete_list:
                        dst = os.path.join(app_root, rel)
                        if os.path.exists(dst):
                            try:
                                os.remove(dst)
                            except Exception:
                                pass

                    if item.get("version"):
                        final_ver = str(item["version"])

                is_demo_run = DEMO_PREVIEW_MODE and all(not (it.get("patch_url") or it.get("full_url")) for it in items)
                if not is_demo_run:
                    try:
                        with open(os.path.join(app_root, "version.json"), "w", encoding="utf-8") as vf:
                            json.dump({"version": final_ver, "updated_at": datetime.now(IST_TZ).isoformat()}, vf, indent=2)
                    except Exception:
                        pass

                with self._lock:
                    self._installing = False
                    if is_demo_run:
                        self._status = self._evaluate_remote(self._read_local_version(), self._get_demo_remote())
                    else:
                        self._state["installed_version"] = final_ver
                        self._save_state()
                        self._status = self._evaluate_remote(final_ver, self._state.get("cached_remote"))
                    snap_done = dict(self._status)

                self.download_progress.emit(100, f"Updated to v{final_ver}!")
                self.status_changed.emit(snap_done)
                self.update_finished.emit(True, f"Updated cleanly to v{final_ver}")

                if locked_swaps:
                    bat_fp = os.path.join(tmp_dirs[-1], "finish_patch.bat")
                    lines = ["@echo off", "timeout /t 2 /nobreak >nul"]
                    for staged, dst in locked_swaps:
                        lines.append(f'move /y "{staged}" "{dst}" >nul')
                    if getattr(sys, "frozen", False):
                        lines.append(f'start "" "{sys.executable}"')
                    else:
                        lines.append(f'start "" "{sys.executable}" "{os.path.join(app_root, "main_app.py")}"')
                    with open(bat_fp, "w", encoding="utf-8") as bf:
                        bf.write("\r\n".join(lines))
                    subprocess.Popen(["cmd", "/c", bat_fp], creationflags=0x08000000)
                else:
                    for td in tmp_dirs:
                        shutil.rmtree(td, ignore_errors=True)
            except Exception as exc:
                with self._lock:
                    self._installing = False
                    self._status["installing"] = False
                    self._status["error"] = str(exc)
                    snap_err = dict(self._status)
                self.status_changed.emit(snap_err)
                self.update_finished.emit(False, str(exc))

        threading.Thread(target=_apply_worker, daemon=True).start()


_SINGLETON_CHECKER: PatchChecker | None = None


def get_patch_checker() -> PatchChecker:
    global _SINGLETON_CHECKER
    if _SINGLETON_CHECKER is None:
        _SINGLETON_CHECKER = PatchChecker()
    return _SINGLETON_CHECKER
