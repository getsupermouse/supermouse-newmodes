# -*- coding: utf-8 -*-
from .common import *
from .markup_editor import _SnipResultWindow
class _SnipOverlay(QWidget):
    """Fullscreen dimmed desktop snipping overlay with crosshair cursor."""
    snipped = Signal(object, QRect, object)
    cancelled = Signal()

    def __init__(self, parent=None):
        super().__init__(
            parent,
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint,
        )
        self.setAttribute(Qt.WA_TranslucentBackground, False)
        self.setCursor(Qt.CrossCursor)
        self.setMouseTracking(True)

        self._screen = None
        self._screen_pix = None
        self._dpr = 1.0
        self._selecting = False
        self._origin = QPoint()
        self._current = QPoint()

    def begin_snip(self):
        cur = QCursor.pos()
        scr = QApplication.screenAt(cur) or QApplication.primaryScreen()
        self._screen = scr
        self._screen_pix = scr.grabWindow(0)
        self._dpr = float(self._screen_pix.devicePixelRatio() or 1.0)
        self._selecting = False
        self._origin = QPoint()
        self._current = QPoint()

        self.setGeometry(scr.geometry())
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

    def _selection_rect(self):
        if not self._selecting:
            return QRect()
        return QRect(self._origin, self._current).normalized().intersected(self.rect())

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self._selecting = False
            self.hide()
            self.cancelled.emit()
            e.accept()
        else:
            super().keyPressEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._selecting = True
            self._origin = e.position().toPoint()
            self._current = self._origin
            self.update()
            e.accept()
        elif e.button() == Qt.RightButton:
            self._selecting = False
            self.hide()
            self.cancelled.emit()
            e.accept()

    def mouseMoveEvent(self, e):
        if self._selecting:
            self._current = e.position().toPoint()
            self.update()
            e.accept()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._selecting:
            self._current = e.position().toPoint()
            sel = self._selection_rect()
            self._selecting = False
            self.hide()

            if sel.width() >= 10 and sel.height() >= 10 and self._screen_pix:
                dpr = self._dpr
                src = QRect(
                    int(round(sel.x() * dpr)),
                    int(round(sel.y() * dpr)),
                    max(1, int(round(sel.width() * dpr))),
                    max(1, int(round(sel.height() * dpr))),
                )
                cropped = self._screen_pix.copy(src)
                cropped.setDevicePixelRatio(dpr)
                global_rect = QRect(self.mapToGlobal(sel.topLeft()), sel.size())
                self.snipped.emit(cropped, global_rect, self._screen)
            else:
                self.cancelled.emit()
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        if self._screen_pix and not self._screen_pix.isNull():
            p.drawPixmap(self.rect(), self._screen_pix)

        p.fillRect(self.rect(), QColor(0, 0, 0, 128))

        sel = self._selection_rect()
        if not sel.isEmpty() and sel.width() >= 2 and sel.height() >= 2 and self._screen_pix:
            dpr = self._dpr
            src = QRectF(sel.x() * dpr, sel.y() * dpr, sel.width() * dpr, sel.height() * dpr)
            p.drawPixmap(QRectF(sel), self._screen_pix, src)

            p.setPen(QPen(QColor("#a3e635"), 1.6))
            p.drawRect(QRectF(sel.x() + 0.5, sel.y() + 0.5, sel.width() - 1.0, sel.height() - 1.0))

            dim_txt = f"{int(round(sel.width() * dpr))} × {int(round(sel.height() * dpr))}"
            f_d = QFont("Segoe UI Variable", 8, QFont.Bold)
            p.setFont(f_d)
            tw = QFontMetrics(f_d).horizontalAdvance(dim_txt) + 14
            dy = sel.top() - 24 if sel.top() > 30 else sel.bottom() + 6
            dx = max(8, min(self.width() - tw - 8, sel.left()))
            dp = QPainterPath()
            dp.addRoundedRect(QRectF(dx, dy, tw, 18), 5.0, 5.0)
            p.fillPath(dp, QColor(5, 5, 6, 235))
            p.setPen(QPen(QColor(163, 230, 53, 140), 0.9))
            p.drawPath(dp)
            p.setPen(QColor("#a3e635"))
            p.drawText(QRect(dx, dy, tw, 18), Qt.AlignCenter, dim_txt)
        else:
            hint = "Drag to snip area  •  Esc to cancel"
            fh = QFont("Segoe UI Variable", 9, QFont.DemiBold)
            p.setFont(fh)
            hw = QFontMetrics(fh).horizontalAdvance(hint) + 28
            hr = QRectF((self.width() - hw) * 0.5, 22.0, hw, 30.0)
            hp = QPainterPath()
            hp.addRoundedRect(hr, 8.0, 8.0)
            p.fillPath(hp, QColor(5, 5, 6, 235))
            p.setPen(QPen(QColor(163, 230, 53, 130), 1.0))
            p.drawPath(hp)
            p.setPen(QColor("#E4E4E7"))
            p.drawText(hr, Qt.AlignCenter, hint)

        p.end()


