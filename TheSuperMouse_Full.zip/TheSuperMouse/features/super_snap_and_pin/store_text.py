# -*- coding: utf-8 -*-
"""Super Snap & Pin - Store Text Module."""
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QWidget, QLabel, QVBoxLayout
from ui_theme import ACCENT_LIME, TEXT_PRIMARY, TEXT_MUTED

class StoreTextWindow(QWidget):
    """Store Text clipboard history tool window."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Store Text")
        self.setFixedSize(360, 480)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.SubWindow)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
