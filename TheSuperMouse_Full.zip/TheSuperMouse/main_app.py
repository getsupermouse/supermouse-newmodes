# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - MASTER LAUNCHER & MODULE ORCHESTRATOR
=======================================================
Connects separated modular components cleanly:
  - runner.py         -> Main SuperMouse Editor HUD Window (SuperMouseHUD)
  - quick_menu.py     -> Vertical Frosted Glass Sidebar Menu (SuperMouseQuickMenu)
  - global_triggers.py -> Win+Shift+M, R-Hold + 3x L-Click, System Tray & Autostart
"""

import os
import sys

_ROOT_DIR = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
if _ROOT_DIR not in sys.path:
    sys.path.insert(0, _ROOT_DIR)
for _sub in ['core', 'features', os.path.join('features', 'super_share'), os.path.join('features', 'super_snap_and_pin')]:
    _p = os.path.join(_ROOT_DIR, _sub)
    if _p not in sys.path:
        sys.path.insert(0, _p)

_log_p = os.path.join(_ROOT_DIR, "app_crash.log")
try:
    _err_f = open(_log_p, "a", encoding="utf-8")
    if sys.stdout is None:
        sys.stdout = _err_f
    if sys.stderr is None:
        sys.stderr = _err_f
except Exception:
    pass

import atexit
import ctypes
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

from PySide6.QtCore import QObject, Signal, Qt
from PySide6.QtGui import QIcon, QCursor
from PySide6.QtWidgets import QApplication

import runner
from quick_menu import SuperMouseQuickMenu
from super_clipboard import SuperClipboardWindow, count_box_items
from super_design import SuperSupDesignWindow
from super_share import SuperShareController, count_stored_share_items
from global_triggers import (
    GlobalInputTriggers, SystemTrayManager, ensure_autostart_registered,
    disable_autostart_registered, load_access_settings,
)
from selection_theme import apply_supermouse_selection_theme, restore_original_selection_theme
from windows_integration import (
    register_windows_context_menus, send_ipc_command,
    prewarm_win11_shell_server, stop_win11_shell_server, IPC_PORT,
)


class _IpcBridge(QObject):
    route_requested = Signal(str)


def acquire_single_instance_mutex():
    """Ensure only one background trigger + tray service runs at a time."""
    kernel32 = ctypes.windll.kernel32
    mutex = kernel32.CreateMutexW(None, False, "TheSuperMouse_Unified_App_Mutex_v2")
    last_err = kernel32.GetLastError()
    ERROR_ALREADY_EXISTS = 183
    if last_err == ERROR_ALREADY_EXISTS:
        return None
    return mutex


def main():
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("TheSuperMouse.CreativeSuite.v1.02")
    except Exception:
        pass

    app = QApplication.instance()
    if not app:
        app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    init_cfg = load_access_settings()
    if init_cfg.get("selection_theme_enabled", True):
        apply_supermouse_selection_theme(app)
    atexit.register(restore_original_selection_theme)

    from ui_theme import get_app_icon
    app_icon = get_app_icon()
    if not app_icon.isNull():
        app.setWindowIcon(app_icon)

    # 1. Separate SuperMouse Main Editor Window
    hud = runner.SuperMouseHUD(install_hook=False)

    # 2. Separate The SuperClipboard Window + Snipping Box Engine
    super_clipboard = SuperClipboardWindow()

    # 3. Separate SuperSupDesign Studio Window (Folder / Files / Cursor)
    super_design = SuperSupDesignWindow()

    # 3b. Separate Super Share Controller (Device Window + Stored Window + LAN Engine)
    super_share = SuperShareController()

    # 4. Separate Minimalist Quick Menu (Entry/Exit pull animation vs ASMR between-option switch)
    quick_menu = SuperMouseQuickMenu(
        on_open_hud=hud.open_hud_at_any_cost,
        on_open_clipboard=super_clipboard.open_asmr_switch,
        on_open_design=super_design.open_asmr_switch,
        on_open_snap=super_clipboard.start_snap_directly,
        on_open_box=super_clipboard.open_my_box_asmr,
        on_open_share_menu=super_share.menu_window.open_asmr_switch,
        on_open_share_device=super_share.device_window.open_asmr_switch,
        on_open_share_stored=super_share.stored_window.open_asmr_switch,
        on_open_share_settings=super_share.settings_window.open_asmr_switch,
        get_box_count=count_box_items,
        get_share_count=count_stored_share_items,
    )
    hud.on_back_to_menu = quick_menu.open_asmr_switch
    super_clipboard.on_back_to_menu = quick_menu.open_asmr_switch
    super_design.on_back_to_menu = quick_menu.open_asmr_switch
    super_share.on_back_to_menu = quick_menu.open_asmr_switch
    super_share.on_back_to_share_menu = super_share.menu_window.open_asmr_switch

    # 5. Separate Global Input Triggers (customizable hotkey + R-Hold+3x L-Click + Shift+Win+2x Tap)
    triggers = GlobalInputTriggers(callback=quick_menu.toggle_at_cursor, parent=app)
    triggers.install()

    def _apply_live_access_settings(cfg):
        triggers.reload_settings(cfg)
        if cfg.get("selection_theme_enabled", True):
            apply_supermouse_selection_theme(app)
        else:
            restore_original_selection_theme()
        if cfg.get("autostart_enabled", True):
            ensure_autostart_registered(os.path.abspath(__file__))
        else:
            disable_autostart_registered()

    quick_menu.on_settings_changed = _apply_live_access_settings

    # 6. Always-On Taskbar Tray Icon (^ Overflow Up Arrow)
    tray_mgr = SystemTrayManager(icon_path=runner.TASKBAR_ICON_ICO, parent=app)
    tray_mgr.open_menu_requested.connect(quick_menu.open_at_cursor)
    tray_mgr.open_hud_requested.connect(hud.open_hud_at_any_cost)
    tray_mgr.open_clipboard_requested.connect(super_clipboard.open_at_cursor)
    tray_mgr.open_design_requested.connect(super_design.open_window)
    tray_mgr.quit_requested.connect(
        lambda: (triggers.uninstall(), super_share.engine.stop(), stop_win11_shell_server(), restore_original_selection_theme(), app.quit())
    )

    # 7. Ensure Autostart + HKCU Context Menus + Pre-Warmed Win11 Shell COM + Loopback IPC
    if init_cfg.get("autostart_enabled", True):
        ensure_autostart_registered(os.path.abspath(__file__))
    register_windows_context_menus()
    prewarm_win11_shell_server()

    ipc = _IpcBridge(app)

    def _on_ipc(route):
        if route == "snap":
            super_clipboard.start_snap_directly()
        elif route == "box":
            super_clipboard.open_my_box()
        elif route == "superpin":
            super_clipboard.open_at_cursor()
        elif route == "supershare_device":
            super_share.device_window.open_window()
        elif route in ("hud", "cursor", "menu", "supershare"):
            quick_menu.open_at_cursor()
        elif route in ("supershare_menu", "supershare_sub"):
            super_share.menu_window.open_asmr_switch()
        elif route in ("supershare_stored", "supershare_memory"):
            super_share.stored_window.open_window()
        elif route == "supershare_settings":
            super_share.settings_window.open_window()
        elif route == "superedit":
            hud.open_hud_at_any_cost()
        else:
            quick_menu.open_at_cursor()

    ipc.route_requested.connect(_on_ipc, Qt.QueuedConnection)

    class _IpcHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            route = self.path.strip("/").split("?")[0] or "menu"
            ipc.route_requested.emit(route)
            self.send_response(200)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(b"OK")

        def log_message(self, *args):
            pass

    class ReusableHTTPServer(HTTPServer):
        allow_reuse_address = True

    def _run_ipc():
        for _ in range(5):
            try:
                srv = ReusableHTTPServer(("127.0.0.1", IPC_PORT), _IpcHandler)
                srv.serve_forever()
                break
            except Exception:
                import time; time.sleep(1)

    threading.Thread(target=_run_ipc, daemon=True).start()

    # Create quick shortcut on Desktop & Quick Launch for Super Snap & Pin
    try:
        import win32com.client
        wsh = win32com.client.Dispatch("WScript.Shell")
        snap_lnk = os.path.join(os.path.expanduser("~"), "Desktop", "Super Snap & Pin.lnk")
        exe_path = sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__)
        ico_path = runner.TASKBAR_ICON_ICO
        sc = wsh.CreateShortcut(snap_lnk)
        sc.TargetPath = exe_path
        sc.Arguments = "--snap"
        sc.WorkingDirectory = os.path.dirname(exe_path)
        if os.path.exists(ico_path):
            sc.IconLocation = ico_path
        sc.Save()
    except Exception:
        pass

    if "--superpin" in sys.argv:
        super_clipboard.open_at_cursor()
    elif "--snap" in sys.argv:
        super_clipboard.start_snap_directly()
    elif "--box" in sys.argv:
        super_clipboard.open_my_box()
    elif "--superedit" in sys.argv:
        hud.open_hud_at_any_cost()
    elif "--supershare" in sys.argv:
        quick_menu.open_at_cursor()
    elif "--silent" not in sys.argv:
        quick_menu.open_at_cursor()

    sys.exit(app.exec())


if __name__ == "__main__":
    import traceback
    try:
        _mutex = acquire_single_instance_mutex()
        print(f"MAIN_APP RUN: mutex={_mutex}, argv={sys.argv}", flush=True)
        if not _mutex:
            route = "menu"
            if "--superpin" in sys.argv:
                route = "superpin"
            elif "--snap" in sys.argv:
                route = "snap"
            elif "--box" in sys.argv:
                route = "box"
            elif "--supershare" in sys.argv:
                route = "supershare"
            send_ipc_command(route)
            sys.exit(0)
        main()
    except Exception:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "app_crash.log"), "w", encoding="utf-8") as f:
            traceback.print_exc(file=f)

