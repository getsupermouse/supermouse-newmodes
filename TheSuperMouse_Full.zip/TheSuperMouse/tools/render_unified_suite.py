import os
import struct
import io
from PySide6.QtGui import QImage, QPainter, QColor
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtCore import QByteArray
from PIL import Image

assets_dir = r"D:\THESUPERMOUSE\thesupermouse\assets"
os.makedirs(assets_dir, exist_ok=True)

GRAD = """<defs>
  <linearGradient id="g" x1="0%" y1="0%" x2="0%" y2="100%">
    <stop offset="0%" stop-color="#FCFF00"/>
    <stop offset="45%" stop-color="#84FF00"/>
    <stop offset="100%" stop-color="#00FF85"/>
  </linearGradient>
</defs>"""

# 1. POINTER HAND (Fixed rounded apex, no cut off, sleek dome)
SVG_HAND = f"""<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 24 24">
{GRAD}
<g transform="translate(1.5, 1.5)">
  <path d="M 8.5 2.2 C 7.0 2.2 6.0 3.3 6.0 4.8 L 6.0 13.5 L 3.5 11.0 C 2.6 10.1 1.2 10.1 0.4 11.0 C -0.4 11.8 -0.4 13.2 0.4 14.0 L 4.0 17.6 C 5.5 19.1 7.2 19.8 10.0 19.8 L 12.0 19.8 C 16.4 19.8 19.8 16.4 19.8 12.0 L 19.8 9.0 C 19.8 7.9 18.9 7.0 17.8 7.0 C 17.4 7.0 17.1 7.1 16.8 7.3 C 16.5 6.5 15.7 6.0 14.8 6.0 C 14.4 6.0 14.1 6.1 13.8 6.3 C 13.5 5.5 12.7 5.0 11.8 5.0 C 11.4 5.0 11.0 5.1 10.8 5.3 L 10.8 4.8 C 10.8 3.3 9.8 2.2 8.5 2.2 Z" 
        fill="url(#g)" stroke="#000000" stroke-width="1.6" stroke-linejoin="round"/>
  <path d="M 10.8 9.5 L 10.8 13.5" stroke="#000000" stroke-width="1.2" stroke-linecap="round"/>
  <path d="M 13.8 10.2 L 13.8 13.5" stroke="#000000" stroke-width="1.2" stroke-linecap="round"/>
  <path d="M 16.8 11.0 L 16.8 14.0" stroke="#000000" stroke-width="1.2" stroke-linecap="round"/>
</g>
</svg>"""

# 2. GRAB (Open Hand - Exact matching pointer hand style)
# 4 open fingers + thumb, matching stroke and radius
SVG_GRAB = f"""<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 24 24">
{GRAD}
<g transform="translate(1.5, 1.5)">
  <path d="M 6.8 3.0 C 5.5 3.0 4.8 3.8 4.8 5.2 L 4.8 12.0 L 2.8 9.8 C 1.9 8.9 0.6 8.9 -0.2 9.8 C -0.9 10.6 -0.9 11.9 -0.2 12.7 L 3.2 16.2 C 4.8 17.8 6.6 18.8 9.2 18.8 L 11.5 18.8 C 15.5 18.8 18.8 15.5 18.8 11.5 L 18.8 7.5 C 18.8 6.2 17.8 5.4 16.5 5.4 C 16.1 5.4 15.8 5.5 15.5 5.7 L 15.5 4.8 C 15.5 3.5 14.5 2.8 13.2 2.8 C 12.8 2.8 12.5 2.9 12.2 3.1 L 12.2 3.8 C 12.2 2.5 11.2 1.8 9.8 1.8 C 8.6 1.8 7.8 2.6 7.8 3.8 L 7.8 4.2 C 7.5 3.5 7.2 3.0 6.8 3.0 Z" 
        fill="url(#g)" stroke="#000000" stroke-width="1.6" stroke-linejoin="round"/>
  <path d="M 7.8 9.0 L 7.8 13.0" stroke="#000000" stroke-width="1.2" stroke-linecap="round"/>
  <path d="M 12.2 8.5 L 12.2 13.0" stroke="#000000" stroke-width="1.2" stroke-linecap="round"/>
  <path d="M 15.5 9.5 L 15.5 13.0" stroke="#000000" stroke-width="1.2" stroke-linecap="round"/>
</g>
</svg>"""

# 3. GRABBING (Closed Hand / Fist - Exact matching pointer hand style)
# Fingers tightly curled inwards, thumb locked over fingers
SVG_GRABBING = f"""<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 24 24">
{GRAD}
<g transform="translate(2, 2)">
  <path d="M 4.5 6.0 C 4.5 4.5 5.8 3.5 7.5 3.5 L 13.5 3.5 C 15.5 3.5 17.0 5.0 17.0 7.0 L 17.0 10.5 C 17.0 14.5 14.0 17.5 10.0 17.5 L 7.5 17.5 C 4.5 17.5 2.5 15.0 2.5 12.0 L 2.5 8.5 C 2.5 7.5 3.5 6.0 4.5 6.0 Z" 
        fill="url(#g)" stroke="#000000" stroke-width="1.6" stroke-linejoin="round"/>
  <!-- Curled finger creases -->
  <path d="M 5.5 8.0 L 15.0 8.0" stroke="#000000" stroke-width="1.3" stroke-linecap="round"/>
  <path d="M 8.5 4.0 L 8.5 8.0" stroke="#000000" stroke-width="1.1" stroke-linecap="round"/>
  <path d="M 12.0 4.0 L 12.0 8.0" stroke="#000000" stroke-width="1.1" stroke-linecap="round"/>
  <!-- Thumb folded across -->
  <path d="M 2.8 11.0 C 3.5 9.5 5.5 9.0 8.0 9.5 L 13.0 10.5 C 14.5 10.8 15.0 12.0 14.0 13.0 C 12.5 14.2 9.5 14.5 7.0 14.0 Z" 
        fill="url(#g)" stroke="#000000" stroke-width="1.4" stroke-linejoin="round"/>
</g>
</svg>"""

# 4. MOVE (4-Way Compass - Normalized compact ~15px size)
SVG_MOVE = f"""<svg width="256" height="256" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
{GRAD}
<g transform="translate(0.5, 0.5)">
  <path d="M 11.5 2 L 14.5 5.5 L 12.5 5.5 L 12.5 10.5 L 17.5 10.5 L 17.5 8.5 L 21 11.5 L 17.5 14.5 L 17.5 12.5 L 12.5 12.5 L 12.5 17.5 L 14.5 17.5 L 11.5 21 L 8.5 17.5 L 10.5 17.5 L 10.5 12.5 L 5.5 12.5 L 5.5 14.5 L 2 11.5 L 5.5 8.5 L 5.5 10.5 L 10.5 10.5 L 10.5 5.5 L 8.5 5.5 Z" 
        fill="url(#g)" stroke="#000000" stroke-width="1.4" stroke-linejoin="round"/>
</g>
</svg>"""

# 5. ZOOM IN (Normalized compact ~15px size)
SVG_ZOOM_IN = f"""<svg width="256" height="256" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
{GRAD}
<g transform="translate(1, 1)">
  <circle cx="9.5" cy="9.5" r="7.5" fill="url(#g)" stroke="#000000" stroke-width="1.6"/>
  <circle cx="9.5" cy="9.5" r="5.2" fill="#050608"/>
  <line x1="14.8" y1="14.8" x2="20.5" y2="20.5" stroke="#000000" stroke-width="4.2" stroke-linecap="round"/>
  <line x1="15" y1="15" x2="20" y2="20" stroke="url(#g)" stroke-width="2.2" stroke-linecap="round"/>
  <!-- + sign -->
  <line x1="9.5" y1="6.8" x2="9.5" y2="12.2" stroke="#84FF00" stroke-width="1.8" stroke-linecap="round"/>
  <line x1="6.8" y1="9.5" x2="12.2" y2="9.5" stroke="#84FF00" stroke-width="1.8" stroke-linecap="round"/>
</g>
</svg>"""

# 6. ZOOM OUT (Normalized compact ~15px size)
SVG_ZOOM_OUT = f"""<svg width="256" height="256" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
{GRAD}
<g transform="translate(1, 1)">
  <circle cx="9.5" cy="9.5" r="7.5" fill="url(#g)" stroke="#000000" stroke-width="1.6"/>
  <circle cx="9.5" cy="9.5" r="5.2" fill="#050608"/>
  <line x1="14.8" y1="14.8" x2="20.5" y2="20.5" stroke="#000000" stroke-width="4.2" stroke-linecap="round"/>
  <line x1="15" y1="15" x2="20" y2="20" stroke="url(#g)" stroke-width="2.2" stroke-linecap="round"/>
  <!-- - sign -->
  <line x1="6.8" y1="9.5" x2="12.2" y2="9.5" stroke="#84FF00" stroke-width="1.8" stroke-linecap="round"/>
</g>
</svg>"""

# 7. HELP INFO (ONLY Question Mark, normalized compact ~15px height)
SVG_HELP = f"""<svg width="256" height="256" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
{GRAD}
<g transform="translate(1, 1)">
  <path d="M 8.0 7.5 C 8.0 5.2 9.6 3.5 11.5 3.5 C 13.4 3.5 15.0 4.8 15.0 6.8 C 15.0 8.5 13.5 9.8 12.2 10.8 C 11.5 11.4 11.2 12.2 11.2 13.5" 
        stroke="#000000" stroke-width="3.2" stroke-linecap="round"/>
  <path d="M 8.0 7.5 C 8.0 5.2 9.6 3.5 11.5 3.5 C 13.4 3.5 15.0 4.8 15.0 6.8 C 15.0 8.5 13.5 9.8 12.2 10.8 C 11.5 11.4 11.2 12.2 11.2 13.5" 
        stroke="url(#g)" stroke-width="2.0" stroke-linecap="round"/>
  <!-- Dot -->
  <circle cx="11.2" cy="17.2" r="1.8" fill="#000000"/>
  <circle cx="11.2" cy="17.2" r="1.2" fill="#00FF85"/>
</g>
</svg>"""

CURSORS = [
    # (name, svg_code, target_width_32, hotspot_32, pad_top)
    ("supermouse_hand", SVG_HAND, 14, (6, 2), 2),
    ("supermouse_grab", SVG_GRAB, 14, (7, 6), 2),
    ("supermouse_grabbing", SVG_GRABBING, 13, (6, 6), 3),
    ("supermouse_move", SVG_MOVE, 15, (7, 7), 2),
    ("supermouse_zoom_in", SVG_ZOOM_IN, 15, (7, 7), 2),
    ("supermouse_zoom_out", SVG_ZOOM_OUT, 15, (7, 7), 2),
    ("supermouse_help", SVG_HELP, 11, (1, 1), 2),
]

def build_cursor_files(name, svg_str, target_w_base, base_hs, pad_top_base):
    renderer = QSvgRenderer(QByteArray(svg_str.encode("utf-8")))
    frames = []

    # Scales: 32px (scale 1), 48px (scale 1.5), 64px (scale 2)
    scales = [(32, target_w_base, pad_top_base), 
              (48, int(target_w_base * 1.5), int(pad_top_base * 1.5)), 
              (64, target_w_base * 2, pad_top_base * 2)]

    for c_size, t_w, pad_top in scales:
        qimg = QImage(256, 256, QImage.Format_ARGB32_Premultiplied)
        qimg.fill(QColor(0, 0, 0, 0))
        p = QPainter(qimg)
        renderer.render(p)
        p.end()

        tmp_path = os.path.join(assets_dir, f"tmp_{name}_{c_size}.png")
        qimg.save(tmp_path, "PNG")
        pil_im = Image.open(tmp_path)
        bbox = pil_im.getbbox()
        cropped = pil_im.crop(bbox) if bbox else pil_im
        if os.path.exists(tmp_path):
            os.remove(tmp_path)

        aspect = cropped.height / max(1, cropped.width)
        t_h = int(t_w * aspect)
        scaled = cropped.resize((t_w, t_h), Image.Resampling.LANCZOS)

        canvas = Image.new("RGBA", (c_size, c_size), (0, 0, 0, 0))
        # Center horizontally, apply top padding
        pad_x = (c_size - t_w) // 2 if name in ["supermouse_move", "supermouse_zoom_in", "supermouse_zoom_out", "supermouse_grab", "supermouse_grabbing"] else 2
        canvas.paste(scaled, (pad_x, pad_top))

        # Calculate scaled hotspot
        hs_x = int(base_hs[0] * (c_size / 32))
        hs_y = int(base_hs[1] * (c_size / 32))
        frames.append((c_size, canvas, (hs_x, hs_y)))

    # Save 32px PNG preview
    preview_dir = os.path.join(assets_dir, "supermouse_previews")
    os.makedirs(preview_dir, exist_ok=True)
    frames[0][1].save(os.path.join(preview_dir, f"{name}.png"))

    # Pack into .cur format
    png_blobs = []
    entries = []
    for size, img, hs in frames:
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        data = buf.getvalue()
        png_blobs.append(data)
        entries.append({"w": size, "h": size, "hx": hs[0], "hy": hs[1], "size": len(data)})

    offset = 6 + 16 * len(entries)
    cur_bytes = bytearray(struct.pack("<HHH", 0, 2, len(entries)))
    for e in entries:
        cur_bytes.extend(struct.pack("<BBBBHHII", e["w"], e["h"], 0, 0, e["hx"], e["hy"], e["size"], offset))
        offset += e["size"]
    for b in png_blobs:
        cur_bytes.extend(b)

    cur_file = os.path.join(assets_dir, f"{name}.cur")
    with open(cur_file, "wb") as f:
        f.write(cur_bytes)

    bbox_32 = frames[0][1].getbbox()
    w_32 = bbox_32[2] - bbox_32[0] if bbox_32 else 0
    h_32 = bbox_32[3] - bbox_32[1] if bbox_32 else 0
    print(f"Generated {name}.cur -> visual size: {w_32}x{h_32}px, hotspot: {frames[0][2]}")

for name, svg, tw, hs, pt in CURSORS:
    build_cursor_files(name, svg, tw, hs, pt)

print("All unified cursors built successfully!")

