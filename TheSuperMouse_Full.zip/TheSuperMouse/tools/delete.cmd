@echo off
if /I "%~1"=="supermouse" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0delete_supermouse.ps1"
    exit /b %errorlevel%
)
echo Usage: delete supermouse
exit /b 1
