# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE — GitHub Release & Update Manifest Publisher
Stages and deploys version.json and update patches to GitHub:
  - Updates repository directory (updates/version.json and patches).
  - Automatically runs git add, commit, and push.
"""
import argparse
import os
import shutil
import subprocess
import sys


def publish(manifest_dir: str, repo_dir: str, commit_msg: str = "Release update"):
    os.makedirs(repo_dir, exist_ok=True)
    updates_target = os.path.join(repo_dir, "updates")
    os.makedirs(updates_target, exist_ok=True)

    sources = [manifest_dir, r"D:\THESUPERMOUSE\dist_release"]
    found_any = False

    for src_dir in sources:
        if os.path.exists(src_dir):
            for item in os.listdir(src_dir):
                src = os.path.join(src_dir, item)
                dst = os.path.join(updates_target, item)
                if os.path.isfile(src):
                    shutil.copy2(src, dst)
                    print(f"[+] Synced {item} -> {dst}")
                    found_any = True

    if not found_any:
        print(f"[!] Warning: no release or patch files found in {sources}")
        return False

    # Run git commands in repo_dir
    try:
        subprocess.run(["git", "add", "."], cwd=repo_dir, check=True)
        res = subprocess.run(["git", "status", "--porcelain"], cwd=repo_dir, capture_output=True, text=True)
        if not res.stdout.strip():
            print("[i] No git changes detected to commit.")
            return True
        subprocess.run(["git", "commit", "-m", commit_msg], cwd=repo_dir, check=True)
        print(f"[+] Committed: {commit_msg}")
        push_res = subprocess.run(["git", "push", "origin", "main"], cwd=repo_dir, capture_output=True, text=True)
        if push_res.returncode == 0:
            print("[+] Successfully pushed to GitHub origin/main!")
        else:
            print(f"[*] Push note: {push_res.stderr.strip() or 'Configure remote origin with git remote add origin <URL>'}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"[!] Git operation error: {e}")
        return False


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Publish updates and manifest to GitHub")
    parser.add_argument("--src", default=r"D:\THESUPERMOUSE\dist_patch", help="Path with version.json & patch zips")
    parser.add_argument("--repo", default=r"D:\THESUPERMOUSE\supermousenewnupdates", help="Local clone of GitHub releases repo")
    parser.add_argument("--msg", default="Deploy update manifest and patch to GitHub", help="Commit message")
    args = parser.parse_args()
    publish(args.src, args.repo, args.msg)
