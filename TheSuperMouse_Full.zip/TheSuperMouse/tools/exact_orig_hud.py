import os, sys, json, time, ctypes
from ctypes import wintypes
from PySide6.QtCore import Qt, QTimer, QRectF, QPointF, QSize, Signal
from PySide6.QtGui import (
    QPainter, QColor, QBrush, QPen, QFont, QPainterPath, QLinearGradient,
    QCursor, QIcon, QPixmap
)
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QGraphicsDropShadowEffect, QFrame, QSystemTrayIcon, QMenu
)
from PySide6.QtNetwork import QLocalServer, QLocalSocket

BRAIN_DIR = r"C:\Users\mytre\.gemini\antigravity\brain"
APP_NAME = "AntigravityProgressHUD"

# ══════════════════════════════════════════════════════════════════════════════
#  FAST PROCESS MONITOR (kernel32 CreateToolhelp32Snapshot)
# ══════════════════════════════════════════════════════════════════════════════
kernel32 = ctypes.windll.kernel32
TH32CS_SNAPPROCESS = 0x00000002

class PROCESSENTRY32(ctypes.Structure):
    _fields_ = [
        ('dwSize', wintypes.DWORD),
        ('cntUsage', wintypes.DWORD),
        ('th32ProcessID', wintypes.DWORD),
        ('th32DefaultHeapID', ctypes.c_size_t),
        ('th32ModuleID', wintypes.DWORD),
        ('cntThreads', wintypes.DWORD),
        ('th32ParentProcessID', wintypes.DWORD),
        ('pcPriClassBase', ctypes.c_long),
        ('dwFlags', wintypes.DWORD),
        ('szExeFile', ctypes.c_char * 260)
    ]

def check_antigravity_running():
    hSnapshot = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if hSnapshot == -1:
        return False
    pe32 = PROCESSENTRY32()
    pe32.dwSize = ctypes.sizeof(PROCESSENTRY32)
    has_next = kernel32.Process32First(hSnapshot, ctypes.byref(pe32))
    found = False
    targets = {b'antigravity ide.exe', b'agy.exe'}
    while has_next:
        exe = pe32.szExeFile.lower()
        if exe in targets:
            found = True
            break
        has_next = kernel32.Process32Next(hSnapshot, ctypes.byref(pe32))
    kernel32.CloseHandle(hSnapshot)
    return found


# ══════════════════════════════════════════════════════════════════════════════
#  TRANSCRIPT WATCHER ENGINE
# ══════════════════════════════════════════════════════════════════════════════
class TranscriptWatcher:
    def __init__(self):
        self.last_prompt_id = None
        self.prompt_text = ""
        self.prompt_time = 0
        self.latest_tool = "Ready"
        self.step_count = 0
        self.is_running = False
        self.is_done = True
        self.elapsed_sec = 0

    def find_active_conversation(self):
        if not os.path.exists(BRAIN_DIR):
            return None
        subdirs = [
            os.path.join(BRAIN_DIR, d)
            for d in os.listdir(BRAIN_DIR)
            if os.path.isdir(os.path.join(BRAIN_DIR, d)) and len(d) > 20
        ]
        if not subdirs:
            return None
        subdirs.sort(key=os.path.getmtime, reverse=True)
        return subdirs[0]

    def poll(self):
        conv = self.find_active_conversation()
        if not conv:
            return False

        trans_file = os.path.join(conv, ".system_generated", "logs", "transcript.jsonl")
        if not os.path.exists(trans_file):
            return False

        try:
            with open(trans_file, "rb") as f:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                f.seek(max(0, size - 140000))
                chunk = f.read().decode("utf-8", errors="ignore")

            lines = [json.loads(l) for l in chunk.strip().split("\n") if l.strip().startswith("{")]
        except Exception:
            return False

        if not lines:
            return False

        last_user_idx = -1
        for i, item in enumerate(lines):
            if item.get("type") == "USER_INPUT":
                last_user_idx = i

        if last_user_idx < 0:
            return False

        user_item = lines[last_user_idx]
        p_text = user_item.get("content", "").strip()
        if "<USER_REQUEST>" in p_text:
            p_text = p_text.split("<USER_REQUEST>")[1].split("</USER_REQUEST>")[0].strip()
        created_at = user_item.get("created_at", "")

        is_new_prompt = (self.last_prompt_id != created_at)
        if is_new_prompt:
            self.last_prompt_id = created_at
            self.prompt_text = p_text
            self.prompt_time = time.time()

        subsequent = lines[last_user_idx+1:]
        tool_steps = []
        is_turn_done = False

        for s in subsequent:
            if "tool_calls" in s and s["tool_calls"]:
                for tc in s["tool_calls"]:
                    args = tc.get("args", {})
                    summary = args.get("toolSummary", "") or tc.get("name", "Tool")
                    summary = str(summary).strip("\"'")
                    tool_steps.append(summary)
            if s.get("type") == "PLANNER_RESPONSE" and s.get("content") and not s.get("tool_calls"):
                is_turn_done = True

        self.step_count = len(tool_steps)
        if tool_steps:
            self.latest_tool = tool_steps[-1]
        elif not is_turn_done:
            self.latest_tool = "Thinking & Planning..."
        else:
            self.latest_tool = "Task Completed"

        self.is_done = is_turn_done
        self.is_running = not is_turn_done

        if self.is_running:
            self.elapsed_sec = max(1, int(time.time() - self.prompt_time))
        else:
            if is_new_prompt:
                self.elapsed_sec = 0

        return is_new_prompt


# ══════════════════════════════════════════════════════════════════════════════
#  CIRCULAR NEON PROGRESS RING WIDGET
# ══════════════════════════════════════════════════════════════════════════════
class ProgressRing(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(68, 68)
        self.progress = 0.0
        self.is_active = False

    def set_progress(self, val, active=True):
        self.progress = max(0.0, min(100.0, val))
        self.is_active = active
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        cx, cy = w / 2.0, h / 2.0
        r = 26.0

        p.setPen(QPen(QColor(255, 255, 255, 20), 4.5))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(QPointF(cx, cy), r, r)

        if self.progress > 0:
            span_angle = int(-self.progress / 100.0 * 360 * 16)
            pen_color = QColor("#CFFF48") if self.is_active else QColor("#00FF85")
            pen = QPen(pen_color, 4.8, Qt.SolidLine, Qt.RoundCap)
            p.setPen(pen)
            rect = QRectF(cx - r, cy - r, r * 2.0, r * 2.0)
            p.drawArc(rect, 90 * 16, span_angle)

        p.setPen(QColor("#FFFFFF"))
        font = QFont("Segoe UI Variable", 12, QFont.Bold)
        font.setStyleStrategy(QFont.PreferAntialias)
        p.setFont(font)
        txt = f"{int(self.progress)}%" if self.progress < 100 else "✓"
        p.drawText(QRectF(0, 0, w, h), Qt.AlignCenter, txt)
        p.end()


# ══════════════════════════════════════════════════════════════════════════════
#  FLOATING COMPANION PROGRESS HUD
# ══════════════════════════════════════════════════════════════════════════════
class ProgressHUD(QWidget):
    def __init__(self):
        super().__init__()
        # Normal top-level window so it stays on top AND appears in Windows Taskbar
        self.setWindowFlags(
            Qt.FramelessWindowHint |
            Qt.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setWindowTitle("Antigravity Live Progress HUD")
        ico_file = r"D:\THESUPERMOUSE\thesupermouse\assets\hud_icons\supermouse_logo.ico"
        if os.path.exists(ico_file):
            self.setWindowIcon(QIcon(ico_file))

        self.resize(410, 122)

        self.watcher = TranscriptWatcher()
        self.displayed_progress = 0.0
        self.target_progress = 0.0
        self.drag_position = None
        self.antigravity_was_running = False

        self._build_ui()
        self._position_top_right()

        # Polling timer (fast 120ms tick)
        self.timer = QTimer(self)
        self.timer.setInterval(120)
        self.timer.timeout.connect(self._tick)
        self.timer.start()

        # Tray icon so it lives peacefully in taskbar notification tray
        self._setup_tray()

    def _setup_tray(self):
        ico_file = r"D:\THESUPERMOUSE\thesupermouse\assets\hud_icons\supermouse_logo.ico"
        self.tray = QSystemTrayIcon(self)
        if os.path.exists(ico_file):
            self.tray.setIcon(QIcon(ico_file))
        self.tray.setToolTip("Antigravity Live Progress HUD (Shift + Win + P)")

        menu = QMenu()
        act_show = menu.addAction("Show / Toggle HUD (Shift + Win + P)")
        act_show.triggered.connect(self.toggle_visibility)
        menu.addSeparator()
        act_exit = menu.addAction("Quit")
        act_exit.triggered.connect(QApplication.instance().quit)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(lambda r: self.toggle_visibility() if r == QSystemTrayIcon.Trigger else None)
        self.tray.show()

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 6, 6, 6)

        self.panel = QFrame(self)
        self.panel.setStyleSheet("""
            QFrame {
                background: qradialgradient(cx:0.5, cy:0.5, radius:0.85, fx:0.5, fy:0.5,
                    stop:0 rgba(14, 22, 17, 0.96),
                    stop:0.8 rgba(10, 15, 12, 0.98),
                    stop:1.0 rgba(16, 25, 18, 0.96));
                border: 1.2px solid rgba(207, 255, 72, 0.35);
                border-radius: 18px;
            }
        """)

        glow = QGraphicsDropShadowEffect(self)
        glow.setBlurRadius(24)
        glow.setColor(QColor(0, 0, 0, 140))
        glow.setOffset(0, 4)
        self.panel.setGraphicsEffect(glow)

        p_lay = QVBoxLayout(self.panel)
        p_lay.setContentsMargins(14, 10, 14, 10)
        p_lay.setSpacing(6)

        # Header Row
        hdr = QHBoxLayout()
        hdr.setContentsMargins(0, 0, 0, 0)

        self.lbl_pulse = QLabel("●  ANTIGRAVITY ACTIVE", self.panel)
        self.lbl_pulse.setStyleSheet("""
            color: #CFFF48;
            font-family: 'Segoe UI Variable', -apple-system, sans-serif;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 0.8px;
        """)
        hdr.addWidget(self.lbl_pulse)
        hdr.addStretch()

        grab = QLabel(self.panel)
        grab.setFixedSize(40, 4)
        grab.setStyleSheet("background: rgba(255, 255, 255, 0.22); border-radius: 2px;")
        hdr.addWidget(grab)
        hdr.addStretch()

        # Shortcut hint
        lbl_hint = QLabel("Shift+Win+P", self.panel)
        lbl_hint.setStyleSheet("color: rgba(255,255,255,0.4); font-size: 9px; font-weight: 600;")
        hdr.addWidget(lbl_hint)

        self.btn_close = QPushButton("✕", self.panel)
        self.btn_close.setFixedSize(22, 22)
        self.btn_close.setCursor(Qt.PointingHandCursor)
        self.btn_close.setToolTip("Hide overlay (Reopen anytime with Shift+Win+P or Desktop Shortcut)")
        self.btn_close.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.05);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 11px;
                font-size: 11px;
                font-weight: 700;
            }
            QPushButton:hover {
                background: rgba(255, 68, 68, 0.35);
                border-color: rgba(255, 68, 68, 0.65);
                color: #FFAAAA;
            }
        """)
        self.btn_close.clicked.connect(self.hide)
        hdr.addWidget(self.btn_close)
        p_lay.addLayout(hdr)

        # Body Row
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(12)

        self.ring = ProgressRing(self.panel)
        body.addWidget(self.ring)

        info_col = QVBoxLayout()
        info_col.setContentsMargins(0, 0, 0, 0)
        info_col.setSpacing(2)

        self.lbl_action = QLabel("Connected to Antigravity", self.panel)
        self.lbl_action.setStyleSheet("""
            color: #FFFFFF;
            font-family: 'Segoe UI Variable', -apple-system, sans-serif;
            font-size: 12px;
            font-weight: 700;
        """)
        info_col.addWidget(self.lbl_action)

        self.lbl_prompt = QLabel("Waiting for command...", self.panel)
        self.lbl_prompt.setStyleSheet("""
            color: #8E9DAE;
            font-family: 'Segoe UI Variable', -apple-system, sans-serif;
            font-size: 11px;
            font-weight: 500;
        """)
        info_col.addWidget(self.lbl_prompt)

        self.lbl_stats = QLabel("Step 0  •  Elapsed: 0s", self.panel)
        self.lbl_stats.setStyleSheet("""
            color: #CFFF48;
            font-family: 'Segoe UI Variable', -apple-system, sans-serif;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.4px;
        """)
        info_col.addWidget(self.lbl_stats)

        body.addLayout(info_col, stretch=1)
        p_lay.addLayout(body)
        outer.addWidget(self.panel)

    def _position_top_right(self):
        screen = QApplication.primaryScreen()
        if screen:
            geom = screen.availableGeometry()
            x = geom.x() + geom.width() - self.width() - 28
            y = geom.y() + 36
            self.move(x, y)

    def toggle_visibility(self):
        if self.isVisible():
            self.hide()
        else:
            self.show_and_sync()

    def show_and_sync(self):
        self.watcher.poll()
        self.show()
        self.setWindowState(self.windowState() & ~Qt.WindowMinimized | Qt.WindowActive)
        self.raise_()
        self.activateWindow()
        try:
            hwnd = int(self.winId())
            user32 = ctypes.windll.user32
            user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
            user32.SetForegroundWindow(hwnd)
        except Exception:
            pass

    def _tick(self):
        # 1. Check if Antigravity was just opened
        is_ag_now = check_antigravity_running()
        if is_ag_now and not self.antigravity_was_running:
            # Antigravity just launched! Auto-come onto screen!
            if not self.isVisible():
                self.show_and_sync()
        self.antigravity_was_running = is_ag_now

        # 2. Poll transcript for active prompts
        is_new = self.watcher.poll()
        if is_new and not self.isVisible():
            # User gave a new command! Auto-open!
            self.show_and_sync()

        # 3. Calculate target percentage
        if self.watcher.is_running:
            self.lbl_pulse.setText("●  RUNNING COMMAND...")
            self.lbl_pulse.setStyleSheet("color: #CFFF48; font-size: 10px; font-weight: 800; letter-spacing: 0.8px;")
            elapsed = self.watcher.elapsed_sec
            steps = self.watcher.step_count
            est_total_steps = max(steps + 1, 4)
            pct_steps = (steps / est_total_steps) * 80.0
            pct_time = min(15.0, elapsed * 0.8)
            self.target_progress = min(94.0, 8.0 + pct_steps + pct_time)
        elif self.watcher.is_done:
            self.lbl_pulse.setText("✓  TASK COMPLETED")
            self.lbl_pulse.setStyleSheet("color: #00FF85; font-size: 10px; font-weight: 800; letter-spacing: 0.8px;")
            self.target_progress = 100.0

        # Smooth glide towards target progress
        diff = self.target_progress - self.displayed_progress
        self.displayed_progress += diff * 0.22
        if abs(self.displayed_progress - self.target_progress) < 0.2:
            self.displayed_progress = self.target_progress

        self.ring.set_progress(self.displayed_progress, self.watcher.is_running)

        act = self.watcher.latest_tool
        if len(act) > 36:
            act = act[:33] + "..."
        self.lbl_action.setText(f"⚡ {act}" if self.watcher.is_running else f"✓ {act}")

        pr = self.watcher.prompt_text.replace("\n", " ")
        if len(pr) > 38:
            pr = pr[:35] + "..."
        self.lbl_prompt.setText(f'"{pr}"' if pr else "Waiting for prompt...")

        el = self.watcher.elapsed_sec
        steps_str = f"Step {self.watcher.step_count}"
        if self.watcher.is_running:
            est_rem = max(3, int(15 - (el % 15)))
            self.lbl_stats.setText(f"{steps_str}  •  Elapsed: {el}s  (est. ~{est_rem}s left)")
        else:
            self.lbl_stats.setText(f"{steps_str}  •  Finished in {el}s  •  100% Done")

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and self.drag_position:
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()

    def mouseReleaseEvent(self, event):
        self.drag_position = None
        event.accept()


# ══════════════════════════════════════════════════════════════════════════════
#  GLOBAL KEYBOARD HOOK (Shift + Win + P  AND  Ctrl + Shift + P)
# ══════════════════════════════════════════════════════════════════════════════
class MultiHotkeyHook:
    def __init__(self, callback):
        self.callback = callback
        self.hook = None
        self.user32 = ctypes.windll.user32
        self._setup_hook()

    def _setup_hook(self):
        HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_longlong, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
        def hook_proc(nCode, wParam, lParam):
            if nCode >= 0 and wParam == 0x0100:  # WM_KEYDOWN
                vk = ctypes.cast(lParam, ctypes.POINTER(ctypes.c_ulong)).contents.value
                if vk == 0x50:  # 'P' key
                    win_down = (self.user32.GetAsyncKeyState(0x5B) & 0x8000) or (self.user32.GetAsyncKeyState(0x5C) & 0x8000)
                    shift_down = (self.user32.GetAsyncKeyState(0x10) & 0x8000)
                    ctrl_down = (self.user32.GetAsyncKeyState(0x11) & 0x8000)
                    # Trigger on Shift + Win + P  OR  Ctrl + Shift + P
                    if (win_down and shift_down) or (ctrl_down and shift_down):
                        self.callback()
            return self.user32.CallNextHookEx(None, nCode, wParam, lParam)

        self._proc = HOOKPROC(hook_proc)
        self.user32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
        self.user32.SetWindowsHookExW.restype = wintypes.HHOOK
        self.user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
        self.user32.CallNextHookEx.restype = ctypes.c_longlong
        self.hook = self.user32.SetWindowsHookExW(13, self._proc, None, 0)

    def uninstall(self):
        if self.hook:
            self.user32.UnhookWindowsHookEx(self.hook)
            self.hook = None


def main():
    app = QApplication.instance() or QApplication(sys.argv)

    # Single-instance enforcement via QLocalServer
    socket = QLocalSocket()
    socket.connectToServer(APP_NAME)
    if socket.waitForConnected(200):
        # Already running! Send "show" command to existing instance and exit
        socket.write(b"show\n")
        socket.waitForBytesWritten(200)
        socket.close()
        sys.exit(0)

    server = QLocalServer()
    server.removeServer(APP_NAME)
    server.listen(APP_NAME)

    hud = ProgressHUD()
    hud.show()

    def on_client():
        client = server.nextPendingConnection()
        if client:
            client.waitForReadyRead(200)
            msg = client.readAll().data().decode("utf-8", errors="ignore")
            if "show" in msg:
                hud.show_and_sync()
            client.close()

    server.newConnection.connect(on_client)

    hook = MultiHotkeyHook(hud.toggle_visibility)
    import atexit
    atexit.register(hook.uninstall)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
