import os, json

with open('cursor_roles.json', 'r', encoding='utf-8') as f:
    roles = json.load(f)

html = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TheSuperMouse - Real Windows Cursors 1:1 Suite</title>
    <style>
        :root {
            --bg-deep: #050608;
            --bg-card: #0c0e12;
            --bg-card-hover: #14171d;
            --border-dim: #1d222b;
            --border-accent: #33ff77;
            --neon-start: #fcff00;
            --neon-mid: #84ff00;
            --neon-end: #00ff85;
            --text-main: #f0f4f8;
            --text-dim: #7f8a9a;
            --text-muted: #4e5666;
            --win-blue: #00bcf9;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Cascadia Code', monospace;
            user-select: none;
        }

        body {
            background-color: var(--bg-deep);
            color: var(--text-main);
            min-height: 100vh;
            padding: 30px;
            overflow-x: hidden;
        }

        .header {
            max-width: 1400px;
            margin: 0 auto 30px;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            border-bottom: 1px solid var(--border-dim);
            padding-bottom: 24px;
        }

        .title-group h1 {
            font-size: 26px;
            font-weight: 800;
            letter-spacing: 2px;
            text-transform: uppercase;
            background: linear-gradient(90deg, #ffffff 0%, var(--neon-mid) 60%, var(--neon-end) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }

        .title-group p {
            color: var(--text-dim);
            font-size: 14px;
            line-height: 1.5;
        }

        .controls {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .pill-btn {
            background: #101318;
            border: 1px solid var(--border-dim);
            color: var(--text-dim);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .pill-btn:hover {
            color: #ffffff;
            border-color: #4a5568;
            background: #171c24;
        }

        .pill-btn.active {
            color: #000000;
            background: linear-gradient(135deg, var(--neon-start), var(--neon-mid));
            border-color: transparent;
            font-weight: 700;
            box-shadow: 0 0 15px rgba(132, 255, 0, 0.3);
        }

        .suite-grid {
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 20px;
        }

        .cursor-card {
            background: var(--bg-card);
            border: 1px solid var(--border-dim);
            border-radius: 12px;
            padding: 18px;
            display: flex;
            flex-direction: column;
            gap: 14px;
            transition: all 0.25s ease;
            position: relative;
            overflow: hidden;
        }

        .cursor-card:hover {
            border-color: #2b3542;
            background: var(--bg-card-hover);
            transform: translateY(-2px);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .card-title {
            font-size: 15px;
            font-weight: 700;
            color: #ffffff;
        }

        .card-ocr {
            font-size: 10px;
            color: var(--neon-mid);
            font-family: monospace;
            background: rgba(132, 255, 0, 0.08);
            padding: 3px 6px;
            border-radius: 4px;
            border: 1px solid rgba(132, 255, 0, 0.2);
        }

        .card-file {
            font-size: 11px;
            color: var(--text-dim);
            font-family: monospace;
        }

        .view-stage {
            display: flex;
            gap: 16px;
            align-items: center;
            background: #000000;
            border: 1px solid #161a22;
            border-radius: 8px;
            padding: 16px;
            justify-content: space-around;
        }

        .preview-box {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
        }

        .preview-label {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }

        .label-win {
            color: var(--win-blue);
        }

        .label-sm {
            color: var(--neon-mid);
        }

        .pixel-canvas {
            width: 64px;
            height: 64px;
            background: #050608;
            border: 1px solid #202632;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.04) 1px, transparent 1px);
            background-size: 8px 8px;
        }

        .pixel-canvas img {
            image-rendering: pixelated;
            image-rendering: -moz-crisp-edges;
            image-rendering: crisp-edges;
            transition: transform 0.2s ease;
        }

        .scale-1x .pixel-canvas img {
            width: 32px;
            height: 32px;
        }

        .scale-2x .pixel-canvas img {
            width: 48px;
            height: 48px;
        }

        .scale-4x .pixel-canvas img {
            width: 60px;
            height: 60px;
        }

        .hover-tester {
            background: #090b0e;
            border: 1px dashed #262e3d;
            border-radius: 6px;
            padding: 10px;
            text-align: center;
            font-size: 11px;
            color: var(--text-dim);
            transition: all 0.2s ease;
        }

        .hover-tester:hover {
            border-color: var(--neon-mid);
            color: #ffffff;
            background: #0d1217;
        }

        .card-meta {
            display: flex;
            justify-content: space-between;
            font-size: 11px;
            color: var(--text-muted);
            border-top: 1px solid #14171e;
            padding-top: 10px;
        }

        /* Sandbox */
        .sandbox-section {
            max-width: 1400px;
            margin: 40px auto 0;
            background: #080a0d;
            border: 1px solid var(--border-dim);
            border-radius: 12px;
            padding: 24px;
        }

        .sandbox-title {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 6px;
            color: #ffffff;
        }

        .sandbox-sub {
            font-size: 13px;
            color: var(--text-dim);
            margin-bottom: 16px;
        }

        #streak-canvas {
            width: 100%;
            height: 220px;
            background: #000000;
            border: 1px solid #1a202c;
            border-radius: 8px;
            display: block;
            cursor: none;
        }
    </style>
</head>
<body class="scale-1x">

    <header class="header">
        <div class="title-group">
            <h1>Real Windows System Cursors (1:1 Suite)</h1>
            <p>Direct authentic extractions from <code>C:\\Windows\\Cursors</code> at real desktop pixel scale (32×32) alongside TheSuperMouse Neon design suite.</p>
        </div>
        <div class="controls">
            <div style="font-size: 12px; color: var(--text-muted); margin-right: 8px;">SCALE:</div>
            <button class="pill-btn active" onclick="setScale('1x', this)">1:1 Real (32px)</button>
            <button class="pill-btn" onclick="setScale('2x', this)">1.5x HD (48px)</button>
            <button class="pill-btn" onclick="setScale('4x', this)">Zoom Inspect</button>
        </div>
    </header>

    <main class="suite-grid">
'''

for idx, r in enumerate(roles):
    card_html = f'''
        <div class="cursor-card">
            <div class="card-header">
                <div>
                    <div class="card-title">{idx+1}. {r['name']}</div>
                    <div class="card-file">{r['real_file']}</div>
                </div>
                <div class="card-ocr">{r['ocr'].split()[0]}</div>
            </div>

            <div class="view-stage">
                <div class="preview-box">
                    <span class="preview-label label-win">Real Windows</span>
                    <div class="pixel-canvas">
                        <img src="{r['real_b64']}" alt="{r['name']} Real Windows">
                    </div>
                </div>
                <div style="width: 1px; height: 50px; background: #161a22;"></div>
                <div class="preview-box">
                    <span class="preview-label label-sm">TheSuperMouse</span>
                    <div class="pixel-canvas">
                        <img src="{r['sm_b64']}" alt="{r['name']} SuperMouse">
                    </div>
                </div>
            </div>

            <div class="hover-tester" style="cursor: url('{r['real_b64']}') {r['hotspot']}, auto;">
                Hover Here to Test Real Windows Cursor
            </div>

            <div class="card-meta">
                <span>Hotspot: ({r['hotspot']})</span>
                <span>{r['desc']}</span>
            </div>
        </div>
    '''
    html += card_html

html += '''
    </main>

    <section class="sandbox-section">
        <div class="sandbox-title">Aerodynamic Wind Streak Physics Sandbox</div>
        <div class="sandbox-sub">Move your cursor rapidly across this canvas to witness dynamic opposing air streaks reacting in real time (60 FPS).</div>
        <canvas id="streak-canvas"></canvas>
    </section>

    <script>
        function setScale(scale, btn) {
            document.body.className = 'scale-' + scale;
            document.querySelectorAll('.controls .pill-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        }

        // Particle Physics for Sandbox
        const canvas = document.getElementById('streak-canvas');
        const ctx = canvas.getContext('2d');

        function resize() {
            canvas.width = canvas.parentElement.clientWidth - 48;
            canvas.height = 220;
        }
        window.addEventListener('resize', resize);
        resize();

        let mouse = { x: -100, y: -100, prevX: -100, prevY: -100, speed: 0, vx: 0, vy: 0 };
        let particles = [];

        canvas.addEventListener('mousemove', (e) => {
            const rect = canvas.getBoundingClientRect();
            const curX = e.clientX - rect.left;
            const curY = e.clientY - rect.top;

            if (mouse.x > 0) {
                mouse.vx = curX - mouse.x;
                mouse.vy = curY - mouse.y;
                mouse.speed = Math.hypot(mouse.vx, mouse.vy);
            }

            mouse.x = curX;
            mouse.y = curY;

            // Spawn streaks if moving fast
            if (mouse.speed > 3) {
                const count = Math.min(4, Math.floor(mouse.speed / 5) + 1);
                for (let i = 0; i < count; i++) {
                    const angle = Math.atan2(mouse.vy, mouse.vx) + Math.PI + (Math.random() - 0.5) * 0.4;
                    const spd = (Math.random() * 0.4 + 0.6) * mouse.speed * 0.8;
                    particles.push({
                        x: mouse.x + (Math.random() - 0.5) * 6,
                        y: mouse.y + (Math.random() - 0.5) * 6,
                        vx: Math.cos(angle) * spd,
                        vy: Math.sin(angle) * spd,
                        alpha: 0.9,
                        width: Math.random() * 2 + 1,
                        length: Math.random() * 14 + 10,
                        color: Math.random() > 0.5 ? '#84ff00' : '#00ff85'
                    });
                }
            }
        });

        canvas.addEventListener('mouseleave', () => {
            mouse.x = -100;
            mouse.y = -100;
        });

        function animate() {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Update & draw particles
            for (let i = particles.length - 1; i >= 0; i--) {
                const p = particles[i];
                p.x += p.vx;
                p.y += p.vy;
                p.alpha -= 0.035;

                if (p.alpha <= 0) {
                    particles.splice(i, 1);
                    continue;
                }

                ctx.save();
                ctx.globalAlpha = p.alpha;
                ctx.strokeStyle = p.color;
                ctx.lineWidth = p.width;
                ctx.beginPath();
                ctx.moveTo(p.x, p.y);
                ctx.lineTo(p.x - p.vx * 1.5, p.y - p.vy * 1.5);
                ctx.stroke();
                ctx.restore();
            }

            // Draw cursor head if in canvas
            if (mouse.x > 0 && mouse.y > 0) {
                ctx.save();
                ctx.fillStyle = '#fcff00';
                ctx.shadowColor = '#84ff00';
                ctx.shadowBlur = 8;
                ctx.beginPath();
                ctx.arc(mouse.x, mouse.y, 4, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            }

            requestAnimationFrame(animate);
        }
        animate();
    </script>
</body>
</html>
'''

with open(r'D:\THESUPERMOUSE\preview.html', 'w', encoding='utf-8') as f:
    f.write(html)

print(r'Successfully generated D:\THESUPERMOUSE\preview.html')

