# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE — SHA-256 Delta Patch Builder (for GitHub Releases)
Compares OLD build folder (e.g. 200 MB) vs NEW build folder (e.g. 220 MB) using SHA-256:
  - Identifies exact ADD, REPLACE, DELETE, and SKIP files.
  - Packs ONLY added & replaced files + manifest.json into patch_v<VER>.zip.
  - Generates version.json (for GitHub Releases) + PATCH_README.txt summary.

Usage:
  python tools/make_patch.py --old "C:\\builds\\v1.3" --new "C:\\builds\\v1.4" --ver "1.4" ^
      --headline "Speed & Vibe Upgrade" --subtext "Faster beaming and instant UI sync." ^
      --repo "YOUR_GITHUB/thesupermouse-releases"
"""
import argparse
import hashlib
import json
import os
import zipfile
from datetime import datetime, timedelta, timezone

IST_TZ = timezone(timedelta(hours=5, minutes=30))
IGNORE_DIRS = {"__pycache__", ".git", ".venv", "venv"}


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest().lower()


def scan_folder(folder: str) -> dict:
    hashes = {}
    for root, dirs, files in os.walk(folder):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        for fn in files:
            full = os.path.join(root, fn)
            rel = os.path.relpath(full, folder).replace("\\", "/")
            hashes[rel] = sha256_file(full)
    return hashes


def build_patch(old_dir: str, new_dir: str, out_dir: str, version: str, headline: str, subtext: str, repo: str):
    os.makedirs(out_dir, exist_ok=True)
    old_map = scan_folder(old_dir)
    new_map = scan_folder(new_dir)

    added, replaced, deleted, skipped = [], [], [], []
    for rel, new_hash in sorted(new_map.items()):
        if rel not in old_map:
            added.append(rel)
        elif old_map[rel] != new_hash:
            replaced.append(rel)
        else:
            skipped.append(rel)

    for rel in sorted(old_map.keys()):
        if rel not in new_map:
            deleted.append(rel)

    patch_name = f"patch_v{version}.zip"
    patch_path = os.path.join(out_dir, patch_name)
    sha_manifest = {rel: new_map[rel] for rel in added + replaced}
    today_str = datetime.now(IST_TZ).strftime("%d %b %Y")

    manifest = {
        "version": version,
        "date": today_str,
        "headline": headline,
        "subtext": subtext,
        "add": added,
        "replace": replaced,
        "delete": deleted,
        "skip_count": len(skipped),
        "sha256": sha_manifest,
    }

    with zipfile.ZipFile(patch_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        zf.writestr("manifest.json", json.dumps(manifest, indent=2))
        for rel in added + replaced:
            zf.write(os.path.join(new_dir, rel), arcname=f"files/{rel}")

    size_mb = round(os.path.getsize(patch_path) / (1024 * 1024), 2)
    base_url = f"https://github.com/{repo}/releases/latest/download"

    version_json = {
        "version": version,
        "headline": headline,
        "subtext": subtext,
        "size_mb": size_mb,
        "date": today_str,
        "patch_url": f"{base_url}/{patch_name}",
        "full_url": f"{base_url}/TheSuperMouse_Full.zip",
        "add": added,
        "replace": replaced,
        "delete": deleted,
        "skip_count": len(skipped),
        "sha256": sha_manifest,
    }

    ver_out = os.path.join(out_dir, "version.json")
    with open(ver_out, "w", encoding="utf-8") as vf:
        json.dump(version_json, vf, indent=2)

    readme_out = os.path.join(out_dir, "PATCH_README.txt")
    with open(readme_out, "w", encoding="utf-8") as rf:
        rf.write(
            f"THE SUPER MOUSE — PATCH v{version} ({today_str})\n"
            f"Headline : {headline}\n"
            f"Details  : {subtext}\n"
            f"Patch Zip: {patch_name} ({size_mb} MB)\n"
            f"Summary  : +{len(added)} Added | ~{len(replaced)} Replaced | -{len(deleted)} Deleted | {len(skipped)} Skipped\n\n"
            f"ADDED:\n" + ("\n".join(f"  + {x}" for x in added) or "  (none)") + "\n\n"
            f"REPLACED:\n" + ("\n".join(f"  ~ {x}" for x in replaced) or "  (none)") + "\n\n"
            f"DELETED:\n" + ("\n".join(f"  - {x}" for x in deleted) or "  (none)") + "\n"
        )

    print(f"DONE -> {patch_path} ({size_mb} MB)")
    print(f"       +{len(added)} add | ~{len(replaced)} replace | -{len(deleted)} delete | {len(skipped)} skipped")
    print(f"       Manifest: {ver_out} | Readme: {readme_out}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Build SHA-256 delta patch for THE SUPER MOUSE")
    ap.add_argument("--old", required=True, help="Old build directory")
    ap.add_argument("--new", required=True, help="New build directory")
    ap.add_argument("--out", default="dist_patch", help="Output folder")
    ap.add_argument("--ver", required=True, help="New version string (e.g. 1.4)")
    ap.add_argument("--headline", required=True, help="Update headline")
    ap.add_argument("--subtext", required=True, help="Update details paragraph")
    ap.add_argument("--repo", default="getsupermouse/supermousenewnupdates", help="GitHub owner/repo")
    args = ap.parse_args()
    build_patch(args.old, args.new, args.out, args.ver, args.headline, args.subtext, args.repo)
