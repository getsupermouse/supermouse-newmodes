# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - WINDOWS HKCU CONTEXT MENU & SHORTCUTS INTEGRATION
===================================================================
Registers user-scope (HKCU, zero admin needed) context-menu verbs cleanly:
  - Folder selected (Directory\\shell): SuperMouse & Super Snap & Pin
  - Background right-click (Directory\\Background\\shell): SuperMouse & Super Snap & Pin (bottom position)
  - File Share menu (*\\shell\\Z_SuperShare): SuperShare via SuperMouse
Note: Windows 11 modern top-level XAML menu restricts unpackaged static verbs to
"Show more options" / classic context menu unless packaged as an MSIX IExplorerCommand.
"""

import os
import sys
import uuid
import ctypes
import winreg
import threading
import subprocess
import urllib.request


def _find_base_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    cur = os.path.abspath(__file__)
    for _ in range(6):
        cur = os.path.dirname(cur)
        if os.path.isdir(os.path.join(cur, "thesupermouse", "assets")):
            return cur
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BASE_DIR = _find_base_dir()
MAIN_APP_PY = os.path.join(BASE_DIR, "main_app.py")
ICON_ICO = os.path.join(BASE_DIR, "thesupermouse", "assets", "supermouse_taskbar_icon.ico")
WIN11_SHELL_DIR = os.path.join(BASE_DIR, "thesupermouse", "win11_shell")
APPX_MANIFEST = os.path.join(WIN11_SHELL_DIR, "AppxManifest.xml")
IPC_PORT = 47292


def _pythonw_exe():
    exe = sys.executable or "python.exe"
    pw = os.path.join(os.path.dirname(exe), "pythonw.exe")
    return pw if os.path.exists(pw) else exe


def _reg_set_verb(base_key_path, verb_name, title, cli_flag, bottom=False):
    key_path = f"{base_key_path}\\{verb_name}"
    if getattr(sys, "frozen", False):
        cmd_str = f'"{os.path.abspath(sys.executable)}" {cli_flag}'
    else:
        py = _pythonw_exe()
        cmd_str = f'"{py}" "{MAIN_APP_PY}" {cli_flag}'
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path) as k:
        winreg.SetValueEx(k, "", 0, winreg.REG_SZ, title)
        winreg.SetValueEx(k, "MUIVerb", 0, winreg.REG_SZ, title)
        if os.path.exists(ICON_ICO):
            winreg.SetValueEx(k, "Icon", 0, winreg.REG_SZ, ICON_ICO)
        if bottom:
            winreg.SetValueEx(k, "Position", 0, winreg.REG_SZ, "Bottom")
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, f"{key_path}\\command") as ck:
        winreg.SetValueEx(ck, "", 0, winreg.REG_SZ, cmd_str)


def register_windows_context_menus():
    """Register HKCU context menu entries on Desktop/Folder Background, Folders & Files."""
    try:
        # 1. Right-click on Folder (shows SuperMouse + Super Snap & Pin)
        _reg_set_verb(
            r"Software\Classes\Directory\shell",
            "Z_01_TheSuperMouse",
            "SuperMouse",
            "--menu",
            bottom=True,
        )
        _reg_set_verb(
            r"Software\Classes\Directory\shell",
            "Z_02_TheSuperPin",
            "Super Snap && Pin",
            "--superpin",
            bottom=True,
        )
        # 2. Right-click on Desktop / Explorer Background (bottom position)
        _reg_set_verb(
            r"Software\Classes\Directory\Background\shell",
            "Z_01_TheSuperMouse",
            "SuperMouse",
            "--menu",
            bottom=True,
        )
        _reg_set_verb(
            r"Software\Classes\Directory\Background\shell",
            "Z_02_TheSuperPin",
            "Super Snap && Pin",
            "--superpin",
            bottom=True,
        )
        # 3. Right-click on any file (SuperShare entry at bottom)
        _reg_set_verb(
            r"Software\Classes\*\shell",
            "Z_03_TheSuperShare",
            "SuperShare (SuperMouse)",
            '--supershare "%1"',
            bottom=True,
        )

        # 4. Ensure Win11 First-Level Modern Context Menu Sparse Package is registered
        if os.path.exists(APPX_MANIFEST):
            try:
                ps_cmd = (
                    f'if (-not (Get-AppxPackage "TheSuperMouse.ShellMenu")) {{ '
                    f'Add-AppxPackage -Register "{APPX_MANIFEST}" -ExternalLocation "{WIN11_SHELL_DIR}" }}'
                )
                subprocess.Popen(
                    ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps_cmd],
                    creationflags=0x08000000,
                )
            except Exception:
                pass
        return True
    except Exception:
        return False


def is_context_menus_registered():
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Classes\Directory\shell\Z_01_TheSuperMouse\command",
            0,
            winreg.KEY_READ,
        ):
            return True
    except Exception:
        return False


def unregister_windows_context_menus():
    paths = [
        r"Software\Classes\Directory\shell\Z_01_TheSuperMouse",
        r"Software\Classes\Directory\shell\Z_02_TheSuperPin",
        r"Software\Classes\Directory\Background\shell\Z_01_TheSuperMouse",
        r"Software\Classes\Directory\Background\shell\Z_02_TheSuperPin",
        r"Software\Classes\*\shell\Z_03_TheSuperShare",
    ]
    for p in paths:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, f"{p}\\command")
        except Exception:
            pass
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, p)
        except Exception:
            pass


def send_ipc_command(cmd="menu"):
    """Instant <10ms trigger to running main_app.py instance over loopback HTTP."""
    try:
        url = f"http://127.0.0.1:{IPC_PORT}/{cmd.lstrip('/')}"
        urllib.request.urlopen(url, timeout=0.6).read()
        return True
    except Exception:
        return False


def prewarm_win11_shell_server():
    """
    Pre-warm the Win11 IExplorerCommand COM server in background via CoCreateInstance
    so the very first Win11 right-click has ZERO cold-start pop-in glitch.
    """
    def _warm():
        try:
            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            evt = k32.CreateEventW(None, True, False, "SuperMouse_ShellHost_Shutdown")
            if evt:
                k32.ResetEvent(evt)
                k32.CloseHandle(evt)
        except Exception:
            pass

        try:
            ole32 = ctypes.OleDLL("ole32")
            ole32.CoInitializeEx(None, 2)

            class _GUID(ctypes.Structure):
                _fields_ = [
                    ("Data1", ctypes.c_uint32),
                    ("Data2", ctypes.c_uint16),
                    ("Data3", ctypes.c_uint16),
                    ("Data4", ctypes.c_ubyte * 8),
                ]
                def __init__(self, s):
                    u = uuid.UUID(s)
                    self.Data1, self.Data2, self.Data3 = u.fields[:3]
                    b = u.bytes[8:]
                    for i in range(8):
                        self.Data4[i] = b[i]

            clsid = _GUID("E1A11111-4F3A-4E8B-9C11-112233440001")
            iid = _GUID("a08ce4d0-fa25-44ab-b57c-c7b1c323e0b9")
            ppv = ctypes.c_void_p()
            hr = ole32.CoCreateInstance(ctypes.byref(clsid), None, 4, ctypes.byref(iid), ctypes.byref(ppv))
            if hr == 0 and ppv.value:
                vtbl = ctypes.cast(ctypes.cast(ppv, ctypes.POINTER(ctypes.c_void_p))[0], ctypes.POINTER(ctypes.c_void_p))
                release = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtbl[2])
                release(ppv)
            ole32.CoUninitialize()
        except Exception:
            pass

    threading.Thread(target=_warm, daemon=True).start()


def stop_win11_shell_server():
    try:
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        evt = k32.OpenEventW(0x0002, False, "SuperMouse_ShellHost_Shutdown")
        if evt:
            k32.SetEvent(evt)
            k32.CloseHandle(evt)
    except Exception:
        pass

