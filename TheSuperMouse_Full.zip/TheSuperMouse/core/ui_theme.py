# -*- coding: utf-8 -*-
# pyright: reportAttributeAccessIssue=none, reportGeneralTypeIssues=none, reportOptionalMemberAccess=none
from __future__ import annotations
"""
THE SUPER MOUSE - UNIFIED OBSIDIAN UI DESIGN SYSTEM & COMMON ICON REGISTRY
===========================================================================
Single source of truth shared across Quick Menu, Super Snap & Pin, My Box,
SuperSupDesign, Access, Info, and Action Runner:
  - Consistent 24x24 Lucide vector outline icons everywhere (Back, Home, Cross, Scissors/Snip, Search, Copy, etc.)
  - Invisible-container icon buttons: fixed generous clickable hit-boxes with ZERO visible bordered box at rest
  - Restrained 90/8/2 obsidian palette (#040405 canvas, crisp neutral hierarchy, disciplined #a3e635 accent)
  - Whisper-thin floating pill scrollbar (SLIM_SCROLLBAR_QSS) with zero checkered Qt page tracks
"""

import os
import sys
from functools import lru_cache

from PySide6.QtCore import Qt, QByteArray, QRectF, QTimer, Signal
from PySide6.QtGui import (
    QPainter, QPainterPath, QColor, QPen, QPixmap, QCursor, QIcon,
)
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import QApplication, QPushButton, QWidget


def get_base_dir() -> str:
    """Return the absolute path to the root folder containing the real 'thesupermouse/assets'."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    cur = os.path.abspath(__file__)
    for _ in range(6):
        cur = os.path.dirname(cur)
        if os.path.isdir(os.path.join(cur, "thesupermouse", "assets")):
            return cur
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


BASE_DIR = get_base_dir()
ASSETS_DIR = os.path.join(BASE_DIR, "thesupermouse", "assets")
BOX_DIR = os.path.join(BASE_DIR, "thesupermouse", "superclipboard_box")


# ─── Unified Obsidian Design Tokens ─────────────────────────────────────────
BG_OBSIDIAN = "#040405"
SURFACE_SUBTLE = "#0C0D10"
SURFACE_HOVER = "#15171B"
BORDER_HAIRLINE = "rgba(255, 255, 255, 0.08)"
TEXT_PRIMARY = "#F4F4F5"
TEXT_SECONDARY = "#9CA3AF"
TEXT_MUTED = "#71717A"
ACCENT_LIME = "#a3e635"


def format_count_label(count: int, singular: str, plural: str | None = None) -> str:
    n = max(0, int(count))
    pl = plural or f"{singular}s"
    return f"{n} {singular if n == 1 else pl}"


def native_dpr(widget=None) -> float:
    try:
        if widget is not None:
            d = float(widget.devicePixelRatioF())
            if d > 0.5:
                return d
        scr = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        if scr is not None:
            return max(1.0, float(scr.devicePixelRatio()))
    except Exception:
        pass
    return 1.0


# ─── Single Unified Common Icon Set (Filled Icons + Bold Geometric Strokes) ─
_PEN_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><path fill="{col}" d="m243.31 81.36l-68.68-68.68a16 16 0 0 0-22.63 0l-28.44 28.44l-58 21.76a16 16 0 0 0-10.2 12.35l-20.77 124.6a4 4 0 0 0 6.77 3.49l57-57a23.85 23.85 0 0 1-2.29-12.08a24 24 0 1 1 13.6 23.4l-57 57a4 4 0 0 0 3.49 6.77l124.61-20.77a16 16 0 0 0 12.35-10.16l21.77-58.07L243.31 104a16 16 0 0 0 0-22.63ZM208 116.68L139.32 48l24-24L232 92.68Z"/></svg>'
_HIGHLIGHTER_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="{col}" d="M5.25 2A2.25 2.25 0 0 0 3 4.25v3A2.25 2.25 0 0 0 5.25 9.5h13.5A2.25 2.25 0 0 0 21 7.25v-3A2.25 2.25 0 0 0 18.75 2zM5 11.75V11h14v.75A2.25 2.25 0 0 1 16.75 14h-9.5A2.25 2.25 0 0 1 5 11.75m2.503 3.75H16.5v1.288a2.25 2.25 0 0 1-1.141 1.958l-.154.08l-6.635 3.106a.75.75 0 0 1-1.061-.578l-.007-.101z"/></svg>'
_ERASER_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><path fill="{col}" d="M225 80.4L183.6 39a24 24 0 0 0-33.94 0L31 157.66a24 24 0 0 0 0 33.94l30.06 30.06a8 8 0 0 0 5.68 2.34H216a8 8 0 0 0 0-16h-84.7l93.7-93.66a24 24 0 0 0 0-33.94M213.67 103L160 156.69L107.31 104L161 50.34a8 8 0 0 1 11.32 0l41.38 41.38a8 8 0 0 1 0 11.31Z"/></svg>'
_SHAPES_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><path fill="{col}" d="M111.59 181.47A8 8 0 0 1 104 192H24a8 8 0 0 1-7.59-10.53l40-120a8 8 0 0 1 15.18 0ZM208 76a52 52 0 1 0-52 52a52.06 52.06 0 0 0 52-52m16 68h-88a8 8 0 0 0-8 8v56a8 8 0 0 0 8 8h88a8 8 0 0 0 8-8v-56a8 8 0 0 0-8-8"/></svg>'
_RECT_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><path fill="{col}" d="M224 48v160a16 16 0 0 1-16 16H48a16 16 0 0 1-16-16V48a16 16 0 0 1 16-16h160a16 16 0 0 1 16 16"/></svg>'
_CIRCLE_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><path fill="{col}" d="M232 128A104 104 0 1 1 128 24a104.13 104.13 0 0 1 104 104"/></svg>'
_SPARKLES_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="{col}" d="M15.98 1.804a1 1 0 0 0-1.96 0l-.24 1.192a1 1 0 0 1-.784.785l-1.192.238a1 1 0 0 0 0 1.962l1.192.238a1 1 0 0 1 .785.785l.238 1.192a1 1 0 0 0 1.962 0l.238-1.192a1 1 0 0 1 .785-.785l1.192-.238a1 1 0 0 0 0-1.962l-1.192-.238a1 1 0 0 1-.785-.785zm-9.031 3.88a1 1 0 0 0-1.898 0l-.683 2.051a1 1 0 0 1-.633.633l-2.051.683a1 1 0 0 0 0 1.898l2.051.684a1 1 0 0 1 .633.632l.683 2.051a1 1 0 0 0 1.898 0l.683-2.051a1 1 0 0 1 .633-.633l2.051-.683a1 1 0 0 0 0-1.898l-2.051-.683a1 1 0 0 1-.633-.633zm7 8a1 1 0 0 0-1.898 0l-.184.551a1 1 0 0 1-.632.633l-.551.183a1 1 0 0 0 0 1.898l.551.183a1 1 0 0 1 .633.633l.183.551a1 1 0 0 0 1.898 0l.184-.551a1 1 0 0 1 .632-.633l.551-.183a1 1 0 0 0 0-1.898l-.551-.184a1 1 0 0 1-.633-.632z"/></svg>'
_SCAN_BOLD_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="{col}" fill-rule="evenodd" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12ZM10.004 5.7517C10.4182 5.7495 10.7522 5.41194 10.75 4.99773C10.7478 4.58353 10.4102 4.24952 9.99602 4.25172C8.91427 4.25745 8.01583 4.28215 7.28261 4.41042C6.53075 4.54195 5.88786 4.79244 5.36144 5.29379C4.90634 5.72721 4.60191 6.16616 4.43626 6.79676C4.28612 7.36833 4.25937 8.07154 4.25231 8.99426C4.24914 9.40846 4.58234 9.74681 4.99654 9.74998C5.41074 9.75315 5.74909 9.41994 5.75226 9.00574C5.75952 8.05697 5.79204 7.53952 5.88704 7.17786C5.96654 6.87522 6.09314 6.66836 6.39592 6.38C6.63788 6.14955 6.96814 5.98821 7.54109 5.88798C8.13268 5.78449 8.91071 5.75749 10.004 5.7517ZM14.0041 4.25172C13.5899 4.24952 13.2523 4.58352 13.2501 4.99773C13.2479 5.41194 13.5819 5.7495 13.9961 5.7517C15.0894 5.7575 15.8674 5.78449 16.4589 5.88799C17.0319 5.98822 17.3621 6.14956 17.6041 6.37999C17.9069 6.66835 18.0335 6.87522 18.113 7.17786C18.208 7.53952 18.2405 8.05697 18.2477 9.00574C18.2509 9.41994 18.5893 9.75315 19.0035 9.74998C19.4177 9.74681 19.7509 9.40846 19.7477 8.99426C19.7406 8.07154 19.7139 7.36833 19.5637 6.79676C19.3981 6.16616 19.0937 5.72721 18.6386 5.29379C18.1121 4.79244 17.4693 4.54196 16.7174 4.41043C15.9842 4.28216 15.0858 4.25746 14.0041 4.25172ZM5 11.2501C4.58579 11.2501 4.25 11.5858 4.25 12.0001C4.25 12.4143 4.58579 12.7501 5 12.7501H19C19.4142 12.7501 19.75 12.4143 19.75 12.0001C19.75 11.5858 19.4142 11.2501 19 11.2501H5ZM5.75226 14.9944C5.74909 14.5802 5.41074 14.247 4.99654 14.2501C4.58234 14.2533 4.24914 14.5916 4.25231 15.0058C4.25937 15.9286 4.28612 16.6318 4.43626 17.2034C4.60191 17.8339 4.90634 18.2729 5.36144 18.7063C5.88785 19.2077 6.53073 19.4581 7.28258 19.5897C8.01578 19.718 8.91421 19.7427 9.99593 19.7484C10.4101 19.7506 10.7477 19.4166 10.7499 19.0024C10.7521 18.5882 10.4181 18.2506 10.0039 18.2484C8.91065 18.2426 8.13264 18.2156 7.54107 18.1121C6.96814 18.0119 6.63788 17.8506 6.39592 17.6201C6.09314 17.3318 5.96654 17.1249 5.88704 16.8223C5.79204 16.4606 5.75952 15.9431 5.75226 14.9944ZM19.7477 15.0058C19.7509 14.5916 19.4177 14.2533 19.0035 14.2501C18.5893 14.247 18.2509 14.5802 18.2477 14.9944C18.2405 15.9431 18.208 16.4606 18.113 16.8223C18.0335 17.1249 17.9069 17.3318 17.6041 17.6201C17.3621 17.8506 17.0319 18.0119 16.4589 18.1121C15.8674 18.2156 15.0894 18.2426 13.9961 18.2484C13.5819 18.2506 13.2479 18.5882 13.2501 19.0024C13.2523 19.4166 13.5899 19.7506 14.0041 19.7484C15.0858 19.7427 15.9842 19.718 16.7174 19.5897C17.4693 19.4581 18.1121 19.2077 18.6386 18.7063C19.0937 18.2729 19.3981 17.8339 19.5637 17.2034C19.7139 16.6318 19.7406 15.9286 19.7477 15.0058Z" clip-rule="evenodd"/></svg>'
_SAVE_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><g fill="{col}"><path d="M10.75 2.75a.75.75 0 0 0-1.5 0v8.614L6.295 8.235a.75.75 0 1 0-1.09 1.03l4.25 4.5a.75.75 0 0 0 1.09 0l4.25-4.5a.75.75 0 0 0-1.09-1.03l-2.955 3.129z"/><path d="M3.5 12.75a.75.75 0 0 0-1.5 0v2.5A2.75 2.75 0 0 0 4.75 18h10.5A2.75 2.75 0 0 0 18 15.25v-2.5a.75.75 0 0 0-1.5 0v2.5c0 .69-.56 1.25-1.25 1.25H4.75c-.69 0-1.25-.56-1.25-1.25z"/></g></svg>'
_COPY_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><g fill="{col}"><path d="M2 4.25A2.25 2.25 0 0 1 4.25 2h6.5A2.25 2.25 0 0 1 13 4.25V5.5H9.25A3.75 3.75 0 0 0 5.5 9.25V13H4.25A2.25 2.25 0 0 1 2 10.75z"/><path d="M9.25 7A2.25 2.25 0 0 0 7 9.25v6.5A2.25 2.25 0 0 0 9.25 18h6.5A2.25 2.25 0 0 0 18 15.75v-6.5A2.25 2.25 0 0 0 15.75 7z"/></g></svg>'
_SHARE_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="{col}" d="M13 4.5a2.5 2.5 0 1 1 .702 1.737L6.97 9.604a2.5 2.5 0 0 1 0 .792l6.733 3.367a2.5 2.5 0 1 1-.671 1.341l-6.733-3.367a2.5 2.5 0 1 1 0-3.475l6.733-3.366A2.5 2.5 0 0 1 13 4.5"/></svg>'
_SUPERSHARE_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="{col}" d="M14 2H10C6.22876 2 4.34315 2 3.17157 3.17157C2 4.34315 2 6.22876 2 10V11C2 11.5516 2 12.0494 2.00652 12.5H12.6017C12.7054 11.8207 12.9376 11.1127 13.5251 10.5251C14.1432 9.90708 14.8946 9.68219 15.6056 9.5866C16.2512 9.4998 17.0449 9.49989 17.9105 9.49999H18.0895C18.9551 9.49989 19.7488 9.4998 20.3944 9.5866C20.9315 9.65881 21.4917 9.80481 22 10.1383V10C22 6.22876 22 4.34315 20.8284 3.17157C19.6569 2 17.7712 2 14 2Z"/><path fill="{col}" d="M2.87868 16.1213C3.75736 17 5.17157 17 8 17H11.25V21H8C7.58579 21 7.25 21.3358 7.25 21.75C7.25 22.1642 7.58579 22.5 8 22.5H13.5505L13.5251 22.4749C12.9071 21.8568 12.6822 21.1054 12.5866 20.3944C12.4998 19.7488 12.4999 18.9551 12.5 18.0895V14.9105C12.4999 14.4116 12.4999 13.9365 12.5165 13.5H2.03835C2.10893 14.7579 2.30938 15.552 2.87868 16.1213Z"/><path fill="{col}" fill-rule="evenodd" d="M22 15V18C22 19.8856 22 20.8284 21.4142 21.4142C20.8284 22 19.8856 22 18 22C16.1144 22 15.1716 22 14.5858 21.4142C14 20.8284 14 19.8856 14 18V15C14 13.1144 14 12.1716 14.5858 11.5858C15.1716 11 16.1144 11 18 11C19.8856 11 20.8284 11 21.4142 11.5858C22 12.1716 22 13.1144 22 15ZM16.25 20C16.25 19.5858 16.5858 19.25 17 19.25H19C19.4142 19.25 19.75 19.5858 19.75 20C19.75 20.4142 19.4142 20.75 19 20.75H17C16.5858 20.75 16.25 20.4142 16.25 20Z" clip-rule="evenodd"/></svg>'
_BOX_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="{col}" d="M17.5777 4.43152L15.5777 3.38197C13.8221 2.46066 12.9443 2 12 2C11.0557 2 10.1779 2.46066 8.42229 3.38197L8.10057 3.5508L17.0236 8.64967L21.0403 6.64132C20.3941 5.90949 19.3515 5.36234 17.5777 4.43152Z"/><path fill="{col}" d="M21.7484 7.96434L17.75 9.96353V13C17.75 13.4142 17.4142 13.75 17 13.75C16.5858 13.75 16.25 13.4142 16.25 13V10.7135L12.75 12.4635V21.904C13.4679 21.7252 14.2848 21.2965 15.5777 20.618L17.5777 19.5685C19.7294 18.4393 20.8052 17.8748 21.4026 16.8603C22 15.8458 22 14.5833 22 12.0585V11.9415C22 10.0489 22 8.86557 21.7484 7.96434Z"/><path fill="{col}" d="M11.25 21.904V12.4635L2.25164 7.96434C2 8.86557 2 10.0489 2 11.9415V12.0585C2 14.5833 2 15.8458 2.5974 16.8603C3.19479 17.8748 4.27062 18.4393 6.42228 19.5685L8.42229 20.618C9.71524 21.2965 10.5321 21.7252 11.25 21.904Z"/><path fill="{col}" d="M2.95969 6.64132L12 11.1615L15.4112 9.4559L6.52456 4.37785L6.42229 4.43152C4.64855 5.36234 3.6059 5.90949 2.95969 6.64132Z"/></svg>'
_HOME_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="{col}" fill-rule="evenodd" d="M9.293 2.293a1 1 0 0 1 1.414 0l7 7A1 1 0 0 1 17 11h-1v6a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-6H3a1 1 0 0 1-.707-1.707z" clip-rule="evenodd"/></svg>'
_TRASH_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="{col}" fill-rule="evenodd" d="M8.75 1A2.75 2.75 0 0 0 6 3.75v.443q-1.193.115-2.365.298a.75.75 0 1 0 .23 1.482l.149-.022l.841 10.518A2.75 2.75 0 0 0 7.596 19h4.807a2.75 2.75 0 0 0 2.742-2.53l.841-10.52l.149.023a.75.75 0 0 0 .23-1.482A41 41 0 0 0 14 4.193V3.75A2.75 2.75 0 0 0 11.25 1zM10 4q1.26 0 2.5.075V3.75c0-.69-.56-1.25-1.25-1.25h-2.5c-.69 0-1.25.56-1.25 1.25v.325Q8.74 4 10 4M8.58 7.72a.75.75 0 0 0-1.5.06l.3 7.5a.75.75 0 1 0 1.5-.06zm4.34.06a.75.75 0 1 0-1.5-.06l-.3 7.5a.75.75 0 1 0 1.5.06z" clip-rule="evenodd"/></svg>'
_PENCIL_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="{col}" d="M21.1938 2.80624C22.2687 3.88124 22.2687 5.62415 21.1938 6.69914L20.6982 7.19469C20.5539 7.16345 20.3722 7.11589 20.1651 7.04404C19.6108 6.85172 18.8823 6.48827 18.197 5.803C17.5117 5.11774 17.1483 4.38923 16.956 3.8349C16.8841 3.62781 16.8366 3.44609 16.8053 3.30179L17.3009 2.80624C18.3759 1.73125 20.1188 1.73125 21.1938 2.80624Z"/><path fill="{col}" d="M14.5801 13.3128C14.1761 13.7168 13.9741 13.9188 13.7513 14.0926C13.4886 14.2975 13.2043 14.4732 12.9035 14.6166C12.6485 14.7381 12.3775 14.8284 11.8354 15.0091L8.97709 15.9619C8.71035 16.0508 8.41626 15.9814 8.21744 15.7826C8.01862 15.5837 7.9492 15.2897 8.03811 15.0229L8.99089 12.1646C9.17157 11.6225 9.26191 11.3515 9.38344 11.0965C9.52679 10.7957 9.70249 10.5114 9.90743 10.2487C10.0812 10.0259 10.2832 9.82394 10.6872 9.41993L15.6033 4.50385C15.867 5.19804 16.3293 6.05663 17.1363 6.86366C17.9434 7.67069 18.802 8.13296 19.4962 8.39674L14.5801 13.3128Z"/><path fill="{col}" d="M20.5355 20.5355C22 19.0711 22 16.714 22 12C22 10.4517 22 9.15774 21.9481 8.0661L15.586 14.4283C15.2347 14.7797 14.9708 15.0437 14.6738 15.2753C14.3252 15.5473 13.948 15.7804 13.5488 15.9706C13.2088 16.1327 12.8546 16.2506 12.3833 16.4076L9.45143 17.3849C8.64568 17.6535 7.75734 17.4438 7.15678 16.8432C6.55621 16.2427 6.34651 15.3543 6.61509 14.5486L7.59235 11.6167C7.74936 11.1454 7.86732 10.7912 8.02935 10.4512C8.21958 10.052 8.45272 9.6748 8.72466 9.32615C8.9563 9.02918 9.22032 8.76528 9.57173 8.41404L15.9339 2.05188C14.8423 2 13.5483 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355Z"/></svg>'

COMMON_ICONS = {
    # Core Navigation & Window Chrome (Bold Strokes + Clean Filled Home)
    "back": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4" d="m12 19l-7-7l7-7m7 7H5"/></svg>',
    "arrow_left": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4" d="m12 19l-7-7l7-7m7 7H5"/></svg>',
    "arrow_right": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4" d="M5 12h14m-7-7l7 7l-7 7"/></svg>',
    "home": _HOME_FILL_SVG,
    "house": _HOME_FILL_SVG,
    "close": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4" d="M18 6L6 18M6 6l12 12"/></svg>',
    "x": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4" d="M18 6L6 18M6 6l12 12"/></svg>',

    # Primary Tools & Shared Domain Icons
    "cursor": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M4.037 4.688a.495.495 0 0 1 .651-.651l16 6.5a.5.5 0 0 1-.063.947l-6.124 1.58a2 2 0 0 0-1.438 1.435l-1.579 6.126a.5.5 0 0 1-.947.063z"/></svg>',
    "take_snap": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2"><circle cx="6" cy="6" r="3"/><path d="M8.12 8.12L12 12m8-8L8.12 15.88"/><circle cx="6" cy="18" r="3"/><path d="M14.8 14.8L20 20"/></g></svg>',
    "scissors": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2"><circle cx="6" cy="6" r="3"/><path d="M8.12 8.12L12 12m8-8L8.12 15.88"/><circle cx="6" cy="18" r="3"/><path d="M14.8 14.8L20 20"/></g></svg>',
    "supershare": _SUPERSHARE_FILL_SVG,
    "quick_action": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M15.914 4a1.5 1.5 0 0 0-2.474-1.561l-9 9A1.5 1.5 0 0 0 5.5 14h4.002a.5.5 0 0 1 .471.666L8.086 20a1.5 1.5 0 0 0 2.475 1.56l9-9A1.5 1.5 0 0 0 18.5 10h-3.997a.5.5 0 0 1-.472-.667z"/></svg>',
    "folder": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/></svg>',
    "files": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4m-10 5H8m8 4H8m2-8H8"/></g></svg>',
    "my_box": _BOX_FILL_SVG,
    "text_extractor": _SCAN_BOLD_SVG,
    "store_text": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M21 9a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 15 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2z"/><path d="M15 3v5a1 1 0 0 0 1 1h5"/></g></svg>',

    # Common Actions & Studio Editor Icons (Filled Solids + Bold Directional Lines)
    "search": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2"><path d="m21 21l-4.34-4.34"/><circle cx="11" cy="11" r="8"/></g></svg>',
    "copy": _COPY_FILL_SVG,
    "save": _SAVE_FILL_SVG,
    "upload": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></g></svg>',
    "trash": _TRASH_FILL_SVG,
    "pencil": _PENCIL_FILL_SVG,
    "check": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.6" d="M20 6L9 17l-5-5"/></svg>',
    "reset": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4"><path d="M3 12a9 9 0 1 0 9-9a9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></g></svg>',
    "rotate_ccw": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4"><path d="M3 12a9 9 0 1 0 9-9a9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></g></svg>',
    "retake": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4"><path d="M3 12a9 9 0 1 0 9-9a9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></g></svg>',
    "grid": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="{col}" fill-rule="evenodd" d="M4.25 2A2.25 2.25 0 0 0 2 4.25v2.5A2.25 2.25 0 0 0 4.25 9h2.5A2.25 2.25 0 0 0 9 6.75v-2.5A2.25 2.25 0 0 0 6.75 2zm0 9A2.25 2.25 0 0 0 2 13.25v2.5A2.25 2.25 0 0 0 4.25 18h2.5A2.25 2.25 0 0 0 9 15.75v-2.5A2.25 2.25 0 0 0 6.75 11zm9-9A2.25 2.25 0 0 0 11 4.25v2.5A2.25 2.25 0 0 0 13.25 9h2.5A2.25 2.25 0 0 0 18 6.75v-2.5A2.25 2.25 0 0 0 15.75 2zm0 9A2.25 2.25 0 0 0 11 13.25v2.5A2.25 2.25 0 0 0 13.25 18h2.5A2.25 2.25 0 0 0 18 15.75v-2.5A2.25 2.25 0 0 0 15.75 11z" clip-rule="evenodd"/></svg>',
    "layout_grid": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="{col}" fill-rule="evenodd" d="M4.25 2A2.25 2.25 0 0 0 2 4.25v2.5A2.25 2.25 0 0 0 4.25 9h2.5A2.25 2.25 0 0 0 9 6.75v-2.5A2.25 2.25 0 0 0 6.75 2zm0 9A2.25 2.25 0 0 0 2 13.25v2.5A2.25 2.25 0 0 0 4.25 18h2.5A2.25 2.25 0 0 0 9 15.75v-2.5A2.25 2.25 0 0 0 6.75 11zm9-9A2.25 2.25 0 0 0 11 4.25v2.5A2.25 2.25 0 0 0 13.25 9h2.5A2.25 2.25 0 0 0 18 6.75v-2.5A2.25 2.25 0 0 0 15.75 2zm0 9A2.25 2.25 0 0 0 11 13.25v2.5A2.25 2.25 0 0 0 13.25 18h2.5A2.25 2.25 0 0 0 18 15.75v-2.5A2.25 2.25 0 0 0 15.75 11z" clip-rule="evenodd"/></svg>',
    "oneline": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2"><path d="M2 3v18"/><rect width="12" height="18" x="6" y="3" rx="2"/><path d="M22 3v18"/></g></svg>',
    "gallery_horizontal": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2"><path d="M2 3v18"/><rect width="12" height="18" x="6" y="3" rx="2"/><path d="M22 3v18"/></g></svg>',
    "put_box": _BOX_FILL_SVG,
    "settings": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></g></svg>',
    "info": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4m0-4h.01"/></g></svg>',
    "external": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M7 7h10v10M7 17L17 7"/></svg>',
    "arrow_up_right": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M7 7h10v10M7 17L17 7"/></svg>',
    "sparkles": _SPARKLES_FILL_SVG,
    "share": _SHARE_FILL_SVG,
    "pen_line": _PEN_FILL_SVG,
    "highlighter": _HIGHLIGHTER_FILL_SVG,
    "eraser": _ERASER_FILL_SVG,
    "crop": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4"><path d="M6 2v14a2 2 0 0 0 2 2h14"/><path d="M18 22V8a2 2 0 0 0-2-2H2"/></g></svg>',
    "type": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16M4 7V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2M9 20h6"/></svg>',
    "shapes": _SHAPES_FILL_SVG,
    "move_up_right": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M13 5h6v6m0-6L5 19"/></svg>',
    "undo": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4"><path d="M9 14L4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11"/></g></svg>',
    "redo": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4"><path d="m15 14l5-5l-5-5"/><path d="M20 9H9.5A5.5 5.5 0 0 0 4 14.5A5.5 5.5 0 0 0 9.5 20H13"/></g></svg>',
    "square": _RECT_FILL_SVG,
    "circle": _CIRCLE_FILL_SVG,
    "package_plus": _BOX_FILL_SVG,
}


@lru_cache(maxsize=512)
def _render_cached_icon(svg_tpl: str, color_hex: str, size_px: int, dpr_key: float) -> QPixmap:
    svg = svg_tpl.replace("{col}", color_hex)
    px = max(1, int(round(size_px * dpr_key)))
    pix = QPixmap(px, px)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(p)
    p.end()
    pix.setDevicePixelRatio(dpr_key)
    return pix


def render_common_icon(key_or_svg: str, color_hex: str, size_px: int = 16, dpr: float | None = None) -> QPixmap:
    if dpr is None:
        dpr = native_dpr()
    dpr_key = round(max(1.0, float(dpr)), 2)
    svg_tpl = COMMON_ICONS.get(key_or_svg) or (key_or_svg if "<svg" in str(key_or_svg) else COMMON_ICONS["copy"])
    return _render_cached_icon(svg_tpl, str(color_hex), int(size_px), dpr_key)


# ─── Whisper-Thin Floating Pill Scrollbar Stylesheet (Zero Checkered Gutter) ─
SLIM_SCROLLBAR_QSS = (
    "QScrollArea { background: transparent; border: none; }"
    "QScrollArea > QWidget > QWidget { background: transparent; }"
    "QScrollBar:vertical { background: transparent; width: 6px; margin: 4px 1px 4px 0px; border: none; }"
    "QScrollBar::handle:vertical { background: rgba(255, 255, 255, 0.16); border-radius: 3px; min-height: 30px; }"
    "QScrollBar::handle:vertical:hover { background: rgba(163, 230, 53, 0.58); }"
    "QScrollBar::handle:vertical:pressed { background: rgba(163, 230, 53, 0.85); }"
    "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; width: 0px; background: none; border: none; }"
    "QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical { background: none; border: none; }"
    "QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; border: none; }"
    "QScrollBar:horizontal { background: transparent; height: 6px; margin: 0px 4px 1px 4px; border: none; }"
    "QScrollBar::handle:horizontal { background: rgba(255, 255, 255, 0.16); border-radius: 3px; min-width: 30px; }"
    "QScrollBar::handle:horizontal:hover { background: rgba(163, 230, 53, 0.58); }"
    "QScrollBar::handle:horizontal:pressed { background: rgba(163, 230, 53, 0.85); }"
    "QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0px; height: 0px; background: none; border: none; }"
    "QScrollBar::left-arrow:horizontal, QScrollBar::right-arrow:horizontal { background: none; border: none; }"
    "QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { background: transparent; border: none; }"
)


class CleanHeaderIconButton(QWidget):
    """
    Borderless fixed-size clickable slot (invisible box at rest) showing a crisp
    common vector icon at original proportion; reveals a whisper-soft wash on hover.
    """
    clicked = Signal()

    def __init__(self, icon_key: str, tip_text: str = "", box_size: int = 32, icon_size: int = 16, on_press_tick=None, parent=None):
        super().__init__(parent)
        self.icon_key = icon_key
        self.icon_size = icon_size
        self.on_press_tick = on_press_tick
        if tip_text:
            self.setToolTip(tip_text)
        self.setFixedSize(box_size, box_size)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        self._h = 0.0
        self._t = 0.0
        self._press = 0.0
        self._tm = QTimer(self)
        self._tm.setInterval(16)
        self._tm.timeout.connect(self._step)

    def _step(self):
        act = False
        if abs(self._t - self._h) >= 0.008:
            self._h += (self._t - self._h) * 0.25
            act = True
        else:
            self._h = self._t
        if self._press > 0.01:
            self._press *= 0.80
            act = True
        else:
            self._press = 0.0
        self.update()
        if not act:
            self._tm.stop()

    def enterEvent(self, e):
        self._t = 1.0
        if not self._tm.isActive():
            self._tm.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._t = 0.0
        if not self._tm.isActive():
            self._tm.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            if callable(self.on_press_tick):
                self.on_press_tick()
            self._press = 1.0
            if not self._tm.isActive():
                self._tm.start()
            self.clicked.emit()
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        hv = self._h
        sc = 1.0 - self._press * 0.07

        p.save()
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        # Invisible at rest (0 border, 0 box fill) -> soft circular obsidian glass halo on hover
        if hv > 0.02:
            hp = QPainterPath()
            hp.addEllipse(QRectF(1.0, 1.0, w - 2.0, h - 2.0))
            p.fillPath(hp, QColor(255, 255, 255, int(20 * hv)))
            p.setPen(QPen(QColor(255, 255, 255, int(24 * hv)), 0.8))
            p.drawPath(hp)

        if self.icon_key in ("back", "arrow_left") and hv > 0.01:
            p.translate(-1.5 * hv, 0.0)

        r_c = int(214 * (1.0 - hv) + 255 * hv)
        g_c = int(219 * (1.0 - hv) + 255 * hv)
        b_c = int(226 * (1.0 - hv) + 255 * hv)
        col = f"#{r_c:02x}{g_c:02x}{b_c:02x}"
        isz = self.icon_size
        pix = render_common_icon(self.icon_key, col, isz, dpr=native_dpr(self))
        p.drawPixmap(int(round((w - isz) * 0.5)), int(round((h - isz) * 0.5)), pix)
        p.restore()
        p.end()


class CleanBackButton(CleanHeaderIconButton):
    """Unified borderless iOS Back button shared across every SuperMouse window header."""

    def __init__(self, tip_text: str = "Back to Quick Menu", box_size: int = 30, icon_size: int = 15, on_press_tick=None, parent=None):
        super().__init__("back", tip_text=tip_text, box_size=box_size, icon_size=icon_size, on_press_tick=on_press_tick, parent=parent)


class CleanCloseButton(QPushButton):
    """
    Borderless common Cross ('X') button: full 30x30 hit target invisible at rest,
    reveals gentle circular hover wash + smooth 90deg rotation on hover.
    """

    def __init__(self, tip: str = "Close", box_size: int = 30, icon_size: int = 15, parent=None):
        super().__init__(parent)
        self.icon_size = icon_size
        self.setFixedSize(box_size, box_size)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(tip)
        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def _step(self):
        active = False
        if abs(self._target - self._h) >= 0.008:
            self._h += (self._target - self._h) * 0.25
            active = True
        else:
            self._h = self._target
        if self._press > 0.01:
            self._press *= 0.80
            active = True
        else:
            self._press = 0.0
        self.update()
        if not active:
            self._timer.stop()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        self._press = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().mousePressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        hv = self._h
        sc = 1.0 - self._press * 0.08

        p.save()
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        if hv > 0.02:
            ep = QPainterPath()
            ep.addEllipse(QRectF(1.0, 1.0, w - 2.0, h - 2.0))
            p.fillPath(ep, QColor(255, 255, 255, int(20 * hv)))

        r_c = int(194 * (1.0 - hv) + 255 * hv)
        g_c = int(198 * (1.0 - hv) + 255 * hv)
        b_c = int(206 * (1.0 - hv) + 255 * hv)
        isz = self.icon_size
        p.save()
        p.translate(w * 0.5, h * 0.5)
        p.rotate(hv * 90.0)
        cpix = render_common_icon("close", f"#{r_c:02x}{g_c:02x}{b_c:02x}", isz, dpr=native_dpr(self))
        p.drawPixmap(-isz // 2, -isz // 2, cpix)
        p.restore()
        p.restore()
        p.end()


# ─── Global App & Window Identity Icon Helper ────────────────────────────────
_CACHED_APP_ICON = None


def get_app_icon():
    global _CACHED_APP_ICON
    if _CACHED_APP_ICON is not None and not _CACHED_APP_ICON.isNull():
        return _CACHED_APP_ICON
    ico_path = os.path.join(ASSETS_DIR, 'supermouse_taskbar_icon.ico')
    png_path = os.path.join(ASSETS_DIR, 'supermouse_taskbar_icon.png')
    logo_trans = os.path.join(ASSETS_DIR, 'supermouse_app_logo_trans.png')
    logo_crop = os.path.join(ASSETS_DIR, 'supermouse_app_logo_cropped.png')
    icon = QIcon()
    for p in (ico_path, png_path, logo_trans, logo_crop):
        if os.path.exists(p):
            icon = QIcon(p)
            break
    _CACHED_APP_ICON = icon
    return icon


def get_app_logo_pixmap(target_height=20, dpr=1.0):
    for fn in ('supermouse_app_logo_cropped.png', 'supermouse_app_logo_trans.png', 'supermouse_app_logo.png'):
        fp = os.path.join(ASSETS_DIR, fn)
        if os.path.exists(fp):
            pm = QPixmap(fp)
            if not pm.isNull():
                qi = pm.toImage().scaledToHeight(max(14, int(round(target_height * dpr))), Qt.TransformationMode.SmoothTransformation)
                res = QPixmap.fromImage(qi)
                res.setDevicePixelRatio(dpr)
                return res
    return None


def apply_window_identity(widget, title='TheSuperMouse'):
    try:
        widget.setWindowTitle(title)
        widget.setWindowIcon(get_app_icon())
    except Exception:
        pass
