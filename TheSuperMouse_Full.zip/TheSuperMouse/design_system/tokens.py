"""
THE SUPERMOUSE DESIGN SYSTEM (v1.01)
Official Publishing & Deployment Tokens
Authoritative typography, explicit font weights, obsidian palette, and vector brand specs.
Ensures 1:1 identical visual rendering across Windows 10, Windows 11, and GitHub release bundles.
"""

from PySide6.QtGui import QFont, QColor

# ─── TYPOGRAPHY TOKENS ────────────────────────────────────────────────────────
FONT_FAMILIES_DISPLAY = [
    "Segoe UI Variable Display",
    "Segoe UI Variable Text",
    "Segoe UI",
    "Arial",
    "sans-serif"
]

FONT_FAMILIES_MONO = [
    "Cascadia Code",
    "Consolas",
    "Segoe UI Variable",
    "monospace"
]

# Explicit weights guaranteed across all Windows versions (prevents thin ClearType dropouts)
WEIGHT_BLACK = 900
WEIGHT_EXTRA_BOLD = 800  # Used for 'THE SUPERMOUSE' header & prominent titles
WEIGHT_BOLD = 700        # Used for row labels on hover / active
WEIGHT_SEMIBOLD = 600    # Used for idle row labels (demi-bold baseline, never thin!)
WEIGHT_MEDIUM = 500
WEIGHT_REGULAR = 400

def make_app_font(point_size: float = 9.6, weight: int = WEIGHT_SEMIBOLD, letter_spacing: float = 0.0) -> QFont:
    """Create a high-dpi vector font with explicit fallback stack and fixed weight."""
    f = QFont()
    f.setFamilies(FONT_FAMILIES_DISPLAY)
    f.setPointSizeF(point_size)
    f.setWeight(weight)
    f.setBold(weight >= WEIGHT_BOLD)
    if letter_spacing != 0.0:
        f.setLetterSpacing(QFont.AbsoluteSpacing, letter_spacing)
    f.setHintingPreference(QFont.PreferNoHinting)
    return f

# ─── OBSIDIAN COLOR TOKENS ───────────────────────────────────────────────────
COLOR_CANVAS_OLED = "#040405"
COLOR_CANVAS_CARD = "rgba(255, 255, 255, 0.04)"
COLOR_HAIRLINE_BORDER = "rgba(255, 255, 255, 0.08)"

COLOR_TEXT_HERO = "#FFFFFF"
COLOR_TEXT_PRIMARY = "#FFFFFF"
COLOR_TEXT_MUTED = "#EDEDEF"
COLOR_TEXT_SUBTLE = "#94A3B8"
COLOR_TEXT_CAPTION = "rgba(255, 255, 255, 0.34)"

COLOR_CYBER_LIME = "#A3E635"
COLOR_CYBER_LIME_RIM = "rgba(163, 230, 53, 0.55)"
COLOR_CYBER_LIME_TINT = "rgba(163, 230, 53, 0.12)"

LOGO_GRADIENT_START = "#FFFF00"
LOGO_GRADIENT_END = "#00FF85"

# ─── HEADER & WINDOW DIMENSIONS ──────────────────────────────────────────────
HEADER_HEIGHT = 44.0
LOGO_TEXT_SIZE = 11.4
EYEBROW_TEXT_SIZE = 8.0
MENU_ROW_HEIGHT = 36.0
DROPDOWN_HEADER_HEIGHT = 38.0
BASE_COLLAPSED_HEIGHT = 490.0
MAX_DROPDOWN_HEIGHT = 228.0
WINDOW_WIDTH = 288.0
