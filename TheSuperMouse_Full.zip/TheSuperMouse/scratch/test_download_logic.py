import subprocess

ps_test = r'''
$zipPath = "$env:TEMP\TheSuperMouse_Test.zip"
$downloadCandidates = @(
    "https://github.com/getsupermouse/supermouse-newmodes/releases/download/v1.01/TheSuperMouse_Full.zip",
    "https://github.com/getsupermouse/supermousenewnupdates/releases/download/v1.01/TheSuperMouse_Full.zip"
)

Write-Host "Testing Candidate 1..."
$targetUrl = $downloadCandidates[0]
$req = [System.Net.HttpWebRequest]::Create($targetUrl)
$req.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) TheSuperMouseInstaller"
$req.Timeout = 15000
$req.AllowAutoRedirect = $true
$resp = $req.GetResponse()
$totalBytes = $resp.ContentLength
$resp.Close()
Write-Host "Candidate 1 responded! ContentLength: $totalBytes bytes"
'''

p = subprocess.run(['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps_test], capture_output=True, text=True)
print("STDOUT:\n", p.stdout)
print("STDERR:\n", p.stderr)
