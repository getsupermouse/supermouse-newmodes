import os
import subprocess
import urllib.request
import json
import time

print("=== Starting GitHub Release Launch for v1.01 ===")

# 1. Retrieve Git token
p = subprocess.Popen(['git', 'credential', 'fill'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
out, _ = p.communicate(input='protocol=https\nhost=github.com\n\n')
token = None
for l in out.splitlines():
    if l.startswith('password='):
        token = l.split('=', 1)[1]

if not token:
    raise RuntimeError("Could not retrieve GitHub token from Windows Credential Manager!")

headers = {
    'Authorization': f'token {token}',
    'Accept': 'application/vnd.github.v3+json',
    'User-Agent': 'TheSuperMouseReleaseEngine'
}

repo = "getsupermouse/supermousenewnupdates"

# 2. Check and delete old releases (e.g. v1.0)
print(f"Checking existing releases on {repo}...")
req = urllib.request.Request(f'https://api.github.com/repos/{repo}/releases', headers=headers)
with urllib.request.urlopen(req) as resp:
    releases = json.load(resp)

for rel in releases:
    rel_id = rel['id']
    tag = rel.get('tag_name')
    if tag == 'v1.0' or tag == 'v1.01':
        print(f"Deleting old release {tag} (ID {rel_id})...")
        del_req = urllib.request.Request(f'https://api.github.com/repos/{repo}/releases/{rel_id}', headers=headers, method='DELETE')
        try:
            with urllib.request.urlopen(del_req) as del_resp:
                print(f"Deleted release {tag} successfully.")
        except Exception as e:
            print(f"Error deleting release {tag}: {e}")

time.sleep(1)

# Also delete git tag v1.01 if it already existed remotely so fresh tag is made
del_tag_req = urllib.request.Request(f'https://api.github.com/repos/{repo}/git/refs/tags/v1.01', headers=headers, method='DELETE')
try:
    with urllib.request.urlopen(del_tag_req) as resp:
        print("Deleted existing remote tag v1.01 if any.")
except Exception:
    pass

# 3. Create fresh Release v1.01
print("Creating fresh release v1.01...")
create_data = {
    "tag_name": "v1.01",
    "target_commitish": "main",
    "name": "THE SUPERMOUSE v1.01 Official Release",
    "body": "THE SUPERMOUSE Version 1.01 (Production Release)\n\n"
            "- New & polished Access and Settings hotkey & navigation buttons\n"
            "- Real-time Windows cursor scaling stepper (-10 to +10, default 0)\n"
            "- Official Avatar suite and cleaned personal snapshots\n"
            "- High-speed delta updater engine with SHA-256 verification\n"
            "- Standalone distribution package for new users\n",
    "draft": False,
    "prerelease": False,
    "make_latest": "true"
}

req_create = urllib.request.Request(
    f'https://api.github.com/repos/{repo}/releases',
    data=json.dumps(create_data).encode('utf-8'),
    headers={**headers, 'Content-Type': 'application/json'},
    method='POST'
)

with urllib.request.urlopen(req_create) as resp:
    new_release = json.load(resp)

new_release_id = new_release['id']
upload_url_template = new_release['upload_url'] # e.g. https://uploads.github.com/.../assets{?name,label}
upload_base = upload_url_template.split('{')[0]
print(f"Release v1.01 created with ID: {new_release_id}")

# 4. Upload Assets
assets_to_upload = [
    (r"D:\THESUPERMOUSE\supermousenewnupdates\updates\patch_v1.01.zip", "patch_v1.01.zip", "application/zip"),
    (r"D:\THESUPERMOUSE\supermousenewnupdates\updates\TheSuperMouse_Full.zip", "TheSuperMouse_Full.zip", "application/zip")
]

for file_path, asset_name, content_type in assets_to_upload:
    file_size = os.path.getsize(file_path)
    file_mb = round(file_size / (1024 * 1024), 2)
    print(f"Uploading {asset_name} ({file_mb} MB) to Release v1.01...")
    
    upload_url = f"{upload_base}?name={asset_name}"
    with open(file_path, 'rb') as f_data:
        body_bytes = f_data.read()

    req_upload = urllib.request.Request(
        upload_url,
        data=body_bytes,
        headers={
            'Authorization': f'token {token}',
            'Content-Type': content_type,
            'Content-Length': str(file_size),
            'User-Agent': 'TheSuperMouseReleaseEngine'
        },
        method='POST'
    )

    with urllib.request.urlopen(req_upload) as up_resp:
        up_data = json.load(up_resp)
        print(f"Uploaded {asset_name} successfully! Download URL: {up_data.get('browser_download_url')}")

print("All release assets uploaded successfully to GitHub Release v1.01!")
