import os
import shutil
import hashlib
import json
import subprocess
import urllib.request

print("=== 1. Creating 'new and updates' Backup Folder ===")
backup_root = r"D:\THESUPERMOUSE\new and updates"
backup_new = os.path.join(backup_root, "new")
backup_updates = os.path.join(backup_root, "updates")

os.makedirs(backup_new, exist_ok=True)
os.makedirs(backup_updates, exist_ok=True)

src_full_zip = r"D:\THESUPERMOUSE\supermousenewnupdates\updates\TheSuperMouse_Full.zip"
src_patch_zip = r"D:\THESUPERMOUSE\supermousenewnupdates\updates\patch_v1.01.zip"
src_vjson = r"D:\THESUPERMOUSE\supermousenewnupdates\updates\version.json"
src_bundle_dir = r"D:\THESUPERMOUSE\PC REALEASE BUNDLE\TheSuperMouse"

# Compute hashes
def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest().lower()

full_sha = file_sha256(src_full_zip)
patch_sha = file_sha256(src_patch_zip)

print(f"Full ZIP SHA256:  {full_sha}")
print(f"Patch ZIP SHA256: {patch_sha}")

# Write matching .sha256 files in supermousenewnupdates/updates
with open(r"D:\THESUPERMOUSE\supermousenewnupdates\updates\TheSuperMouse_Full.sha256", "w") as f:
    f.write(f"{full_sha}  TheSuperMouse_Full.zip\n")

with open(r"D:\THESUPERMOUSE\supermousenewnupdates\updates\patch_v1.01.sha256", "w") as f:
    f.write(f"{patch_sha}  patch_v1.01.zip\n")

# Copy to backup 'new' folder
print("Copying full bundle to 'new and updates/new'...")
shutil.copy2(src_full_zip, os.path.join(backup_new, "TheSuperMouse_Full.zip"))
with open(os.path.join(backup_new, "TheSuperMouse_Full.sha256"), "w") as f:
    f.write(f"{full_sha}  TheSuperMouse_Full.zip\n")

# Copy the full standalone directory as well for immediate ready-to-run backup
backup_bundle_folder = os.path.join(backup_new, "TheSuperMouse")
if os.path.exists(backup_bundle_folder):
    shutil.rmtree(backup_bundle_folder)
shutil.copytree(src_bundle_dir, backup_bundle_folder)
print("Saved full standalone directory and zip in 'new'!")

# Copy to backup 'updates' folder
print("Copying update files to 'new and updates/updates'...")
shutil.copy2(src_patch_zip, os.path.join(backup_updates, "patch_v1.01.zip"))
with open(os.path.join(backup_updates, "patch_v1.01.sha256"), "w") as f:
    f.write(f"{patch_sha}  patch_v1.01.zip\n")
shutil.copy2(src_vjson, os.path.join(backup_updates, "version.json"))
print("Saved patch zip, sha256, and version.json in 'updates'!")

print("=== Backup folder setup completed successfully! ===")
