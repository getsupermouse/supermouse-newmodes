import os
import subprocess
import time

# Kill existing running main_app.py
print("Killing old python/pythonw main_app processes...")
subprocess.run(
    'powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { ($_.Name -eq \'pythonw.exe\' -or $_.Name -eq \'python.exe\') -and $_.CommandLine -like \'*main_app.py*\' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"',
    shell=True
)

time.sleep(1)

# Launch fresh main_app.py
print("Launching fresh main_app.py --supershare...")
app_dir = r"D:\THESUPERMOUSE\VERSION 1.0"
subprocess.Popen(["pythonw.exe", "main_app.py", "--supershare"], cwd=app_dir, creationflags=subprocess.DETACHED_PROCESS)

time.sleep(1)

# Check running process
p = subprocess.run(
    'powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { ($_.Name -eq \'pythonw.exe\' -or $_.Name -eq \'python.exe\') -and $_.CommandLine -like \'*main_app.py*\' } | Select-Object ProcessId, CommandLine"',
    shell=True,
    capture_output=True,
    text=True
)
print("Running processes:\n", p.stdout.strip())
