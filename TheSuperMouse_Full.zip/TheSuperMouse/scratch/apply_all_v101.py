import os
import re
import json
import zipfile
import hashlib
import subprocess

print("=== Starting Global v1.0 -> v1.01 Update ===")

# 1. Update features/patch_checker/patch_engine.py
patch_engine_path = r'D:\THESUPERMOUSE\VERSION 1.0\features\patch_checker\patch_engine.py'
with open(patch_engine_path, 'r', encoding='utf-8') as f:
    pe_code = f.read()

# Replace legacy suppression
old_pe = '''        # Unified v1.0 already incorporates all previous v1.1-v1.5 changes
        if _parse_version(remote_v) <= _parse_version("1.5"):
            remote_v = "1.0"
            if isinstance(remote, dict):
                remote["updates"] = []
                remote["version"] = "1.0"'''

new_pe = '''        # Unified v1.01 baseline (legacy test versions cleanup)
        if _parse_version(remote_v) < _parse_version("1.0"):
            remote_v = "1.01"
            if isinstance(remote, dict):
                remote["updates"] = []
                remote["version"] = "1.01"'''

if old_pe in pe_code:
    pe_code = pe_code.replace(old_pe, new_pe)
    with open(patch_engine_path, 'w', encoding='utf-8') as f:
        f.write(pe_code)
    print("Updated patch_engine.py legacy suppression")

# 2. Update thesupermouse/studio_website/index.html
studio_html = r'D:\THESUPERMOUSE\VERSION 1.0\thesupermouse\studio_website\index.html'
if os.path.exists(studio_html):
    with open(studio_html, 'r', encoding='utf-8') as f:
        sh_content = f.read()
    sh_content = sh_content.replace('v1.0', 'v1.01').replace('Version 1.0', 'Version 1.01')
    with open(studio_html, 'w', encoding='utf-8') as f:
        f.write(sh_content)
    print("Updated thesupermouse/studio_website/index.html")

# 3. Update design_system/tokens.py
tokens_py = r'D:\THESUPERMOUSE\VERSION 1.0\design_system\tokens.py'
if os.path.exists(tokens_py):
    with open(tokens_py, 'r', encoding='utf-8') as f:
        tok_content = f.read()
    tok_content = tok_content.replace('v1.0', 'v1.01').replace('Version 1.0', 'Version 1.01')
    with open(tokens_py, 'w', encoding='utf-8') as f:
        f.write(tok_content)
    print("Updated design_system/tokens.py")

# 4. Update features/super_share/device_hub.py docstring
hub_py = r'D:\THESUPERMOUSE\VERSION 1.0\features\super_share\device_hub.py'
if os.path.exists(hub_py):
    with open(hub_py, 'r', encoding='utf-8') as f:
        hub_content = f.read()
    hub_content = hub_content.replace('UPERMOUSE v1.0.', 'UPERMOUSE v1.01.')
    with open(hub_py, 'w', encoding='utf-8') as f:
        f.write(hub_content)
    print("Updated device_hub.py docstring")

# 5. Update tools/build_full.py
build_full = r'D:\THESUPERMOUSE\VERSION 1.0\tools\build_full.py'
if os.path.exists(build_full):
    with open(build_full, 'r', encoding='utf-8') as f:
        bf_content = f.read()
    bf_content = bf_content.replace('version_str: str = "1.0"', 'version_str: str = "1.01"')
    bf_content = bf_content.replace('default="1.0"', 'default="1.01"')
    with open(build_full, 'w', encoding='utf-8') as f:
        f.write(bf_content)
    print("Updated tools/build_full.py")

# 6. Update TheWebsite/index.html
web_html = r'D:\THESUPERMOUSE\TheWebsite\index.html'
if os.path.exists(web_html):
    with open(web_html, 'r', encoding='utf-8') as f:
        w_content = f.read()
    # Careful targeted replacements
    w_content = w_content.replace('Version         : v1.0.0 (Official Windows Production Release)', 'Version         : v1.01 (Official Windows Production Release)')
    w_content = w_content.replace('TheSuperMouse-Setup-v1.0.exe', 'TheSuperMouse-Setup-v1.01.exe')
    w_content = w_content.replace('<span>v1.0</span>', '<span>v1.01</span>')
    w_content = w_content.replace('v1.0 • 64-Bit', 'v1.01 • 64-Bit')
    w_content = w_content.replace('SuperSpace-Android-Companion-v1.0.apk', 'SuperSpace-Android-Companion-v1.01.apk')
    w_content = w_content.replace('<!-- 7. Info v1.0 -->', '<!-- 7. Info v1.01 -->')
    w_content = w_content.replace('THE SUPERMOUSE v1.0', 'THE SUPERMOUSE v1.01')
    w_content = w_content.replace('Included in THE SUPERMOUSE v1.0', 'Included in THE SUPERMOUSE v1.01')
    w_content = w_content.replace('Install v1.0 Now →', 'Install v1.01 Now →')
    w_content = w_content.replace('Included in v1.0 →', 'Included in v1.01 →')
    w_content = w_content.replace('Current Official Build • v1.0', 'Current Official Build • v1.01')
    w_content = w_content.replace('What’s New in THE SUPERMOUSE v1.0', 'What’s New in THE SUPERMOUSE v1.01')
    w_content = w_content.replace('Version 1.0 unifies', 'Version 1.01 unifies')
    w_content = w_content.replace('Get Latest v1.0 Build →', 'Get Latest v1.01 Build →')
    w_content = w_content.replace('© 2026 THE SUPERMOUSE v1.0', '© 2026 THE SUPERMOUSE v1.01')
    w_content = w_content.replace('OFFICIAL BUILD • v1.0', 'OFFICIAL BUILD • v1.01')
    w_content = w_content.replace('THE SUPERMOUSE v1.0 Info', 'THE SUPERMOUSE v1.01 Info')
    w_content = w_content.replace('release v1.0 by SuperMouse Studio', 'release v1.01 by SuperMouse Studio')
    with open(web_html, 'w', encoding='utf-8') as f:
        f.write(w_content)
    print("Updated TheWebsite/index.html")

# 7. Update TheWebsite/updates/version.json and thesupermouse-releases/updates/version.json
super_vjson = r'D:\THESUPERMOUSE\supermousenewnupdates\updates\version.json'
with open(super_vjson, 'r', encoding='utf-8') as f:
    vdata = json.load(f)

for target_v in [
    r'D:\THESUPERMOUSE\TheWebsite\updates\version.json',
    r'D:\THESUPERMOUSE\thesupermouse-releases\updates\version.json',
    r'D:\THESUPERMOUSE\dist_release\TheSuperMouse\version.json'
]:
    if os.path.exists(os.path.dirname(target_v)):
        with open(target_v, 'w', encoding='utf-8') as f:
            json.dump(vdata, f, indent=2)
        print(f"Updated {target_v}")

# 8. Deploy TheWebsite to Cloudflare Pages if wrangler is available
try:
    p = subprocess.run('npx wrangler pages deploy . --project-name getsupermouse', shell=True, cwd=r'D:\THESUPERMOUSE\TheWebsite', capture_output=True, text=True, timeout=30)
    print("Cloudflare deploy output:", p.stdout.split('\n')[-3:])
except Exception as e:
    print("Wrangler deploy note:", e)

# 9. Sync PC RELEASE BUNDLE files from VERSION 1.0
print("Syncing updated files to PC RELEASE BUNDLE...")
bundle_src = r'D:\THESUPERMOUSE\VERSION 1.0'
bundle_dst = r'D:\THESUPERMOUSE\PC REALEASE BUNDLE\TheSuperMouse'

sync_files = [
    'features/quick_menu.py',
    'features/runner.py',
    'features/patch_checker/patch_engine.py',
    'features/super_share/common.py',
    'features/super_share/device_hub.py',
    'features/super_share/menu_window.py',
    'features/super_share/settings.py',
    'features/super_snap_and_pin/window.py',
    'core/global_triggers.py',
    'main_app.py',
    'super_clipboard.py',
    'version.json',
    'thesupermouse/config/access_settings.json',
    'thesupermouse/browser_selection_theme/manifest.json',
    'thesupermouse/studio_website/index.html',
    'design_system/tokens.py',
    'tools/build_full.py'
]

for rel in sync_files:
    sp = os.path.join(bundle_src, rel)
    dp = os.path.join(bundle_dst, rel)
    if os.path.exists(sp):
        os.makedirs(os.path.dirname(dp), exist_ok=True)
        with open(sp, 'rb') as f_in, open(dp, 'wb') as f_out:
            f_out.write(f_in.read())

print("Sync to PC RELEASE BUNDLE complete.")

# 10. Re-build patch_v1.01.zip
patch_zip_path = r'D:\THESUPERMOUSE\supermousenewnupdates\updates\patch_v1.01.zip'
os.makedirs(os.path.dirname(patch_zip_path), exist_ok=True)
with zipfile.ZipFile(patch_zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for rel in sync_files:
        fp = os.path.join(bundle_src, rel)
        if os.path.exists(fp):
            zf.write(fp, rel)

# Compute patch SHA-256
h = hashlib.sha256()
with open(patch_zip_path, 'rb') as f:
    for chunk in iter(lambda: f.read(65536), b""):
        h.update(chunk)
patch_sha = h.hexdigest().lower()
patch_size_mb = round(os.path.getsize(patch_zip_path) / (1024 * 1024), 2)
print(f"New patch_v1.01.zip SHA-256: {patch_sha}, Size: {patch_size_mb} MB")

# Update version.json with new patch hash
vdata["patch_sha256"] = patch_sha
vdata["patch_size_mb"] = f"{patch_size_mb:.2f} MB"
vdata["size_mb"] = f"{patch_size_mb:.2f} MB"
vdata["total_size_mb"] = patch_size_mb
vdata["updates"][0]["size_mb"] = patch_size_mb

with open(super_vjson, 'w', encoding='utf-8') as f:
    json.dump(vdata, f, indent=2)

for target_v in [
    r'D:\THESUPERMOUSE\TheWebsite\updates\version.json',
    r'D:\THESUPERMOUSE\thesupermouse-releases\updates\version.json'
]:
    if os.path.exists(os.path.dirname(target_v)):
        with open(target_v, 'w', encoding='utf-8') as f:
            json.dump(vdata, f, indent=2)

print("Updated version.json everywhere with latest patch sha.")

# Rebuild TheSuperMouse_Full.zip
full_zip_path = r'D:\THESUPERMOUSE\supermousenewnupdates\updates\TheSuperMouse_Full.zip'
print("Rebuilding TheSuperMouse_Full.zip...")
clean_rules_file = r'D:\THESUPERMOUSE\PC REALEASE BUNDLE\.bundle_clean_rules'
clean_rules = []
if os.path.exists(clean_rules_file):
    with open(clean_rules_file, 'r', encoding='utf-8') as f:
        clean_rules = [l.strip().lower() for l in f if l.strip() and not l.startswith('#')]

with zipfile.ZipFile(full_zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(bundle_dst):
        for file in files:
            full_p = os.path.join(root, file)
            rel_p = os.path.relpath(full_p, os.path.dirname(bundle_dst))
            rel_norm = rel_p.replace('\\', '/').lower()
            if any(rule in rel_norm for rule in clean_rules):
                continue
            zf.write(full_p, rel_p)

h_full = hashlib.sha256()
with open(full_zip_path, 'rb') as f:
    for chunk in iter(lambda: f.read(65536), b""):
        h_full.update(chunk)
full_sha = h_full.hexdigest().lower()
full_size_mb = round(os.path.getsize(full_zip_path) / (1024 * 1024), 2)
print(f"New TheSuperMouse_Full.zip SHA-256: {full_sha}, Size: {full_size_mb} MB")

# Final update of full sha
vdata["full_sha256"] = full_sha
vdata["full_size_mb"] = f"{full_size_mb:.2f} MB"
with open(super_vjson, 'w', encoding='utf-8') as f:
    json.dump(vdata, f, indent=2)

for target_v in [
    r'D:\THESUPERMOUSE\TheWebsite\updates\version.json',
    r'D:\THESUPERMOUSE\thesupermouse-releases\updates\version.json'
]:
    if os.path.exists(os.path.dirname(target_v)):
        with open(target_v, 'w', encoding='utf-8') as f:
            json.dump(vdata, f, indent=2)

print("=== All updates completed successfully! ===")
