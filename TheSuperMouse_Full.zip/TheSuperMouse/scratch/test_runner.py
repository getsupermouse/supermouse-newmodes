import subprocess

test_cmd = [
    'powershell',
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-File', r'D:\THESUPERMOUSE\VERSION 1.0\scratch\clean_install.ps1'
]

# We pass an empty input or simulated key to see if it parses and runs
p = subprocess.Popen(test_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
stdout, stderr = p.communicate(input="\n")
print("RETURN CODE:", p.returncode)
print("STDOUT:\n", stdout)
print("STDERR:\n", stderr)
