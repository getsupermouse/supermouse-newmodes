import os
import subprocess
import urllib.request
import json

print("=== Pushing TheWebsite to getsupermouse.github.io and SuperMouseHQ to getsupermouse-status ===")

# 1. Retrieve Git token
p = subprocess.Popen(['git', 'credential', 'fill'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
out, _ = p.communicate(input='protocol=https\nhost=github.com\n\n')
token = None
for l in out.splitlines():
    if l.startswith('password='):
        token = l.split('=', 1)[1]

headers = {
    'Authorization': f'token {token}',
    'Accept': 'application/vnd.github.v3+json',
    'User-Agent': 'TheSuperMouseReleaseEngine'
}

# 2. Push TheWebsite to getsupermouse.github.io
dir_web = r"D:\THESUPERMOUSE\TheWebsite"
subprocess.run(['git', 'init'], cwd=dir_web)
subprocess.run(['git', 'remote', 'remove', 'origin'], cwd=dir_web, capture_output=True)
subprocess.run(['git', 'remote', 'add', 'origin', 'https://github.com/getsupermouse/getsupermouse.github.io.git'], cwd=dir_web)
subprocess.run(['git', 'checkout', '-B', 'main'], cwd=dir_web)
subprocess.run(['git', 'add', '-A'], cwd=dir_web)
subprocess.run(['git', 'commit', '-m', 'Update website with verified how-to-install instructions and terminal selectors'], cwd=dir_web)
p_push = subprocess.run(['git', 'push', '-u', 'origin', 'main', '--force'], cwd=dir_web, capture_output=True, text=True)
print("Pushed TheWebsite to getsupermouse.github.io:\n", p_push.stdout, p_push.stderr)

# 3. Create repo getsupermouse-status if not exists
data = json.dumps({'name': 'getsupermouse-status', 'description': 'THE SUPERMOUSE Executive Desk & Status Page', 'private': False, 'auto_init': False}).encode('utf-8')
req = urllib.request.Request('https://api.github.com/user/repos', data=data, headers={**headers, 'Content-Type': 'application/json'}, method='POST')
try:
    with urllib.request.urlopen(req) as r:
        print("Created getsupermouse-status repo:", json.load(r).get('html_url'))
except urllib.error.HTTPError as e:
    print("getsupermouse-status note:", e.code)

# 4. Push SuperMouseHQ to getsupermouse-status
dir_hq = r"D:\THESUPERMOUSE\SuperMouseHQ"
subprocess.run(['git', 'init'], cwd=dir_hq)
subprocess.run(['git', 'remote', 'remove', 'origin'], cwd=dir_hq, capture_output=True)
subprocess.run(['git', 'remote', 'add', 'origin', 'https://github.com/getsupermouse/getsupermouse-status.git'], cwd=dir_hq)
subprocess.run(['git', 'checkout', '-B', 'main'], cwd=dir_hq)
subprocess.run(['git', 'add', '-A'], cwd=dir_hq)
subprocess.run(['git', 'commit', '-m', 'Update Executive Desk with Fleet Broadcast Notifications suite'], cwd=dir_hq)
p_push_hq = subprocess.run(['git', 'push', '-u', 'origin', 'main', '--force'], cwd=dir_hq, capture_output=True, text=True)
print("Pushed SuperMouseHQ to getsupermouse-status:\n", p_push_hq.stdout, p_push_hq.stderr)

print("=== Both website and status page pushed successfully! ===")
