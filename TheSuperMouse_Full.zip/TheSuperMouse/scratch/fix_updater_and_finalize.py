import os
import re
import json
import zipfile
import hashlib
import subprocess

print("=== Fixing patch_engine.py and remaining v1.0 references ===")

# 1. Fix patch_engine.py
pe_path = r'D:\THESUPERMOUSE\VERSION 1.0\features\patch_checker\patch_engine.py'
with open(pe_path, 'r', encoding='utf-8') as f:
    code = f.read()

# Replace lines 190-208 cleanly
old_block = '''        # Unified v1.01 baseline (legacy test versions cleanup)
        if _parse_version(remote_v) < _parse_version("1.0"):
            remote_v = "1.01"
            if isinstance(remote, dict):
                remote["updates"] = []
                remote["version"] = "1.01"

        is_newer = _parse_version(remote_v) > _parse_version(local_v)
        raw_list = remote.get("updates")
        pending_items = []

        if isinstance(raw_list, list) and raw_list:
            for item in raw_list:
                if not isinstance(item, dict):
                    continue
                iv = str(item.get("version") or remote_v)
                if _parse_version(iv) <= _parse_version("1.5"):
                    continue'''

new_block = '''        # Unified v1.01 baseline
        is_newer = _parse_version(remote_v) > _parse_version(local_v)
        raw_list = remote.get("updates")
        pending_items = []

        if isinstance(raw_list, list) and raw_list:
            for item in raw_list:
                if not isinstance(item, dict):
                    continue
                iv = str(item.get("version") or remote_v)
                if _parse_version(iv) <= _parse_version(local_v):
                    continue'''

if old_block in code:
    code = code.replace(old_block, new_block)
    with open(pe_path, 'w', encoding='utf-8') as f:
        f.write(code)
    print("Fixed patch_engine.py update filtering bug!")
else:
    print("Warning: old_block not matched exactly in patch_engine.py, doing regex replacement...")
    code = re.sub(
        r'if _parse_version\(iv\) <= _parse_version\("1\.5"\):\s+continue',
        r'if _parse_version(iv) <= _parse_version(local_v):\n                    continue',
        code
    )
    with open(pe_path, 'w', encoding='utf-8') as f:
        f.write(code)

# 2. Fix tools/build_full.py
bf_path = r'D:\THESUPERMOUSE\VERSION 1.0\tools\build_full.py'
if os.path.exists(bf_path):
    with open(bf_path, 'r', encoding='utf-8') as f:
        bf_code = f.read()
    bf_code = bf_code.replace('version_str: str = "1.0"', 'version_str: str = "1.01"').replace('default="1.0"', 'default="1.01"')
    with open(bf_path, 'w', encoding='utf-8') as f:
        f.write(bf_code)
    print("Fixed tools/build_full.py")

# 3. Fix TheWebsite/index.html remaining v1.0 strings
w_path = r'D:\THESUPERMOUSE\TheWebsite\index.html'
if os.path.exists(w_path):
    with open(w_path, 'r', encoding='utf-8') as f:
        w_code = f.read()
    w_code = w_code.replace('tabs (v1.0, Beta 0.9', 'tabs (v1.01, Beta 0.9')
    w_code = w_code.replace('Milestone 0: v1.0 Official', 'Milestone 0: v1.01 Official')
    w_code = w_code.replace('Upgraded to v1.0', 'Upgraded to v1.01')
    w_code = w_code.replace('Auto-Deleted When v1.0 Installed', 'Auto-Deleted When v1.01 Installed')
    w_code = w_code.replace('Will Auto-Replace v1.0 Seamlessly', 'Will Auto-Replace v1.01 Seamlessly')
    w_code = w_code.replace('inside your v1.0 menu', 'inside your v1.01 menu')
    w_code = w_code.replace('inside the v1.0 command menu', 'inside the v1.01 command menu')
    with open(w_path, 'w', encoding='utf-8') as f:
        f.write(w_code)
    print("Fixed TheWebsite/index.html remaining strings")

# 4. Sync to PC RELEASE BUNDLE
bundle_src = r'D:\THESUPERMOUSE\VERSION 1.0'
bundle_dst = r'D:\THESUPERMOUSE\PC REALEASE BUNDLE\TheSuperMouse'
for rel in ['features/patch_checker/patch_engine.py', 'tools/build_full.py']:
    sp = os.path.join(bundle_src, rel)
    dp = os.path.join(bundle_dst, rel)
    with open(sp, 'rb') as f_in, open(dp, 'wb') as f_out:
        f_out.write(f_in.read())

# 5. Re-generate patch_v1.01.zip
patch_zip = r'D:\THESUPERMOUSE\supermousenewnupdates\updates\patch_v1.01.zip'
sync_files = [
    'features/quick_menu.py',
    'features/runner.py',
    'features/patch_checker/patch_engine.py',
    'features/super_share/common.py',
    'features/super_share/device_hub.py',
    'features/super_share/menu_window.py',
    'features/super_share/settings.py',
    'features/super_snap_and_pin/window.py',
    'core/global_triggers.py',
    'main_app.py',
    'super_clipboard.py',
    'version.json',
    'thesupermouse/config/access_settings.json',
    'thesupermouse/browser_selection_theme/manifest.json',
    'thesupermouse/studio_website/index.html',
    'design_system/tokens.py',
    'tools/build_full.py'
]

with zipfile.ZipFile(patch_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
    for rel in sync_files:
        fp = os.path.join(bundle_src, rel)
        if os.path.exists(fp):
            zf.write(fp, rel)

h = hashlib.sha256()
with open(patch_zip, 'rb') as f:
    for chunk in iter(lambda: f.read(65536), b""):
        h.update(chunk)
p_sha = h.hexdigest().lower()
p_size = round(os.path.getsize(patch_zip) / (1024 * 1024), 2)
print(f"Updated patch_v1.01.zip: SHA={p_sha}, Size={p_size} MB")

# 6. Re-generate TheSuperMouse_Full.zip
full_zip = r'D:\THESUPERMOUSE\supermousenewnupdates\updates\TheSuperMouse_Full.zip'
clean_rules_file = r'D:\THESUPERMOUSE\PC REALEASE BUNDLE\.bundle_clean_rules'
clean_rules = []
if os.path.exists(clean_rules_file):
    with open(clean_rules_file, 'r', encoding='utf-8') as f:
        clean_rules = [l.strip().lower() for l in f if l.strip() and not l.startswith('#')]

with zipfile.ZipFile(full_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(bundle_dst):
        for file in files:
            full_p = os.path.join(root, file)
            rel_p = os.path.relpath(full_p, os.path.dirname(bundle_dst))
            rel_norm = rel_p.replace('\\', '/').lower()
            if any(rule in rel_norm for rule in clean_rules):
                continue
            zf.write(full_p, rel_p)

h_f = hashlib.sha256()
with open(full_zip, 'rb') as f:
    for chunk in iter(lambda: f.read(65536), b""):
        h_f.update(chunk)
f_sha = h_f.hexdigest().lower()
f_size = round(os.path.getsize(full_zip) / (1024 * 1024), 2)
print(f"Updated TheSuperMouse_Full.zip: SHA={f_sha}, Size={f_size} MB")

# 7. Update version.json manifests
v_manifest = r'D:\THESUPERMOUSE\supermousenewnupdates\updates\version.json'
with open(v_manifest, 'r', encoding='utf-8') as f:
    vdata = json.load(f)

vdata["version"] = "1.01"
vdata["name"] = "THE SUPERMOUSE 1.01"
vdata["headline"] = "THE SUPERMOUSE 1.01 (LATEST)"
vdata["patch_sha256"] = p_sha
vdata["patch_size_mb"] = f"{p_size:.2f} MB"
vdata["size_mb"] = f"{p_size:.2f} MB"
vdata["total_size_mb"] = p_size
vdata["full_sha256"] = f_sha
vdata["full_size_mb"] = f"{f_size:.2f} MB"
vdata["updates"][0]["size_mb"] = p_size

with open(v_manifest, 'w', encoding='utf-8') as f:
    json.dump(vdata, f, indent=2)

for target_v in [
    r'D:\THESUPERMOUSE\TheWebsite\updates\version.json',
    r'D:\THESUPERMOUSE\thesupermouse-releases\updates\version.json'
]:
    with open(target_v, 'w', encoding='utf-8') as f:
        json.dump(vdata, f, indent=2)

# Deploy TheWebsite
try:
    p = subprocess.run('npx wrangler pages deploy . --project-name getsupermouse', shell=True, cwd=r'D:\THESUPERMOUSE\TheWebsite', capture_output=True, text=True, timeout=30)
    print("Wrangler deployed.")
except Exception as e:
    pass

print("=== Done! ===")
