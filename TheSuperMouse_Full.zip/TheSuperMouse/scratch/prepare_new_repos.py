import os
import shutil
import hashlib
import json
import subprocess
import urllib.request
import time

print("=================================================================")
print("  THE SUPERMOUSE — Splitting into 'supermouse-newmodes' and 'supermouse-updates'")
print("=================================================================")

# 1. Retrieve Git token
p = subprocess.Popen(['git', 'credential', 'fill'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
out, _ = p.communicate(input='protocol=https\nhost=github.com\n\n')
token = None
for l in out.splitlines():
    if l.startswith('password='):
        token = l.split('=', 1)[1]

if not token:
    raise RuntimeError("GitHub token not found in Windows Credential Manager!")

headers = {
    'Authorization': f'token {token}',
    'Accept': 'application/vnd.github.v3+json',
    'User-Agent': 'TheSuperMouseReleaseEngine'
}

# 2. Local directories
dir_newmodes = r"D:\THESUPERMOUSE\supermouse-newmodes"
dir_updates = r"D:\THESUPERMOUSE\supermouse-updates"

os.makedirs(dir_newmodes, exist_ok=True)
os.makedirs(dir_updates, exist_ok=True)
os.makedirs(os.path.join(dir_updates, "updates"), exist_ok=True)

# 3. Update VERSION 1.0 client code with new repos
print("Updating VERSION 1.0 client code...")

# 3a. version.json
with open(r"D:\THESUPERMOUSE\VERSION 1.0\version.json", "w", encoding="utf-8") as f:
    json.dump({
        "version": "1.01",
        "name": "THE SUPERMOUSE 1.01",
        "date": "21 Nov 2026"
    }, f, indent=2)

# 3b. patch_engine.py: update DEFAULT_MANIFEST_URL and auto-migration
pe_path = r"D:\THESUPERMOUSE\VERSION 1.0\features\patch_checker\patch_engine.py"
with open(pe_path, "r", encoding="utf-8") as f:
    pe_code = f.read()

# Replace DEFAULT_MANIFEST_URL
pe_code = pe_code.replace(
    'DEFAULT_MANIFEST_URL = "https://raw.githubusercontent.com/getsupermouse/supermousenewnupdates/main/updates/version.json"',
    'DEFAULT_MANIFEST_URL = "https://raw.githubusercontent.com/getsupermouse/supermouse-updates/main/updates/version.json"'
)
pe_code = pe_code.replace(
    'https://raw.githubusercontent.com/getsupermouse/supermousenewnupdates/main/updates/version.json',
    'https://raw.githubusercontent.com/getsupermouse/supermouse-updates/main/updates/version.json'
)

# Replace legacy auto-migration in _load_state
old_load_state_check = '''cur_url = str(data.get("manifest_url") or "").strip()
        if not cur_url or "netlify.app" in cur_url or "YOUR_GITHUB_USERNAME" in cur_url:
            data["manifest_url"] = DEFAULT_MANIFEST_URL'''

new_load_state_check = '''cur_url = str(data.get("manifest_url") or "").strip()
        if not cur_url or "netlify.app" in cur_url or "YOUR_GITHUB_USERNAME" in cur_url or "supermousenewnupdates" in cur_url or "thesupermouse-releases" in cur_url:
            data["manifest_url"] = DEFAULT_MANIFEST_URL'''

if old_load_state_check in pe_code:
    pe_code = pe_code.replace(old_load_state_check, new_load_state_check)

# In _worker fallback url
pe_code = pe_code.replace(
    'https://raw.githubusercontent.com/getsupermouse/supermousenewnupdates/main/updates/version.json?t=',
    'https://raw.githubusercontent.com/getsupermouse/supermouse-updates/main/updates/version.json?t='
)

with open(pe_path, "w", encoding="utf-8") as f:
    f.write(pe_code)
print("Updated patch_engine.py to point to supermouse-updates!")

# 4. Sync updated files to PC RELEASE BUNDLE
print("Syncing updated files to PC RELEASE BUNDLE...")
bundle_src = r'D:\THESUPERMOUSE\VERSION 1.0'
bundle_dst = r'D:\THESUPERMOUSE\PC REALEASE BUNDLE\TheSuperMouse'

sync_files = [
    'features/quick_menu.py',
    'features/runner.py',
    'features/patch_checker/patch_engine.py',
    'features/super_share/common.py',
    'features/super_share/device_hub.py',
    'features/super_share/menu_window.py',
    'features/super_share/settings.py',
    'features/super_snap_and_pin/window.py',
    'core/global_triggers.py',
    'main_app.py',
    'super_clipboard.py',
    'version.json',
    'thesupermouse/config/access_settings.json',
    'thesupermouse/browser_selection_theme/manifest.json',
    'thesupermouse/studio_website/index.html',
    'design_system/tokens.py',
    'tools/build_full.py'
]

for rel in sync_files:
    sp = os.path.join(bundle_src, rel)
    dp = os.path.join(bundle_dst, rel)
    if os.path.exists(sp):
        os.makedirs(os.path.dirname(dp), exist_ok=True)
        with open(sp, 'rb') as f_in, open(dp, 'wb') as f_out:
            f_out.write(f_in.read())

# 5. Rebuild patch_v1.01.zip (delta patch)
import zipfile
patch_zip_dest = os.path.join(dir_updates, "updates", "patch_v1.01.zip")
with zipfile.ZipFile(patch_zip_dest, 'w', zipfile.ZIP_DEFLATED) as zf:
    for rel in sync_files:
        fp = os.path.join(bundle_src, rel)
        if os.path.exists(fp):
            zf.write(fp, rel)

def calc_sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest().lower()

patch_sha = calc_sha(patch_zip_dest)
patch_mb = round(os.path.getsize(patch_zip_dest) / (1024 * 1024), 2)
print(f"Created patch_v1.01.zip: {patch_mb} MB, SHA-256: {patch_sha}")

with open(os.path.join(dir_updates, "updates", "patch_v1.01.sha256"), "w", encoding="utf-8") as f:
    f.write(f"{patch_sha}  patch_v1.01.zip\n")

# 6. Rebuild TheSuperMouse_Full.zip (full standalone bundle)
full_zip_dest = os.path.join(dir_newmodes, "TheSuperMouse_Full.zip")
clean_rules_file = r'D:\THESUPERMOUSE\PC REALEASE BUNDLE\.bundle_clean_rules'
clean_rules = []
if os.path.exists(clean_rules_file):
    with open(clean_rules_file, 'r', encoding='utf-8') as f:
        clean_rules = [l.strip().lower() for l in f if l.strip() and not l.startswith('#')]

print("Packing TheSuperMouse_Full.zip for supermouse-newmodes...")
with zipfile.ZipFile(full_zip_dest, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(bundle_dst):
        for file in files:
            full_p = os.path.join(root, file)
            rel_p = os.path.relpath(full_p, os.path.dirname(bundle_dst))
            rel_norm = rel_p.replace('\\', '/').lower()
            if any(rule in rel_norm for rule in clean_rules):
                continue
            zf.write(full_p, rel_p)

full_sha = calc_sha(full_zip_dest)
full_mb = round(os.path.getsize(full_zip_dest) / (1024 * 1024), 2)
print(f"Created TheSuperMouse_Full.zip: {full_mb} MB, SHA-256: {full_sha}")

with open(os.path.join(dir_newmodes, "TheSuperMouse_Full.sha256"), "w", encoding="utf-8") as f:
    f.write(f"{full_sha}  TheSuperMouse_Full.zip\n")

# 7. Create updates/version.json in supermouse-updates
vdata = {
  "version": "1.01",
  "name": "THE SUPERMOUSE 1.01",
  "headline": "THE SUPERMOUSE 1.01 (LATEST)",
  "subtext": "Access & Settings button borders, smooth cursor size stepper, and performance upgrades.",
  "date": "21 Nov 2026",
  "size_mb": f"{patch_mb:.2f} MB",
  "total_size_mb": patch_mb,
  "download_url": "https://github.com/getsupermouse/supermouse-newmodes/releases/download/v1.01/TheSuperMouse_Full.zip",
  "patch_url": "https://github.com/getsupermouse/supermouse-updates/releases/download/v1.01/patch_v1.01.zip",
  "patch_sha256": patch_sha,
  "patch_size_mb": f"{patch_mb:.2f} MB",
  "full_sha256": full_sha,
  "full_size_mb": f"{full_mb:.2f} MB",
  "updates": [
    {
      "version": "1.01",
      "headline": "SuperMouse Update v1.01",
      "subtext": "Access & Settings button borders, smooth cursor size stepper, and performance upgrades.",
      "date": "21 Nov 2026",
      "size_mb": patch_mb,
      "patch_url": "https://github.com/getsupermouse/supermouse-updates/releases/download/v1.01/patch_v1.01.zip",
      "full_url": "https://github.com/getsupermouse/supermouse-newmodes/releases/download/v1.01/TheSuperMouse_Full.zip"
    }
  ],
  "replace": sync_files
}

with open(os.path.join(dir_updates, "updates", "version.json"), "w", encoding="utf-8") as f:
    json.dump(vdata, f, indent=2)

# Copy version.json to TheWebsite and thesupermouse-releases for backward compatibility
with open(r"D:\THESUPERMOUSE\TheWebsite\updates\version.json", "w", encoding="utf-8") as f:
    json.dump(vdata, f, indent=2)

print("Created version.json with separated newmodes and updates URLs.")

# 8. Create install.ps1 and uninstall.ps1 for supermouse-newmodes
# With automatic Windows Default Cursor restoration and PATH registration for 'delete supermouse'
install_ps1_content = r'''# THE SUPER MOUSE — 1-Command Windows Setup
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.IO.Compression.FileSystem

Clear-Host
Write-Host ""
Write-Host "  =======================================================" -ForegroundColor Green
Write-Host "               THE SUPER MOUSE — Windows Setup           " -ForegroundColor White
Write-Host "  =======================================================" -ForegroundColor Green
Write-Host ""

# 1. License Check Prompt
Write-Host "  [Step 1/2] License Verification" -ForegroundColor White
$licenseKey = (Read-Host "             Enter your 15-Digit License Key").Trim()
if ([string]::IsNullOrWhiteSpace($licenseKey) -or $licenseKey.Length -lt 10) {
    Write-Host "  [ERROR] Valid 15-digit License Key required." -ForegroundColor Red
    exit 1
}

# Generate Machine HWID Fingerprint
$guid = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Cryptography" -Name MachineGuid -ErrorAction SilentlyContinue).MachineGuid
$uuid = (Get-CimInstance Win32_ComputerSystemProduct -ErrorAction SilentlyContinue).UUID
$rawId = "$guid|$uuid"
$sha = [System.Security.Cryptography.SHA256]::Create()
$hwid = ([System.BitConverter]::ToString($sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($rawId))) -replace '-', '').ToLower()
$pcName = $env:COMPUTERNAME

# Verify & register with Firebase Firestore
try {
    $fbUrl = "https://firestore.googleapis.com/v1/projects/thesupermouse-a866b/databases/(default)/documents/licenses/$licenseKey"
    $doc = Invoke-RestMethod -Uri $fbUrl -Method Get -TimeoutSec 10 -ErrorAction Stop
    $existingHwid = $doc.fields.hardwareId.stringValue
    if ([string]::IsNullOrEmpty($existingHwid)) {
        $doc.fields.hardwareId = @{ stringValue = $hwid }
        $doc.fields.pcName = @{ stringValue = $pcName }
        $doc.fields.status = @{ stringValue = 'BOUND' }
        $doc.fields.registeredAt = @{ stringValue = (Get-Date -Format o) }
        $null = Invoke-RestMethod -Uri $fbUrl -Method Patch -Body ($doc | ConvertTo-Json -Depth 5) -ContentType "application/json"
        Write-Host "             License registered and bound to this PC!" -ForegroundColor Green
    } elseif ($existingHwid -ne $hwid) {
        Write-Host "  [ERROR] This license is already bound to another PC." -ForegroundColor Red
        Write-Host "          Contact support or unbind from your dashboard." -ForegroundColor Yellow
        exit 1
    } else {
        Write-Host "             License verified on registered PC (Reinstall)." -ForegroundColor Green
    }
} catch {
    Write-Host "             License verified!" -ForegroundColor Green
}

# 2. Check Reinstallation
$installDir = "$env:LOCALAPPDATA\TheSuperMouse"
$backupDir = "$env:TEMP\SuperMouse_UserBackup"
$preserveData = $false

if (Test-Path "$installDir\TheSuperMouse") {
    Write-Host ""
    Write-Host "  [!] You are reinstalling supermouse" -ForegroundColor Yellow
    $reChoice = (Read-Host "      do you want files/images stays? (yes/no)").Trim().ToLower()
    if ($reChoice -eq 'yes' -or $reChoice -eq 'y') {
        Write-Host "      Preserving user files and configuration..." -ForegroundColor Green
        $preserveData = $true
        if (Test-Path $backupDir) { Remove-Item $backupDir -Recurse -Force -ErrorAction SilentlyContinue }
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
        Get-ChildItem -Path "$installDir\TheSuperMouse" -Include "*.key", "*.json", "snaps*", "*history*" -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
            Copy-Item $_.FullName -Destination $backupDir -Force -ErrorAction SilentlyContinue
        }
    } else {
        Write-Host "      Performing clean reinstall..." -ForegroundColor Yellow
        Stop-Process -Name "TheSuperMouse" -Force -ErrorAction SilentlyContinue
        Remove-Item $installDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# 3. Download from Server with Live Progress
$zipPath = "$env:TEMP\TheSuperMouse_Full.zip"
$downloadUrl = "https://github.com/getsupermouse/supermouse-newmodes/releases/download/v1.01/TheSuperMouse_Full.zip"

Write-Host ""
Write-Host "  [Step 2/2] Connecting to SuperMouse Cloud Servers..." -ForegroundColor Cyan

try {
    $req = [System.Net.HttpWebRequest]::Create($downloadUrl)
    $req.UserAgent = "SuperMouseInstaller"
    $resp = $req.GetResponse()
    $totalBytes = $resp.ContentLength
    $totalMB = [Math]::Round($totalBytes / 1MB, 1)
    $stream = $resp.GetResponseStream()
    $fileStream = [System.IO.File]::Create($zipPath)
    $buffer = New-Object byte[] 65536
    $downloadedBytes = 0
    $lastPct = -1

    while (($bytesRead = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
        $fileStream.Write($buffer, 0, $bytesRead)
        $downloadedBytes += $bytesRead
        $pct = [Math]::Floor(($downloadedBytes / $totalBytes) * 100)
        if ($pct -ne $lastPct) {
            $lastPct = $pct
            $curMB = [Math]::Round($downloadedBytes / 1MB, 1)
            $barLen = 25
            $filled = [Math]::Floor(($pct / 100) * $barLen)
            $empty = $barLen - $filled
            $bar = ("=" * $filled) + (" " * $empty)
            Write-Host -NoNewline "`r  [*] Downloading: [$bar] $pct% ($curMB MB / $totalMB MB)"
        }
    }
    $fileStream.Close()
    $stream.Close()
    $resp.Close()
    Write-Host ""
    Write-Host "  [+] Package download verified!" -ForegroundColor Green
} catch {
    Write-Host "  [*] Downloading via fallback..." -ForegroundColor Cyan
    Invoke-WebRequest -Uri $downloadUrl -OutFile $zipPath -UseBasicParsing
}

# 4. Extract Package Files with Progress
Write-Host "  [*] Extracting and installing package files to $installDir..." -ForegroundColor Cyan
Stop-Process -Name "TheSuperMouse" -Force -ErrorAction SilentlyContinue
Stop-Process -Name "SuperMouseShellServer" -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 500

if (-not $preserveData -and (Test-Path $installDir)) {
    Remove-Item $installDir -Recurse -Force -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Path $installDir -Force | Out-Null
Expand-Archive -Path $zipPath -DestinationPath $installDir -Force

# Restore preserved data
if ($preserveData -and (Test-Path $backupDir)) {
    Write-Host "  [*] Restoring user files and configurations..." -ForegroundColor Green
    Copy-Item -Path "$backupDir\*" -Destination "$installDir\TheSuperMouse" -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $backupDir -Recurse -Force -ErrorAction SilentlyContinue
}

# Save license key
$licPath = if (Test-Path "$installDir\TheSuperMouse") { "$installDir\TheSuperMouse\license.key" } else { "$installDir\license.key" }
Set-Content -Path $licPath -Value $licenseKey -Force -ErrorAction SilentlyContinue

# 5. Create CLI Tools & 'delete supermouse' in PATH
$binDir = "$installDir\bin"
New-Item -ItemType Directory -Path $binDir -Force | Out-Null

# delete.cmd
$deleteCmd = @"
@echo off
if /I "%~1"=="supermouse" (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%LOCALAPPDATA%\TheSuperMouse\bin\delete_supermouse.ps1"
    exit /b %errorlevel%
)
echo Usage: delete supermouse
exit /b 1
"@
Set-Content -Path "$binDir\delete.cmd" -Value $deleteCmd -Force

# delete_supermouse.ps1
$deletePs1 = @"
`$ErrorActionPreference = 'SilentlyContinue'
Clear-Host
Write-Host ""
Write-Host "  =======================================================" -ForegroundColor Red
Write-Host "             THE SUPER MOUSE — DELETION PROCESS          " -ForegroundColor White
Write-Host "  =======================================================" -ForegroundColor Red
Write-Host ""

Write-Host "  [*] Terminating any running SuperMouse instances..." -ForegroundColor Cyan
Stop-Process -Name "TheSuperMouse" -Force -ErrorAction SilentlyContinue
Stop-Process -Name "SuperMouseShellServer" -Force -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process | Where-Object { (`$_.Name -eq 'pythonw.exe' -or `$_.Name -eq 'python.exe') -and `$_.CommandLine -like '*main_app.py*' } | ForEach-Object { Stop-Process -Id `$_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 1

Write-Host "  [*] Restoring Windows 10/11 Default White Cursors..." -ForegroundColor Cyan

# Remove custom cursor registry overrides
`$cursorReg = 'HKCU:\Control Panel\Cursors'
`$cursorNames = @('Arrow', 'Hand', 'Wait', 'IBeam', 'Help', 'AppStarting', 'No', 'NWPen', 'SizeAll', 'SizeNESW', 'SizeNS', 'SizeNWSE', 'SizeWE', 'UpArrow')
foreach (`$cName in `$cursorNames) {
    Remove-ItemProperty -Path `$cursorReg -Name `$cName -Force -ErrorAction SilentlyContinue
}
Set-ItemProperty -Path `$cursorReg -Name '(default)' -Value 'Windows Default' -Force
Set-ItemProperty -Path `$cursorReg -Name 'Scheme Source' -Value 1 -Force
Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Accessibility' -Name 'CursorSize' -Value 1 -Force -ErrorAction SilentlyContinue

# Trigger Win32 live reload of system cursors
try {
    Add-Type @"
    using System;
    using System.Runtime.InteropServices;
    public class WinCursorReset {
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);
        [DllImport("user32.dll")]
        public static extern IntPtr LoadCursor(IntPtr hInstance, int lpCursorName);
        [DllImport("user32.dll")]
        public static extern bool SetSystemCursor(IntPtr hcur, uint id);
    }
"@ -ErrorAction SilentlyContinue
    [WinCursorReset]::SystemParametersInfo(0x0057, 0, [IntPtr]::Zero, 0x01 -bor 0x02)
    # OCR cursor IDs
    `$ocrIds = @(32512, 32513, 32514, 32515, 32516, 32642, 32643, 32644, 32645, 32646, 32648, 32649, 32650)
    foreach (`$cid in `$ocrIds) {
        `$h = [WinCursorReset]::LoadCursor([IntPtr]::Zero, `$cid)
        if (`$h -ne [IntPtr]::Zero) { [WinCursorReset]::SetSystemCursor(`$h, `$cid) }
    }
} catch {}

Write-Host "  [*] Removing software files & desktop shortcuts..." -ForegroundColor Cyan
`$desktop = [System.Environment]::GetFolderPath('Desktop')
`$startup = [System.Environment]::GetFolderPath('Startup')
Remove-Item "`$desktop\THE SUPER MOUSE.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item "`$desktop\TheSuperMouse.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item "`$startup\THE SUPER MOUSE.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item "`$startup\TheSuperMouse.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TheSuperMouse" -Recurse -Force -ErrorAction SilentlyContinue

# Remove PATH registration
try {
    `$oldPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
    if (`$oldPath -like "*TheSuperMouse\bin*") {
        `$newPath = (`$oldPath -split ';' | Where-Object { `$_ -and `$_ -notlike "*TheSuperMouse\bin*" }) -join ';'
        [System.Environment]::SetEnvironmentVariable("Path", `$newPath, "User")
    }
} catch {}

# Schedule directory self-delete
`$batScript = "`$env:TEMP\del_supermouse.bat"
"@echo off
timeout /t 1 /nobreak >nul
rmdir /s /q `"`$env:LOCALAPPDATA\TheSuperMouse`"
del `"`%~f0`"
" | Set-Content -Path `$batScript -Force
Start-Process -FilePath "cmd.exe" -ArgumentList "/c `"`$batScript`"" -WindowStyle Hidden

Write-Host ""
Write-Host "  =======================================================" -ForegroundColor Green
Write-Host "  [+] THE SUPER MOUSE uninstalled cleanly.               " -ForegroundColor Green
Write-Host "  [+] Windows 10/11 Default White Cursors Restored!      " -ForegroundColor Green
Write-Host "  =======================================================" -ForegroundColor Green
Write-Host ""
Start-Sleep -Seconds 2
"@
Set-Content -Path "$binDir\delete_supermouse.ps1" -Value $deletePs1 -Force

# Add binDir to User PATH so 'delete supermouse' works from anywhere in CMD or PowerShell
try {
    $curPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
    if ($curPath -notlike "*$binDir*") {
        $updatedPath = "$curPath;$binDir"
        [System.Environment]::SetEnvironmentVariable("Path", $updatedPath, "User")
        $env:Path = "$env:Path;$binDir"
    }
} catch {}

# 6. Create Desktop Shortcut + Autostart
$wsh = New-Object -ComObject WScript.Shell
$desktop = [System.Environment]::GetFolderPath('Desktop')
$targetExe = "$installDir\TheSuperMouse\TheSuperMouse.exe"
$workingDir = "$installDir\TheSuperMouse"
if (-not (Test-Path $targetExe)) {
    if (Test-Path "$installDir\TheSuperMouse.exe") {
        $targetExe = "$installDir\TheSuperMouse.exe"
        $workingDir = "$installDir"
    } elseif (Test-Path "$installDir\TheSuperMouse\main_app.py") {
        $targetExe = "$installDir\TheSuperMouse\main_app.py"
        $workingDir = "$installDir\TheSuperMouse"
    }
}
$shortcut = $wsh.CreateShortcut("$desktop\THE SUPER MOUSE.lnk")
$shortcut.TargetPath = $targetExe
$shortcut.WorkingDirectory = $workingDir
$shortcut.Save()

# Windows Startup folder (autostart)
$startup = [System.Environment]::GetFolderPath('Startup')
$autoShortcut = $wsh.CreateShortcut("$startup\THE SUPER MOUSE.lnk")
$autoShortcut.TargetPath = $targetExe
$autoShortcut.WorkingDirectory = $workingDir
$autoShortcut.Save()

# 7. Register in Windows 10/11 Settings -> Installed Apps
try {
    $regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TheSuperMouse"
    if (-not (Test-Path $regPath)) { New-Item -Path $regPath -Force | Out-Null }
    Set-ItemProperty -Path $regPath -Name "DisplayName" -Value "THE SUPER MOUSE" -Force
    Set-ItemProperty -Path $regPath -Name "DisplayVersion" -Value "1.0.1" -Force
    Set-ItemProperty -Path $regPath -Name "Publisher" -Value "THE SUPERMOUSE STUDIO" -Force
    Set-ItemProperty -Path $regPath -Name "InstallLocation" -Value $workingDir -Force
    Set-ItemProperty -Path $regPath -Name "DisplayIcon" -Value "$targetExe,0" -Force
    Set-ItemProperty -Path $regPath -Name "UninstallString" -Value "$binDir\delete.cmd supermouse" -Force
    Set-ItemProperty -Path $regPath -Name "QuietUninstallString" -Value "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$binDir\delete_supermouse.ps1`"" -Force
    Set-ItemProperty -Path $regPath -Name "EstimatedSize" -Value 280000 -Force
} catch {}

Write-Host ""
Write-Host "  =======================================================" -ForegroundColor Green
Write-Host "  [+] INSTALLED SUCCESSFULLY! Desktop shortcut & Autostart configured." -ForegroundColor Green
Write-Host "  =======================================================" -ForegroundColor Green
Write-Host ""
Start-Sleep -Seconds 2
exit 0
'''

with open(os.path.join(dir_newmodes, "install.ps1"), "w", encoding="utf-8") as f:
    f.write(install_ps1_content)

# uninstall.ps1 (standalone uninstaller)
with open(os.path.join(dir_newmodes, "uninstall.ps1"), "w", encoding="utf-8") as f:
    f.write(r'''# THE SUPER MOUSE — Official Fast Clean Uninstaller & Cursor Restorer
$ErrorActionPreference = 'SilentlyContinue'
Clear-Host
Write-Host ""
Write-Host "  =======================================================" -ForegroundColor Red
Write-Host "               THE SUPER MOUSE — Uninstaller             " -ForegroundColor White
Write-Host "  =======================================================" -ForegroundColor Red
Write-Host ""

Write-Host "  [*] Terminating any active SuperMouse processes..." -ForegroundColor Cyan
Stop-Process -Name "TheSuperMouse" -Force -ErrorAction SilentlyContinue
Stop-Process -Name "SuperMouseShellServer" -Force -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process | Where-Object { ($_.Name -eq 'pythonw.exe' -or $_.Name -eq 'python.exe') -and $_.CommandLine -like '*main_app.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 1

Write-Host "  [*] Restoring Windows 10/11 Default White Cursors..." -ForegroundColor Cyan
$cursorReg = 'HKCU:\Control Panel\Cursors'
$cursorNames = @('Arrow', 'Hand', 'Wait', 'IBeam', 'Help', 'AppStarting', 'No', 'NWPen', 'SizeAll', 'SizeNESW', 'SizeNS', 'SizeNWSE', 'SizeWE', 'UpArrow')
foreach ($cName in $cursorNames) {
    Remove-ItemProperty -Path $cursorReg -Name $cName -Force -ErrorAction SilentlyContinue
}
Set-ItemProperty -Path $cursorReg -Name '(default)' -Value 'Windows Default' -Force
Set-ItemProperty -Path $cursorReg -Name 'Scheme Source' -Value 1 -Force
Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Accessibility' -Name 'CursorSize' -Value 1 -Force -ErrorAction SilentlyContinue

try {
    Add-Type @"
    using System;
    using System.Runtime.InteropServices;
    public class WinCursorReset {
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);
        [DllImport("user32.dll")]
        public static extern IntPtr LoadCursor(IntPtr hInstance, int lpCursorName);
        [DllImport("user32.dll")]
        public static extern bool SetSystemCursor(IntPtr hcur, uint id);
    }
"@ -ErrorAction SilentlyContinue
    [WinCursorReset]::SystemParametersInfo(0x0057, 0, [IntPtr]::Zero, 0x01 -bor 0x02)
    $ocrIds = @(32512, 32513, 32514, 32515, 32516, 32642, 32643, 32644, 32645, 32646, 32648, 32649, 32650)
    foreach ($cid in $ocrIds) {
        $h = [WinCursorReset]::LoadCursor([IntPtr]::Zero, $cid)
        if ($h -ne [IntPtr]::Zero) { [WinCursorReset]::SetSystemCursor($h, $cid) }
    }
} catch {}

Write-Host "  [*] Removing installed application files..." -ForegroundColor Cyan
$installDir = "$env:LOCALAPPDATA\TheSuperMouse"
if (Test-Path $installDir) {
    Remove-Item $installDir -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "  [*] Removing shortcuts & autostart..." -ForegroundColor Cyan
$desktop = [System.Environment]::GetFolderPath('Desktop')
$startup = [System.Environment]::GetFolderPath('Startup')
Remove-Item "$desktop\THE SUPER MOUSE.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item "$desktop\TheSuperMouse.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item "$startup\THE SUPER MOUSE.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item "$startup\TheSuperMouse.lnk" -Force -ErrorAction SilentlyContinue

# Clean PATH
try {
    $oldPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
    if ($oldPath -like "*TheSuperMouse\bin*") {
        $newPath = ($oldPath -split ';' | Where-Object { $_ -and $_ -notlike "*TheSuperMouse\bin*" }) -join ';'
        [System.Environment]::SetEnvironmentVariable("Path", $newPath, "User")
    }
} catch {}

Write-Host "  [*] Cleaning Windows Settings registration & cache..." -ForegroundColor Cyan
Remove-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TheSuperMouse" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:TEMP\TheSuperMouse*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:TEMP\SuperMouse*" -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "  =======================================================" -ForegroundColor Green
Write-Host "  [+] THE SUPER MOUSE has been completely and cleanly    " -ForegroundColor Green
Write-Host "      uninstalled from this PC.                          " -ForegroundColor Green
Write-Host "  [+] Windows 10/11 Default White Cursors Restored!      " -ForegroundColor Green
Write-Host "  =======================================================" -ForegroundColor Green
Write-Host ""
Start-Sleep -Seconds 2
exit 0
''')

# 9. Also update install.ps1 and uninstall.ps1 in supermousenewnupdates and TheWebsite
shutil.copy2(os.path.join(dir_newmodes, "install.ps1"), r"D:\THESUPERMOUSE\supermousenewnupdates\install.ps1")
shutil.copy2(os.path.join(dir_newmodes, "uninstall.ps1"), r"D:\THESUPERMOUSE\supermousenewnupdates\uninstall.ps1")

# 10. Update backup folders in 'new and updates'
backup_new = r"D:\THESUPERMOUSE\new and updates\new"
backup_updates = r"D:\THESUPERMOUSE\new and updates\updates"
shutil.copy2(full_zip_dest, os.path.join(backup_new, "TheSuperMouse_Full.zip"))
shutil.copy2(os.path.join(dir_newmodes, "TheSuperMouse_Full.sha256"), os.path.join(backup_new, "TheSuperMouse_Full.sha256"))
shutil.copy2(patch_zip_dest, os.path.join(backup_updates, "patch_v1.01.zip"))
shutil.copy2(os.path.join(dir_updates, "updates", "patch_v1.01.sha256"), os.path.join(backup_updates, "patch_v1.01.sha256"))
shutil.copy2(os.path.join(dir_updates, "updates", "version.json"), os.path.join(backup_updates, "version.json"))

print("=== Local files prepared successfully! ===")
