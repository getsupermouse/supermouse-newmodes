import os
import json
import subprocess

print("=== 1. Updating TheWebsite/_worker.js with direct /updates/version.json route ===")
vjson_path = r'D:\THESUPERMOUSE\TheWebsite\updates\version.json'
with open(vjson_path, 'r', encoding='utf-8') as f:
    vdata = json.load(f)

worker_path = r'D:\THESUPERMOUSE\TheWebsite\_worker.js'
with open(worker_path, 'r', encoding='utf-8') as f:
    wcode = f.read()

v_const = f"const VERSION_MANIFEST = {json.dumps(vdata, indent=2)};\n\n"

# Insert v_const after imports/constants
if "const VERSION_MANIFEST =" not in wcode:
    wcode = v_const + wcode

# Add route in fetch handler
route_code = '''    // Direct update manifest route
    if (url.pathname === '/updates/version.json' || url.pathname === '/version.json') {
      return new Response(JSON.stringify(VERSION_MANIFEST), {
        status: 200,
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Access-Control-Allow-Origin': '*',
          'Cache-Control': 'no-cache, no-store, must-revalidate',
        },
      });
    }
'''

if "url.pathname === '/updates/version.json'" not in wcode:
    # insert right after OPTIONS preflight
    wcode = wcode.replace("if (request.method === 'OPTIONS') {", route_code + "\n    if (request.method === 'OPTIONS') {")

with open(worker_path, 'w', encoding='utf-8') as f:
    f.write(wcode)
print("Updated _worker.js")

# 2. Deploy to Cloudflare Pages
print("=== 2. Deploying to Cloudflare Pages ===")
subprocess.run('npx wrangler pages deploy . --project-name getsupermouse', shell=True, cwd=r'D:\THESUPERMOUSE\TheWebsite')

# 3. Push to getsupermouse.github.io for Netlify auto-deployment
print("=== 3. Pushing to getsupermouse.github.io ===")
subprocess.run(['git', 'add', '-A'], cwd=r'D:\THESUPERMOUSE\TheWebsite')
subprocess.run(['git', 'commit', '-m', 'Update v1.01 manifest and routes'], cwd=r'D:\THESUPERMOUSE\TheWebsite')
subprocess.run(['git', 'push', 'origin', 'main'], cwd=r'D:\THESUPERMOUSE\TheWebsite')

# 4. Push to thesupermouse-releases
print("=== 4. Pushing to thesupermouse-releases ===")
subprocess.run(['git', 'add', '-A'], cwd=r'D:\THESUPERMOUSE\thesupermouse-releases')
subprocess.run(['git', 'commit', '-m', 'Update v1.01 release manifest'], cwd=r'D:\THESUPERMOUSE\thesupermouse-releases')
subprocess.run(['git', 'push', 'origin', 'main'], cwd=r'D:\THESUPERMOUSE\thesupermouse-releases')

print("=== Deployment finished! ===")
