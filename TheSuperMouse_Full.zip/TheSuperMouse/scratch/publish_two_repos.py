import os
import subprocess
import urllib.request
import json
import time

print("=================================================================")
print("  Publishing Releases to supermouse-newmodes & supermouse-updates")
print("=================================================================")

# 1. Retrieve Git token
p = subprocess.Popen(['git', 'credential', 'fill'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
out, _ = p.communicate(input='protocol=https\nhost=github.com\n\n')
token = None
for l in out.splitlines():
    if l.startswith('password='):
        token = l.split('=', 1)[1]

if not token:
    raise RuntimeError("GitHub token not found!")

headers = {
    'Authorization': f'token {token}',
    'Accept': 'application/vnd.github.v3+json',
    'User-Agent': 'TheSuperMouseReleaseEngine'
}

# --- REPO 1: supermouse-updates ---
print("\n--- Publishing to getsupermouse/supermouse-updates ---")
dir_updates = r"D:\THESUPERMOUSE\supermouse-updates"

# Git init and push main
subprocess.run(['git', 'init'], cwd=dir_updates)
subprocess.run(['git', 'remote', 'remove', 'origin'], cwd=dir_updates, capture_output=True)
subprocess.run(['git', 'remote', 'add', 'origin', 'https://github.com/getsupermouse/supermouse-updates.git'], cwd=dir_updates)
subprocess.run(['git', 'checkout', '-B', 'main'], cwd=dir_updates)
subprocess.run(['git', 'add', '-A', ':!updates/*.zip'], cwd=dir_updates) # don't commit zip to git tree
subprocess.run(['git', 'commit', '-m', 'Initial v1.01 update manifests and SHA-256 signatures'], cwd=dir_updates)
subprocess.run(['git', 'push', '-u', 'origin', 'main', '--force'], cwd=dir_updates)
print("Pushed main branch to supermouse-updates.")

# Create Release v1.01 on supermouse-updates
repo_updates = "getsupermouse/supermouse-updates"
create_data = {
    "tag_name": "v1.01",
    "target_commitish": "main",
    "name": "THE SUPERMOUSE v1.01 Delta Patch",
    "body": "Official SHA-256 Delta Patch v1.01 for existing installations.",
    "draft": False,
    "prerelease": False,
    "make_latest": "true"
}

req = urllib.request.Request(
    f'https://api.github.com/repos/{repo_updates}/releases',
    data=json.dumps(create_data).encode('utf-8'),
    headers={**headers, 'Content-Type': 'application/json'},
    method='POST'
)

try:
    with urllib.request.urlopen(req) as resp:
        rel_up = json.load(resp)
        upload_base_up = rel_up['upload_url'].split('{')[0]
        print(f"Created Release v1.01 in {repo_updates} (ID: {rel_up['id']})")

        # Upload patch_v1.01.zip
        patch_file = os.path.join(dir_updates, "updates", "patch_v1.01.zip")
        sz = os.path.getsize(patch_file)
        with open(patch_file, 'rb') as f_data:
            data_bytes = f_data.read()

        req_up = urllib.request.Request(
            f"{upload_base_up}?name=patch_v1.01.zip",
            data=data_bytes,
            headers={
                'Authorization': f'token {token}',
                'Content-Type': 'application/zip',
                'Content-Length': str(sz),
                'User-Agent': 'TheSuperMouseReleaseEngine'
            },
            method='POST'
        )
        with urllib.request.urlopen(req_up) as up_r:
            print("Uploaded patch_v1.01.zip successfully to supermouse-updates!")
except Exception as e:
    print(f"Error creating release in {repo_updates}: {e}")


# --- REPO 2: supermouse-newmodes ---
print("\n--- Publishing to getsupermouse/supermouse-newmodes ---")
dir_newmodes = r"D:\THESUPERMOUSE\supermouse-newmodes"

# Git init and push main
subprocess.run(['git', 'init'], cwd=dir_newmodes)
subprocess.run(['git', 'remote', 'remove', 'origin'], cwd=dir_newmodes, capture_output=True)
subprocess.run(['git', 'remote', 'add', 'origin', 'https://github.com/getsupermouse/supermouse-newmodes.git'], cwd=dir_newmodes)
subprocess.run(['git', 'checkout', '-B', 'main'], cwd=dir_newmodes)
subprocess.run(['git', 'add', '-A', ':!*.zip'], cwd=dir_newmodes) # don't commit zip to git tree
subprocess.run(['git', 'commit', '-m', 'Initial v1.01 installer, uninstaller, and SHA-256 signatures'], cwd=dir_newmodes)
subprocess.run(['git', 'push', '-u', 'origin', 'main', '--force'], cwd=dir_newmodes)
print("Pushed main branch to supermouse-newmodes.")

# Create Release v1.01 on supermouse-newmodes
repo_new = "getsupermouse/supermouse-newmodes"
create_data_new = {
    "tag_name": "v1.01",
    "target_commitish": "main",
    "name": "THE SUPERMOUSE v1.01 Official Standalone",
    "body": "Official standalone distribution package for new users and clean installs.",
    "draft": False,
    "prerelease": False,
    "make_latest": "true"
}

req_new = urllib.request.Request(
    f'https://api.github.com/repos/{repo_new}/releases',
    data=json.dumps(create_data_new).encode('utf-8'),
    headers={**headers, 'Content-Type': 'application/json'},
    method='POST'
)

try:
    with urllib.request.urlopen(req_new) as resp:
        rel_new = json.load(resp)
        upload_base_new = rel_new['upload_url'].split('{')[0]
        print(f"Created Release v1.01 in {repo_new} (ID: {rel_new['id']})")

        # Upload TheSuperMouse_Full.zip (115.53 MB)
        full_file = os.path.join(dir_newmodes, "TheSuperMouse_Full.zip")
        sz_f = os.path.getsize(full_file)
        print(f"Uploading TheSuperMouse_Full.zip ({sz_f / (1024*1024):.2f} MB)...")
        with open(full_file, 'rb') as f_data:
            data_bytes = f_data.read()

        req_up_new = urllib.request.Request(
            f"{upload_base_new}?name=TheSuperMouse_Full.zip",
            data=data_bytes,
            headers={
                'Authorization': f'token {token}',
                'Content-Type': 'application/zip',
                'Content-Length': str(sz_f),
                'User-Agent': 'TheSuperMouseReleaseEngine'
            },
            method='POST'
        )
        with urllib.request.urlopen(req_up_new) as up_r_new:
            print("Uploaded TheSuperMouse_Full.zip successfully to supermouse-newmodes!")
except Exception as e:
    print(f"Error creating release in {repo_new}: {e}")

# Delete old releases on supermousenewnupdates
print("\n--- Cleaning old releases on supermousenewnupdates ---")
try:
    req_old = urllib.request.Request('https://api.github.com/repos/getsupermouse/supermousenewnupdates/releases', headers=headers)
    with urllib.request.urlopen(req_old) as r_old:
        for r_item in json.load(r_old):
            del_id = r_item['id']
            del_req = urllib.request.Request(f'https://api.github.com/repos/getsupermouse/supermousenewnupdates/releases/{del_id}', headers=headers, method='DELETE')
            urllib.request.urlopen(del_req)
            print(f"Deleted old release {r_item.get('tag_name')} (ID: {del_id}) from supermousenewnupdates")
except Exception as e:
    print("Old release purge note:", e)

print("\n=== Release publishing to both repos complete! ===")
