import os

path = r"D:\THESUPERMOUSE\SuperMouseHQ\index.html"
with open(path, "r", encoding="utf-8") as f:
    html = f.read()

# 1. Add nav button in desktop nav
nav_marker = '<button class="nav-btn" data-tab="github">GitHub Packaging</button>'
nav_broadcast = '<button class="nav-btn" data-tab="broadcast">🔔 Broadcast Notifications</button>'
if nav_broadcast not in html:
    html = html.replace(nav_marker, nav_marker + "\n      " + nav_broadcast)

# 2. Add dock button in mobile dock
dock_marker = '<button class="dock-btn" data-tab="github">Git</button>'
dock_broadcast = '<button class="dock-btn" data-tab="broadcast">Notifs</button>'
if dock_broadcast not in html:
    html = html.replace(dock_marker, dock_marker + "\n    " + dock_broadcast)

# 3. Add Broadcast section after tab-github
broadcast_section = """
    <!-- SECTION: BROADCAST NOTIFICATIONS -->
    <div id="tab-broadcast" class="section-tab">
      <div class="desk-hero">
        <div>
          <h1 class="desk-heading">Fleet Broadcast & In-App Notifications</h1>
          <p class="desk-subheading">Compose and push instant broadcast notifications directly to all active SUPERMOUSE PCs.</p>
        </div>
        <button class="btn-pill btn-lime" onclick="document.getElementById('notif-title').focus()">+ Compose Broadcast</button>
      </div>

      <!-- Compose Notification Card -->
      <div class="chart-card" style="margin-bottom:24px;">
        <h3 style="font-size:16px; font-weight:800; margin-bottom:14px; letter-spacing:-0.3px;">Post New Live Notification to All Users</h3>
        <form id="form-broadcast">
          <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap:14px; margin-bottom:14px;">
            <div class="form-group">
              <label class="form-label">Notification Title / Headline</label>
              <input type="text" id="notif-title" class="form-input" placeholder="e.g. THE SUPERMOUSE v1.01 Released!" required>
            </div>
            <div class="form-group">
              <label class="form-label">Category / Type</label>
              <select id="notif-type" class="form-select">
                <option value="UPDATE">🚀 Software Update</option>
                <option value="ANNOUNCEMENT">📢 General Announcement</option>
                <option value="FEATURE">✨ New Feature Spotlight</option>
                <option value="MAINTENANCE">⚙️ Maintenance Notice</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Audience Target</label>
              <select id="notif-target" class="form-select">
                <option value="ALL">All Active Fleet PCs (Global)</option>
                <option value="BOUND_ONLY">Bound Verified PCs Only</option>
              </select>
            </div>
          </div>

          <div class="form-group" style="margin-bottom:14px;">
            <label class="form-label">Notification Message Body</label>
            <textarea id="notif-msg" class="form-input" rows="3" placeholder="Enter message details displayed inside user cursor command windows..." required style="resize:vertical;"></textarea>
          </div>

          <div style="display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:12px; color:var(--text-sub);">Broadcast will be pushed to Firebase Firestore live collection.</span>
            <button type="submit" id="btn-send-notif" class="btn-pill btn-lime" style="padding:10px 22px; font-size:13px;">
              Publish Broadcast Notification →
            </button>
          </div>
        </form>
      </div>

      <!-- History of Sent Broadcasts -->
      <div class="table-container">
        <div style="padding:16px 20px; border-bottom:1px solid var(--line); display:flex; justify-content:space-between; align-items:center;">
          <h4 style="font-size:13px; font-weight:800; text-transform:uppercase; letter-spacing:0.5px; color:var(--text-main);">Sent Broadcasts History</h4>
          <span id="notif-count-badge" class="brand-badge">0 Broadcasts</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>Headline</th>
              <th>Category</th>
              <th>Target</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="notif-table-body">
            <tr><td colspan="6" style="text-align:center; padding:24px; color:var(--text-muted);">Loading broadcast history from Firebase...</td></tr>
          </tbody>
        </table>
      </div>
    </div>
"""

github_end_marker = '    </div>\n\n  </main>'
if 'id="tab-broadcast"' not in html:
    html = html.replace(github_end_marker, '    </div>\n' + broadcast_section + '\n  </main>')

# 4. Add JavaScript handlers for Broadcast Notifications in script section
js_broadcast_code = """
    // ==========================================
    // BROADCAST NOTIFICATIONS SYSTEM (FIREBASE)
    // ==========================================
    async function loadBroadcastHistory() {
      const tbody = document.getElementById('notif-table-body');
      const badge = document.getElementById('notif-count-badge');
      if (!tbody) return;

      try {
        const notifUrl = `${FIRESTORE_BASE}/notifications?pageSize=50`;
        const res = await fetch(notifUrl);
        if (!res.ok) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:24px; color:var(--text-muted);">No broadcasts yet or collection initialized.</td></tr>';
          return;
        }
        const data = await res.json();
        const docs = data.documents || [];
        if (badge) badge.textContent = `${docs.length} Broadcast${docs.length === 1 ? '' : 's'}`;

        if (docs.length === 0) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:24px; color:var(--text-muted);">No broadcast notifications posted yet.</td></tr>';
          return;
        }

        tbody.innerHTML = docs.map(doc => {
          const docId = doc.name.split('/').pop();
          const f = doc.fields || {};
          const title = f.title?.stringValue || 'Announcement';
          const msg = f.message?.stringValue || '';
          const type = f.type?.stringValue || 'UPDATE';
          const target = f.target?.stringValue || 'ALL';
          const dateStr = f.createdAt?.stringValue || 'Recent';

          return `
            <tr>
              <td style="font-family:var(--mono); font-size:11.5px; color:var(--text-muted);">${dateStr}</td>
              <td><strong>${escapeHtml(title)}</strong><div style="font-size:11.5px; color:var(--text-muted); margin-top:2px;">${escapeHtml(msg.substring(0, 90))}${msg.length > 90 ? '...' : ''}</div></td>
              <td><span class="status-badge badge-live">${escapeHtml(type)}</span></td>
              <td><span class="tag-origin">${escapeHtml(target)}</span></td>
              <td><span class="status-badge badge-bound">● Live Active</span></td>
              <td><button class="btn-action delete" onclick="deleteBroadcast('${docId}')">Revoke</button></td>
            </tr>
          `;
        }).join('');
      } catch (err) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:24px; color:var(--text-muted);">Ready for live broadcasts.</td></tr>';
      }
    }

    async function deleteBroadcast(docId) {
      if (!confirm('Revoke and delete this broadcast notification?')) return;
      try {
        const delUrl = `${FIRESTORE_BASE}/notifications/${encodeURIComponent(docId)}`;
        const res = await fetch(delUrl, { method: 'DELETE' });
        if (res.ok) {
          alert('Broadcast notification revoked successfully.');
          loadBroadcastHistory();
        } else {
          alert('Failed to revoke broadcast from Firebase.');
        }
      } catch (e) {
        alert('Error revoking broadcast: ' + e.message);
      }
    }

    const formBroadcast = document.getElementById('form-broadcast');
    if (formBroadcast) {
      formBroadcast.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('btn-send-notif');
        const oldText = btn.textContent;
        btn.textContent = 'Publishing to Fleet...';
        btn.disabled = true;

        const title = document.getElementById('notif-title').value.trim();
        const type = document.getElementById('notif-type').value;
        const target = document.getElementById('notif-target').value;
        const msg = document.getElementById('notif-msg').value.trim();
        const notifId = 'notif_' + Date.now();

        try {
          const putUrl = `${FIRESTORE_BASE}/notifications/${notifId}`;
          const payload = {
            fields: {
              title: { stringValue: title },
              type: { stringValue: type },
              target: { stringValue: target },
              message: { stringValue: msg },
              createdAt: { stringValue: new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' }) + ' IST' },
              status: { stringValue: 'ACTIVE' }
            }
          };

          const res = await fetch(putUrl, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });

          if (res.ok) {
            alert(`Broadcast Published Successfully to All Users!\\n\\n"${title}"`);
            formBroadcast.reset();
            loadBroadcastHistory();
          } else {
            alert('Failed to publish notification in Firebase.');
          }
        } catch (err) {
          alert('Error publishing broadcast: ' + err.message);
        } finally {
          btn.textContent = oldText;
          btn.disabled = false;
        }
      });
    }
"""

if 'loadBroadcastHistory()' not in html:
    # insert before window.addEventListener('DOMContentLoaded'
    html = html.replace("window.addEventListener('DOMContentLoaded', () => {", js_broadcast_code + "\n    window.addEventListener('DOMContentLoaded', () => {\n      loadBroadcastHistory();")

with open(path, "w", encoding="utf-8") as f:
    f.write(html)

print("SuperMouseHQ/index.html updated with complete Fleet Broadcast Notification system!")
