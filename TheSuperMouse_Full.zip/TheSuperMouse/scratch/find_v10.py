import os
import re

base_dirs = [r'D:\THESUPERMOUSE\VERSION 1.0', r'D:\THESUPERMOUSE\supermousenewnupdates', r'D:\THESUPERMOUSE\PC REALEASE BUNDLE']
extensions = ('.py', '.json', '.iss', '.ps1', '.html', '.js', '.txt', '.md', '.bat')

pattern = re.compile(r'\bv1\.0\b|version\s*1\.0\b|TheSuperMouse\s*1\.0\b|["\']1\.0["\']', re.IGNORECASE)

found = []
for b in base_dirs:
    for root, dirs, files in os.walk(b):
        if any(ign in root.lower() for ign in ['venv', '.git', '__pycache__', 'node_modules', '.gradle']):
            continue
        for f in files:
            if f.endswith(extensions):
                p = os.path.join(root, f)
                try:
                    with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                        content = fp.read()
                    matches = list(pattern.finditer(content))
                    if matches:
                        # filter out false positives if it's already 1.01
                        actual = []
                        for m in matches:
                            sub = content[max(0, m.start()-10):min(len(content), m.end()+10)]
                            if '1.01' not in sub and '1.0.1' not in sub:
                                actual.append((m.group(0), sub.strip()))
                        if actual:
                            found.append((p, actual))
                except Exception as e:
                    pass

for p, acts in found:
    print(f"FILE: {p}")
    for g, s in acts[:5]:
        print(f"   [{g}] -> ...{s}...")
