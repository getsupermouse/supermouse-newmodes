import os
import re

dirs_to_check = [
    r'D:\THESUPERMOUSE\VERSION 1.0',
    r'D:\THESUPERMOUSE\TheWebsite',
    r'D:\THESUPERMOUSE\thesupermouse-releases',
    r'D:\THESUPERMOUSE\supermousenewnupdates',
    r'D:\THESUPERMOUSE\PC REALEASE BUNDLE'
]

pattern = re.compile(r'\bv1\.0\b|version\s*1\.0\b|TheSuperMouse\s*1\.0\b|["\']1\.0["\']', re.IGNORECASE)

found = []
for d in dirs_to_check:
    for root, dirs, files in os.walk(d):
        if any(ign in root.lower() for ign in ['.git', 'node_modules', '__pycache__', 'venv', '.gradle', 'cache']):
            continue
        for f in files:
            if f.endswith(('.json', '.py', '.js', '.html', '.iss', '.ps1', '.txt', '.md', '.bat')):
                p = os.path.join(root, f)
                try:
                    with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                        content = fp.read()
                    matches = list(pattern.finditer(content))
                    actual = []
                    for m in matches:
                        sub = content[max(0, m.start()-10):min(len(content), m.end()+10)]
                        if '1.01' not in sub and '1.0.1' not in sub:
                            actual.append((m.group(0), sub.strip()))
                    if actual:
                        found.append((p, actual))
                except Exception:
                    pass

for p, acts in found:
    print(f"FILE: {p}")
    for g, s in acts[:5]:
        print(f"   [{g}] -> {s}")
