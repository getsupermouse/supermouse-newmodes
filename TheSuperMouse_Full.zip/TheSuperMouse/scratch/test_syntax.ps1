$sig = '[DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint a, uint b, IntPtr c, uint d);'
$type = Add-Type -MemberDefinition $sig -Name "PInvokeCursor" -Namespace "Win32Sys" -PassThru
$res = $type::SystemParametersInfo(0x0057, 0, [IntPtr]::Zero, 3)
Write-Host "SystemParametersInfo returned:" $res
