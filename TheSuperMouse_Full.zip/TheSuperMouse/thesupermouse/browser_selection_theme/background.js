chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "supermouse_menu",
      title: "The SuperMouse — Quick Menu",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "supermouse_snap",
      title: "Super Snap & Pin — Take Snap",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "supermouse_box",
      title: "My Box — Open Snaps",
      contexts: ["all"]
    });
  });
});

chrome.contextMenus.onClicked.addListener((info) => {
  let route = "menu";
  if (info.menuItemId === "supermouse_snap") route = "snap";
  else if (info.menuItemId === "supermouse_box") route = "box";
  fetch(`http://127.0.0.1:47291/${route}`).catch(() => {});
});

