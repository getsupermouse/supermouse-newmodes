import 'dart:io';
import 'package:flutter/material.dart';
import 'windows_cursor.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TheSuperMouseApp());
}

class TheSuperMouseApp extends StatelessWidget {
  const TheSuperMouseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'The Super Mouse',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0D0F17),
      ),
      home: const SuperMouseHome(),
    );
  }
}

class SuperMouseHome extends StatefulWidget {
  const SuperMouseHome({super.key});

  @override
  State<SuperMouseHome> createState() => _SuperMouseHomeState();
}

class _SuperMouseHomeState extends State<SuperMouseHome> with WidgetsBindingObserver {
  Offset _cursorPos = const Offset(400, 300);
  bool _insideWindow = true;
  bool _systemWideEnabled = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _toggleSystemCursor(true);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    WindowsCursorManager.restoreSystemCursor();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.detached) {
      WindowsCursorManager.restoreSystemCursor();
    }
  }

  void _toggleSystemCursor(bool enable) {
    if (enable) {
      final curFile = File('${Directory.current.path}/assets/cursor.cur');
      if (curFile.existsSync()) {
        WindowsCursorManager.applySystemCursor(curFile.path);
        setState(() => _systemWideEnabled = true);
      }
    } else {
      WindowsCursorManager.restoreSystemCursor();
      setState(() => _systemWideEnabled = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: MouseRegion(
        cursor: SystemMouseCursors.none,
        onExit: (_) => setState(() => _insideWindow = false),
        onEnter: (_) => setState(() => _insideWindow = true),
        child: Listener(
          onPointerHover: (event) => setState(() {
            _cursorPos = event.localPosition;
            _insideWindow = true;
          }),
          onPointerMove: (event) => setState(() {
            _cursorPos = event.localPosition;
            _insideWindow = true;
          }),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Center(
                child: Container(
                  padding: const EdgeInsets.all(32),
                  decoration: BoxDecoration(
                    color: const Color(0xFF161926),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF2B3347)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.5),
                        blurRadius: 30,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  width: 480,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset(
                        'assets/cursor.png',
                        width: 90,
                        height: 75,
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        'THE SUPER MOUSE',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2.5,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Active Neon Speed Cursor',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white.withValues(alpha: 0.6),
                        ),
                      ),
                      const SizedBox(height: 28),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'System-Wide Windows Cursor',
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Switch(
                            value: _systemWideEnabled,
                            activeThumbColor: const Color(0xFF9AFF00),
                            onChanged: (val) => _toggleSystemCursor(val),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _systemWideEnabled
                            ? 'Cursor is active everywhere in Windows while this app runs.'
                            : 'Cursor is active inside app window only.',
                        style: TextStyle(
                          fontSize: 12,
                          color: _systemWideEnabled
                              ? const Color(0xFF9AFF00)
                              : Colors.white.withValues(alpha: 0.4),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Render In-App Active Image Cursor
              if (_insideWindow)
                Positioned(
                  left: _cursorPos.dx - 22,
                  top: _cursorPos.dy - 18,
                  child: IgnorePointer(
                    child: Image.asset(
                      'assets/cursor.png',
                      width: 44,
                      height: 36,
                      filterQuality: FilterQuality.high,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
