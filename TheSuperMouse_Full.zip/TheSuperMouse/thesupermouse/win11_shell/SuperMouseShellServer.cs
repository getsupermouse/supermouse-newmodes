using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace SuperMouseShell
{
    [ComImport]
    [Guid("a08ce4d0-fa25-44ab-b57c-c7b1c323e0b9")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IExplorerCommand
    {
        [PreserveSig]
        int GetTitle(IntPtr psiItemArray, [MarshalAs(UnmanagedType.LPWStr)] out string ppszName);

        [PreserveSig]
        int GetIcon(IntPtr psiItemArray, [MarshalAs(UnmanagedType.LPWStr)] out string ppszIcon);

        [PreserveSig]
        int GetToolTip(IntPtr psiItemArray, [MarshalAs(UnmanagedType.LPWStr)] out string ppszInfotip);

        [PreserveSig]
        int GetCanonicalName(out Guid pguidCommandName);

        [PreserveSig]
        int GetState(IntPtr psiItemArray, [MarshalAs(UnmanagedType.Bool)] bool fOkToBeSlow, out uint pCmdState);

        [PreserveSig]
        int Invoke(IntPtr psiItemArray, IntPtr pbc);

        [PreserveSig]
        int GetFlags(out uint pFlags);

        [PreserveSig]
        int EnumSubCommands(out IntPtr ppEnum);
    }

    internal static class ShellBridge
    {
        public static readonly string ExePath;
        public static readonly string ExeDir;
        public static readonly string BaseAppDir;
        public static readonly string SuperMouseIcon;
        public static readonly string SuperPinIcon;
        public static readonly string SuperShareIcon;

        static ShellBridge()
        {
            ExePath = typeof(ShellBridge).Assembly.Location;
            ExeDir = Path.GetDirectoryName(ExePath) ?? AppDomain.CurrentDomain.BaseDirectory;
            DirectoryInfo di = Directory.GetParent(ExeDir);
            BaseAppDir = (di != null && di.Parent != null) ? di.Parent.FullName : ExeDir;

            string mouseIco = Path.Combine(ExeDir, "supermouse_cmd_v2.ico");
            SuperMouseIcon = (File.Exists(mouseIco) ? mouseIco + ",0" : ExePath + ",0");
            string pinIco = Path.Combine(ExeDir, "superpin_cmd_v2.ico");
            SuperPinIcon = (File.Exists(pinIco) ? pinIco + ",0" : SuperMouseIcon);
            string shareIco = Path.Combine(ExeDir, "supershare_cmd_v2.ico");
            SuperShareIcon = (File.Exists(shareIco) ? shareIco + ",0" : SuperMouseIcon);
        }

        public static void WarmUp()
        {
            // Force static constructor pre-computation before COM queries arrive
            string _ = SuperMouseIcon;
        }

        public static void TriggerRoute(string route, string cliFlag)
        {
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:47291/" + route);
                    req.Timeout = 700;
                    using (WebResponse resp = req.GetResponse()) { }
                    return;
                }
                catch
                {
                }

                try
                {
                    string mainPy = Path.Combine(BaseAppDir, "main_app.py");
                    if (File.Exists(mainPy))
                    {
                        ProcessStartInfo psi = new ProcessStartInfo("pythonw.exe", "\"" + mainPy + "\" " + cliFlag);
                        psi.UseShellExecute = false;
                        psi.CreateNoWindow = true;
                        Process.Start(psi);
                    }
                }
                catch
                {
                }
            });
        }
    }

    public abstract class BaseSuperMouseCmd : IExplorerCommand
    {
        protected abstract string Title { get; }
        protected abstract string IconPath { get; }
        protected abstract string ToolTipText { get; }
        protected abstract string Route { get; }
        protected abstract string CliFlag { get; }
        protected abstract Guid CanonicalGuid { get; }

        public int GetTitle(IntPtr psiItemArray, out string ppszName)
        {
            ppszName = Title;
            return 0;
        }

        public int GetIcon(IntPtr psiItemArray, out string ppszIcon)
        {
            ppszIcon = IconPath;
            return 0;
        }

        public int GetToolTip(IntPtr psiItemArray, out string ppszInfotip)
        {
            ppszInfotip = ToolTipText;
            return 0;
        }

        public int GetCanonicalName(out Guid pguidCommandName)
        {
            pguidCommandName = CanonicalGuid;
            return 0;
        }

        public int GetState(IntPtr psiItemArray, bool fOkToBeSlow, out uint pCmdState)
        {
            pCmdState = 0; // ECS_ENABLED synchronously
            return 0;
        }

        public int Invoke(IntPtr psiItemArray, IntPtr pbc)
        {
            ShellBridge.TriggerRoute(Route, CliFlag);
            return 0;
        }

        public int GetFlags(out uint pFlags)
        {
            pFlags = 0; // ECF_DEFAULT
            return 0;
        }

        public int EnumSubCommands(out IntPtr ppEnum)
        {
            ppEnum = IntPtr.Zero;
            return unchecked((int)0x80004001); // E_NOTIMPL
        }
    }

    [ComVisible(true)]
    [Guid("E1A11111-4F3A-4E8B-9C11-112233440001")]
    [ClassInterface(ClassInterfaceType.None)]
    public sealed class SuperMouseMenuCmd : BaseSuperMouseCmd
    {
        protected override string Title { get { return "The SuperMouse"; } }
        protected override string IconPath { get { return ShellBridge.SuperMouseIcon; } }
        protected override string ToolTipText { get { return "Open The SuperMouse Quick Menu"; } }
        protected override string Route { get { return "menu"; } }
        protected override string CliFlag { get { return "--menu"; } }
        protected override Guid CanonicalGuid { get { return new Guid("E1A11111-4F3A-4E8B-9C11-112233440001"); } }
    }

    [ComVisible(true)]
    [Guid("E1A11111-4F3A-4E8B-9C11-112233440002")]
    [ClassInterface(ClassInterfaceType.None)]
    public sealed class SuperPinCmd : BaseSuperMouseCmd
    {
        protected override string Title { get { return "Super Snap & Pin"; } }
        protected override string IconPath { get { return ShellBridge.SuperPinIcon; } }
        protected override string ToolTipText { get { return "Open Super Snap & Pin Hub"; } }
        protected override string Route { get { return "superpin"; } }
        protected override string CliFlag { get { return "--superpin"; } }
        protected override Guid CanonicalGuid { get { return new Guid("E1A11111-4F3A-4E8B-9C11-112233440002"); } }
    }

    [ComVisible(true)]
    [Guid("E1A11111-4F3A-4E8B-9C11-112233440003")]
    [ClassInterface(ClassInterfaceType.None)]
    public sealed class SuperShareCmd : BaseSuperMouseCmd
    {
        protected override string Title { get { return "SuperShare (SuperMouse)"; } }
        protected override string IconPath { get { return ShellBridge.SuperShareIcon; } }
        protected override string ToolTipText { get { return "Share via The SuperMouse"; } }
        protected override string Route { get { return "supershare"; } }
        protected override string CliFlag { get { return "--supershare"; } }
        protected override Guid CanonicalGuid { get { return new Guid("E1A11111-4F3A-4E8B-9C11-112233440003"); } }
    }

    internal static class Program
    {
        [DllImport("ole32.dll")]
        private static extern int CoResumeClassObjects();

        [STAThread]
        private static void Main(string[] args)
        {
            ShellBridge.WarmUp();
            RegistrationServices reg = new RegistrationServices();
            int c1 = reg.RegisterTypeForComClients(typeof(SuperMouseMenuCmd), RegistrationClassContext.LocalServer, RegistrationConnectionType.MultipleUse | RegistrationConnectionType.Suspended);
            int c2 = reg.RegisterTypeForComClients(typeof(SuperPinCmd), RegistrationClassContext.LocalServer, RegistrationConnectionType.MultipleUse | RegistrationConnectionType.Suspended);
            int c3 = reg.RegisterTypeForComClients(typeof(SuperShareCmd), RegistrationClassContext.LocalServer, RegistrationConnectionType.MultipleUse | RegistrationConnectionType.Suspended);

            CoResumeClassObjects();

            EventWaitHandle shutdownEvt = new EventWaitHandle(false, EventResetMode.ManualReset, "SuperMouse_ShellHost_Shutdown");
            using (System.Windows.Forms.Timer poll = new System.Windows.Forms.Timer())
            {
                poll.Interval = 2000;
                poll.Tick += (s, e) =>
                {
                    if (shutdownEvt.WaitOne(0))
                    {
                        poll.Stop();
                        Application.ExitThread();
                    }
                };
                poll.Start();
                Application.Run();
            }

            try
            {
                reg.UnregisterTypeForComClients(c1);
                reg.UnregisterTypeForComClients(c2);
                reg.UnregisterTypeForComClients(c3);
                shutdownEvt.Dispose();
            }
            catch { }
        }
    }
}
