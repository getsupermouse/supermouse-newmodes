# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - THE SUPER PIN & MY BOX STUDIO
===============================================
Matched 100% to SuperMouseHUD (#040405 OLED matte black, vector Display Bold
typography, circular #101010 close button, boxless Lucide outline rows):
  - SuperClipboardWindow ('THE SUPER PIN'): 4 clean tools (Take Snap, Text Extractor, Store Text, My Box)
  - _SnipOverlay & _SnipResultWindow: Snipping Tool dim + crosshair box -> 4 actions (Re-Take, Copy Image, Save Image, Put in Box)
  - Put in Box: Flies captured image itself into the right screen edge, then pops
    'GOT THE BOX' out from inside the right edge for 3s -> clicking opens MY BOX.
  - MyBoxWindow ('MY BOX'): Pure black showcase window with dynamic real-time search bar
    and ChatGPT-style date grouping (Today, Yesterday, Nov 10, 2026...) pulling images cleanly
    from internal storage without exposing raw folder UI.
"""

import io
import os
import json
import math
import wave
import struct
import random
import ctypes
from datetime import datetime, timedelta

try:
    import winsound
except Exception:
    winsound = None

_ASMR_TICK_WAV = None


def _get_asmr_tick_wav():
    global _ASMR_TICK_WAV
    if _ASMR_TICK_WAV is not None:
        return _ASMR_TICK_WAV
    try:
        sr = 22050
        dur = 0.022
        n = int(sr * dur)
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sr)
            frames = bytearray()
            for i in range(n):
                t = i / float(sr)
                env = math.exp(-t * 175.0) * min(1.0, i / 12.0)
                freq = 210.0 - 110.0 * (t / dur)
                val = math.sin(2.0 * math.pi * freq * t) + 0.35 * math.sin(2.0 * math.pi * 520.0 * t)
                sample = int(max(-32767, min(32767, val * env * 4200.0)))
                frames.extend(struct.pack("<h", sample))
            wf.writeframes(bytes(frames))
        _ASMR_TICK_WAV = buf.getvalue()
    except Exception:
        _ASMR_TICK_WAV = b""
    return _ASMR_TICK_WAV


def _play_asmr_tick():
    if winsound is None:
        return
    wav = _get_asmr_tick_wav()
    if wav:
        try:
            winsound.PlaySound(wav, winsound.SND_MEMORY | winsound.SND_ASYNC | winsound.SND_NOSTOP)
        except Exception:
            pass

from PySide6.QtSvg import QSvgRenderer
from PySide6.QtCore import (
    Qt, QByteArray, QBuffer, QIODevice, QPoint, QPointF, QRect, QRectF, QSize, QTimer, Signal,
    QPropertyAnimation, QParallelAnimationGroup, QEasingCurve
)
from PySide6.QtGui import (
    QPainter, QPainterPath, QColor, QPen, QBrush,
    QLinearGradient, QPixmap, QCursor, QFont, QFontMetrics, QImage, QIcon
)
from PySide6.QtWidgets import (
    QApplication, QWidget, QFrame, QLabel, QHBoxLayout, QVBoxLayout, QPushButton,
    QScrollArea, QGridLayout, QLineEdit, QDialog, QSlider
)
from ui_theme import (
    COMMON_ICONS,
    SLIM_SCROLLBAR_QSS,
    CleanHeaderIconButton,
    CleanBackButton,
    CleanCloseButton,
    render_common_icon,
    native_dpr,
    format_count_label,
)


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BOX_DIR = os.path.join(BASE_DIR, "thesupermouse", "superclipboard_box")
META_FILE = os.path.join(BOX_DIR, "snaps_meta.json")


def get_desktop_dir():
    """Return actual Windows Desktop path (SHGetFolderPathW CSIDL_DESKTOPDIRECTORY)."""
    try:
        buf = ctypes.create_unicode_buffer(260)
        if ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf) == 0 and buf.value:
            if os.path.isdir(buf.value):
                return buf.value
    except Exception:
        pass
    fallback = os.path.join(os.path.expanduser("~"), "Desktop")
    os.makedirs(fallback, exist_ok=True)
    return fallback


def ensure_box_dir():
    os.makedirs(BOX_DIR, exist_ok=True)
    return BOX_DIR


def _load_snap_metadata():
    if not os.path.exists(META_FILE):
        return {}
    try:
        with open(META_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_snap_metadata(meta: dict):
    ensure_box_dir()
    try:
        with open(META_FILE, "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def _logical_snap_name(dt: datetime, fp: str) -> str:
    h = dt.hour
    if 5 <= h < 9:
        vibe = "Dawn"
    elif 9 <= h < 12:
        vibe = "Morning"
    elif 12 <= h < 16:
        vibe = "Midday"
    elif 16 <= h < 20:
        vibe = "Evening"
    elif 20 <= h < 24:
        vibe = "Night"
    else:
        vibe = "Midnight"

    shape = "Snap"
    try:
        img = QImage(fp)
        if not img.isNull() and img.height() > 0:
            ratio = img.width() / float(img.height())
            if img.width() < 280 and img.height() < 280:
                shape = "Clip"
            elif ratio >= 1.65:
                shape = "Wide Frame"
            elif ratio >= 1.15:
                shape = "Landscape"
            elif ratio <= 0.78:
                shape = "Portrait"
            else:
                shape = "Square Shot"
    except Exception:
        pass
    return f"{vibe} {shape}"


def _next_seq_from_meta(meta: dict) -> int:
    seq = int(meta.get("__seq__", 0) or 0)
    used_max = max(
        (int(v.get("number", 0)) for k, v in meta.items() if k != "__seq__" and isinstance(v, dict)),
        default=0,
    )
    return max(seq, used_max) + 1


def next_snap_number() -> int:
    meta = _load_snap_metadata()
    if "__seq__" not in meta and os.path.isdir(BOX_DIR):
        list_box_entries()
        meta = _load_snap_metadata()
    return _next_seq_from_meta(meta)


def rename_snap_meta(fp: str, new_name: str):
    key = os.path.basename(fp)
    clean = (new_name or "").strip()[:48]
    if not clean:
        return
    meta = _load_snap_metadata()
    entry = meta.get(key, {})
    if not entry.get("number"):
        seq = _next_seq_from_meta(meta)
        entry["number"] = seq
        meta["__seq__"] = max(int(meta.get("__seq__", 0) or 0), seq)
    entry["name"] = clean
    meta[key] = entry
    _save_snap_metadata(meta)


def save_custom_snap_meta(fp: str, snap_num: int, snap_name: str):
    key = os.path.basename(fp)
    meta = _load_snap_metadata()
    clean = (snap_name or "").strip()[:48] or _logical_snap_name(datetime.now(), fp)
    num = int(snap_num)
    meta[key] = {"number": num, "name": clean}
    meta["__seq__"] = max(int(meta.get("__seq__", 0) or 0), num)
    _save_snap_metadata(meta)


def delete_snap_meta(fp: str):
    key = os.path.basename(fp)
    meta = _load_snap_metadata()
    if key in meta:
        meta.pop(key, None)
        _save_snap_metadata(meta)


def list_box_entries():
    """Fetch stored snap image metadata cleanly sorted newest-first in sequential order (#1, #2, #3...)."""
    if not os.path.isdir(BOX_DIR):
        return []
    meta = _load_snap_metadata()
    meta_dirty = False

    # Collect image files sorted oldest -> newest so first sequential migration assigns #1, #2... chronologically
    files = []
    for fn in os.listdir(BOX_DIR):
        if fn.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".webp")):
            fp = os.path.join(BOX_DIR, fn)
            try:
                mtime = os.path.getmtime(fp)
            except Exception:
                mtime = 0.0
            files.append((mtime, fn, fp))
    files.sort(key=lambda x: x[0])

    # One-time migration if legacy random >999 numbers exist before sequential mode
    if "__seq__" not in meta:
        seq = 0
        for mtime, fn, fp in files:
            seq += 1
            dt = datetime.fromtimestamp(mtime)
            old_rec = meta.get(fn) if isinstance(meta.get(fn), dict) else {}
            meta[fn] = {
                "number": seq,
                "name": str(old_rec.get("name") or _logical_snap_name(dt, fp)),
            }
        meta["__seq__"] = seq
        meta_dirty = True

    entries = []
    for mtime, fn, fp in files:
        dt = datetime.fromtimestamp(mtime)
        rec = meta.get(fn)
        if not isinstance(rec, dict) or not rec.get("number") or not rec.get("name"):
            seq = _next_seq_from_meta(meta)
            rec = {
                "number": seq,
                "name": _logical_snap_name(dt, fp),
            }
            meta[fn] = rec
            meta["__seq__"] = max(int(meta.get("__seq__", 0) or 0), seq)
            meta_dirty = True
        entries.append({
            "path": fp,
            "filename": fn,
            "mtime": mtime,
            "dt": dt,
            "snap_num": int(rec["number"]),
            "snap_name": str(rec["name"]),
        })
    if meta_dirty:
        _save_snap_metadata(meta)
    entries.sort(key=lambda x: x["mtime"], reverse=True)
    return entries


def count_box_items():
    return len(list_box_entries())


def copy_pixmap_to_clipboard(pix, hwnd=None):
    """Copy a QPixmap cleanly onto Windows system clipboard (Qt + Win32 CF_DIB retries)."""
    if not pix or pix.isNull():
        return False
    img = pix.toImage()
    cb = QApplication.clipboard()
    cb.setPixmap(pix)
    cb.setImage(img)
    QApplication.processEvents()
    if not cb.image().isNull():
        return True

    try:
        import time
        ba = QByteArray()
        buf = QBuffer(ba)
        buf.open(QIODevice.WriteOnly)
        img.convertToFormat(QImage.Format_RGB888).save(buf, "BMP")
        buf.close()
        dib_bytes = bytes(ba.data())[14:]
        if dib_bytes:
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
            kernel32.GlobalAlloc.restype = ctypes.c_void_p
            kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
            kernel32.GlobalLock.restype = ctypes.c_void_p
            kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
            user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
            user32.SetClipboardData.restype = ctypes.c_void_p

            for _ in range(5):
                if user32.OpenClipboard(hwnd):
                    try:
                        user32.EmptyClipboard()
                        hmem = kernel32.GlobalAlloc(0x0002, len(dib_bytes))
                        if hmem:
                            ptr = kernel32.GlobalLock(hmem)
                            if ptr:
                                ctypes.memmove(ptr, dib_bytes, len(dib_bytes))
                                kernel32.GlobalUnlock(hmem)
                                user32.SetClipboardData(8, hmem)
                                return True
                    finally:
                        user32.CloseClipboard()
                time.sleep(0.015)
    except Exception:
        pass
    return False


# Shared Common Lucide 24x24 Outline Vector Icons (100% Unified Across All Windows)
_LUCIDE_PIN_ICONS = {
    **COMMON_ICONS,
    "arrow_left_fill": COMMON_ICONS["back"],
    "home_fill": COMMON_ICONS["home"],
    "grid_fill": COMMON_ICONS["grid"],
    "oneline_fill": COMMON_ICONS["oneline"],
    "scissors_fill": COMMON_ICONS["take_snap"],
    "search_fill": COMMON_ICONS["search"],
    "pencil_fill": COMMON_ICONS["pencil"],
    "copy_fill": COMMON_ICONS["copy"],
    "trash_fill": COMMON_ICONS["trash"],
    "supershare_fill": COMMON_ICONS["supershare"],
    "close_fill": COMMON_ICONS["close"],
    "box_fill": COMMON_ICONS["my_box"],
}


def _native_dpr(widget=None):
    return native_dpr(widget)


def _render_lucide_pix(key, color_hex, size_px=16, dpr=None):
    tpl = _LUCIDE_PIN_ICONS.get(key) or _LUCIDE_PIN_ICONS["copy"]
    return render_common_icon(tpl, color_hex, size_px=size_px, dpr=dpr)


def _draw_crisp_text(p, rect, centered, font, color, text):
    """Fill glyph vector paths cleanly so Windows ClearType never drops pixels on OLED dark."""
    f = QFont(font)
    f.setHintingPreference(QFont.PreferNoHinting)
    fm = QFontMetrics(f)
    tx = (rect.center().x() - fm.horizontalAdvance(text) * 0.5) if centered else float(rect.left())
    ty = rect.center().y() + (fm.ascent() - fm.descent()) * 0.5
    tp = QPainterPath()
    tp.addText(tx, ty, f, text)
    p.fillPath(tp, color)


def _draw_vector_brand(p, bx, by_c, logo_pix, word1, word2, font_pt=11.0):
    """Render razor-sharp QPainterPath vector brand matching SuperMouseHUD."""
    if logo_pix and not logo_pix.isNull():
        dpr = max(1.0, float(logo_pix.devicePixelRatio() or 1.0))
        lw = logo_pix.width() / dpr
        lh = logo_pix.height() / dpr
        p.drawPixmap(int(round(bx)), int(round(by_c - lh / 2.0)), logo_pix)
        bx += lw + 8.0

    f_logo = QFont("Segoe UI Variable")
    f_logo.setStyleName("Display Bold")
    f_logo.setPointSizeF(font_pt)
    f_logo.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
    f_logo.setHintingPreference(QFont.PreferNoHinting)

    probe = QPainterPath()
    probe.addText(0.0, 0.0, f_logo, f"{word1} {word2}")
    br = probe.boundingRect()
    baseline_y = by_c - (br.top() + br.height() * 0.5)

    p1 = QPainterPath()
    p1.addText(bx, baseline_y, f_logo, word1)
    p.fillPath(p1, QColor("#FFFFFF"))

    w1 = p1.boundingRect().width()
    smx = bx + w1 + 5.5
    p2 = QPainterPath()
    p2.addText(smx, baseline_y, f_logo, word2)
    b2 = p2.boundingRect()
    g_sm = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
    g_sm.setColorAt(0.0, QColor("#FFFF00"))
    g_sm.setColorAt(1.0, QColor("#00FF85"))
    p.fillPath(p2, g_sm)


class _StatusPopup(QFrame):
    """Pure #050505 Obsidian popup notification matching HUD style."""

    def __init__(self, parent=None):
        super().__init__(None, Qt.ToolTip | Qt.FramelessWindowHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setFixedSize(292, 68)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 10, 14, 10)
        lay.setSpacing(11)

        self.ico_lbl = QLabel(self)
        self.ico_lbl.setFixedSize(36, 36)
        self.ico_lbl.setAlignment(Qt.AlignCenter)
        self.ico_lbl.setStyleSheet(
            "background-color: #0E0E0E; border: 1px solid rgba(163, 230, 53, 0.55); border-radius: 18px;"
        )
        lay.addWidget(self.ico_lbl)

        col = QVBoxLayout()
        col.setSpacing(3)
        col.setAlignment(Qt.AlignVCenter)

        self.lbl_title = QLabel("TEXT EXTRACTOR", self)
        self.lbl_title.setStyleSheet(
            "color: #FFFFFF; font-size: 11.5px; font-weight: 700; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; background: transparent;"
        )
        col.addWidget(self.lbl_title)

        b_row = QHBoxLayout()
        b_row.setContentsMargins(0, 0, 0, 0)
        self.lbl_badge = QLabel("COMING SOON", self)
        self.lbl_badge.setFixedHeight(17)
        self.lbl_badge.setAlignment(Qt.AlignCenter)
        self.lbl_badge.setStyleSheet(
            "color: #a3e635; background-color: #121C10; "
            "border: 1px solid rgba(163, 230, 53, 0.50); border-radius: 5px; "
            "font-size: 8.5px; font-weight: 700; letter-spacing: 0.7px; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; padding: 0px 7px;"
        )
        b_row.addWidget(self.lbl_badge)
        b_row.addStretch()
        col.addLayout(b_row)
        lay.addLayout(col, stretch=1)

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.close)

    def mousePressEvent(self, e):
        self._timer.stop()
        self.close()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        path = QPainterPath()
        path.addRoundedRect(rect, 12.0, 12.0)
        p.fillPath(path, QColor(5, 5, 5, 252))
        p.setPen(QPen(QColor(255, 255, 255, 32), 1.0))
        p.drawPath(path)
        p.end()

    def show_message(self, title, svg_tpl, center_pos, badge_text="COMING SOON", duration_ms=2100):
        self.lbl_title.setText(title)
        self.lbl_badge.setText(badge_text)
        svg_raw = svg_tpl.replace("{col}", "#a3e635")
        pix = QPixmap(18, 18)
        pix.fill(Qt.transparent)
        p = QPainter(pix)
        QSvgRenderer(QByteArray(svg_raw.encode("utf-8"))).render(p)
        p.end()
        self.ico_lbl.setPixmap(pix)

        x = center_pos.x() - self.width() // 2
        y = center_pos.y() - self.height() // 2
        screen = QApplication.screenAt(center_pos) or QApplication.primaryScreen()
        if screen:
            ag = screen.availableGeometry()
            x = max(ag.left() + 10, min(ag.right() - self.width() - 10, x))
            y = max(ag.top() + 10, min(ag.bottom() - self.height() - 10, y))
        self.move(x, y)
        self.show()
        self.raise_()
        self._timer.start(duration_ms)


class GotTheBoxEdgePopup(QWidget):
    """
    Minimalist iOS Dynamic-Island style capsule emerging smoothly from bottom-right corner:
      - Sleek 216x52 pill with 2x crisp thumbnail, clean 2-line iOS label & subtle chevron
      - Holds for 3s with smooth OutBack spring slide-in, then glides cleanly back inside
    """

    def __init__(self, on_open_box=None, parent=None):
        super().__init__(
            parent,
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint,
        )
        self.on_open_box = on_open_box
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setFixedSize(216, 52)
        self.setCursor(Qt.PointingHandCursor)

        self._thumb_pix = None
        self._screen_geo = None
        self._snap_title = ""
        self._hold_timer = QTimer(self)
        self._hold_timer.setSingleShot(True)
        self._hold_timer.timeout.connect(self.slide_back_inside)

    def show_from_right(self, y_center, saved_path, snap_pix=None, screen=None, snap_label=""):
        self._hold_timer.stop()
        if hasattr(self, "_anim") and self._anim.state() == QParallelAnimationGroup.Running:
            self._anim.stop()

        self._snap_title = str(snap_label or "").strip()
        if snap_pix and not snap_pix.isNull():
            sc = snap_pix.scaled(72, 72, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            sc.setDevicePixelRatio(2.0)
            self._thumb_pix = sc
        else:
            self._thumb_pix = None

        scr = screen or QApplication.primaryScreen()
        full = scr.geometry()
        avail = scr.availableGeometry()
        self._screen_geo = full

        w, h = self.width(), self.height()
        target_y = max(avail.top() + 18, avail.bottom() - h - 22)

        start_geom = QRect(full.right() + 16, target_y, w, h)
        target_geom = QRect(full.right() - w - 16, target_y, w, h)

        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(360)
        ag.setStartValue(start_geom)
        ag.setEndValue(target_geom)
        ag.setEasingCurve(QEasingCurve.OutBack)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(240)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        self._anim = QParallelAnimationGroup(self)
        self._anim.addAnimation(ag)
        self._anim.addAnimation(af)
        self._anim.finished.connect(lambda: self._hold_timer.start(3000))
        self._anim.start()

    def slide_back_inside(self):
        if not self.isVisible():
            return
        if hasattr(self, "_anim") and self._anim.state() == QParallelAnimationGroup.Running:
            self._anim.stop()

        full = self._screen_geo or QApplication.primaryScreen().geometry()
        curr = self.geometry()
        end_geom = QRect(full.right() + 18, curr.y(), curr.width(), curr.height())

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(280)
        ag.setStartValue(curr)
        ag.setEndValue(end_geom)
        ag.setEasingCurve(QEasingCurve.InCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(240)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.InCubic)

        self._anim = QParallelAnimationGroup(self)
        self._anim.addAnimation(ag)
        self._anim.addAnimation(af)
        self._anim.finished.connect(self.hide)
        self._anim.start()

    def mousePressEvent(self, e):
        self._hold_timer.stop()
        if e.button() == Qt.LeftButton and self.on_open_box:
            self.hide()
            self.on_open_box()
            return
        self.slide_back_inside()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        card = QPainterPath()
        card.addRoundedRect(rect, h * 0.5, h * 0.5)

        p.fillPath(card, QColor(9, 10, 12, 246))
        p.setPen(QPen(QColor(255, 255, 255, 36), 1.0))
        p.drawPath(card)

        thumb_rect = QRectF(9.0, (h - 34.0) * 0.5, 34.0, 34.0)
        tp = QPainterPath()
        tp.addRoundedRect(thumb_rect, 17.0, 17.0)
        p.fillPath(tp, QColor(18, 20, 22, 255))
        if self._thumb_pix and not self._thumb_pix.isNull():
            p.save()
            p.setClipPath(tp)
            tx = int(round(thumb_rect.center().x() - self._thumb_pix.width() / (2.0 * self._thumb_pix.devicePixelRatio())))
            ty = int(round(thumb_rect.center().y() - self._thumb_pix.height() / (2.0 * self._thumb_pix.devicePixelRatio())))
            p.drawPixmap(tx, ty, self._thumb_pix)
            p.restore()
        else:
            p.drawPixmap(int(thumb_rect.x() + 9), int(thumb_rect.y() + 9), _render_lucide_pix("my_box", "#a3e635", 16, dpr=2.0))
        p.setPen(QPen(QColor(163, 230, 53, 120), 1.0))
        p.drawPath(tp)

        # Simple 2-line iOS pill text
        f1 = QFont("Segoe UI Variable")
        f1.setStyleName("Text Bold")
        f1.setPointSizeF(9.6)
        f1.setStyleStrategy(QFont.PreferAntialias | QFont.NoSubpixelAntialias)
        p.setFont(f1)
        p.setPen(QColor("#FFFFFF"))
        p.drawText(QRect(52, 8, int(w - 78), 18), Qt.AlignVCenter | Qt.AlignLeft, "Got the Box")

        short_sub = self._snap_title.split("·")[0].strip() if self._snap_title else "My Box"
        sub = f"{short_sub} · Saved" if short_sub else "Saved"
        f2 = QFont("Segoe UI Variable")
        f2.setStyleName("Text Semibold")
        f2.setPointSizeF(7.8)
        f2.setStyleStrategy(QFont.PreferAntialias | QFont.NoSubpixelAntialias)
        p.setFont(f2)
        p.setPen(QColor(163, 230, 53, 220))
        p.drawText(QRect(52, 26, int(w - 78), 16), Qt.AlignVCenter | Qt.AlignLeft, sub)

        # Subtle iOS right chevron
        chev_svg = (
            '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" '
            'fill="none" stroke="#9CA3AF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">'
            '<path d="m9 18 6-6-6-6"/></svg>'
        )
        QSvgRenderer(QByteArray(chev_svg.encode("utf-8"))).render(p, QRectF(w - 22.0, (h - 12.0) * 0.5, 12.0, 12.0))
        p.end()


class _FlyingSnapImage(QWidget):
    """Always flies the snapped image smoothly into the bottom-right corner above taskbar."""

    def __init__(self, parent=None):
        super().__init__(
            parent,
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint,
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self._pix = None

    def fly_into_right_edge(self, snap_pix, start_global_rect, screen, on_fully_inside):
        self._pix = snap_pix
        scr = screen or QApplication.primaryScreen()
        full = scr.geometry()
        avail = scr.availableGeometry()

        sw = max(72, start_global_rect.width())
        sh = max(48, start_global_rect.height())
        start_rect = QRect(start_global_rect.x(), start_global_rect.y(), sw, sh)

        aspect = sw / max(1.0, float(sh))
        end_w = max(72, min(116, int(sw * 0.35)))
        end_h = max(44, min(86, int(end_w / max(0.4, aspect))))
        # Consistently dock in bottom-right corner just above taskbar slightly upwards
        end_y = max(avail.top() + 24, avail.bottom() - end_h - 34)
        end_rect = QRect(full.right() + 22, end_y, end_w, end_h)

        self.setGeometry(start_rect)
        self.setWindowOpacity(1.0)
        self.show()
        self.raise_()

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(420)
        ag.setStartValue(start_rect)
        ag.setEndValue(end_rect)
        ag.setEasingCurve(QEasingCurve.InOutCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(410)
        af.setStartValue(1.0)
        af.setEndValue(0.88)
        af.setEasingCurve(QEasingCurve.InQuad)

        self._anim = QParallelAnimationGroup(self)
        self._anim.addAnimation(ag)
        self._anim.addAnimation(af)

        def _done():
            self.hide()
            if on_fully_inside:
                on_fully_inside(end_y + end_h // 2)

        self._anim.finished.connect(_done)
        self._anim.start()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)
        path = QPainterPath()
        path.addRoundedRect(rect, 9.0, 9.0)

        p.save()
        p.setClipPath(path)
        if self._pix and not self._pix.isNull():
            p.drawPixmap(rect.toRect(), self._pix)
        p.restore()

        p.setPen(QPen(QColor("#a3e635"), 1.6))
        p.drawPath(path)
        p.end()


class _ActionPillButton(QWidget):
    """Minimalist iOS action pill: sleek matte obsidian secondary or signature lime CTA."""
    clicked = Signal()

    def __init__(self, label, svg_tpl, primary=False, compact=False, parent=None):
        super().__init__(parent)
        self.label = label
        self.svg_tpl = svg_tpl
        self.primary = primary
        self.compact = compact
        self.setFixedHeight(28 if compact else 32)
        self.setCursor(Qt.PointingHandCursor)

        f = QFont("Segoe UI Variable")
        f.setStyleName("Display Bold" if primary else "Text Semibold")
        f.setPointSizeF(8.3 if compact else 8.6)
        tw = QFontMetrics(f).horizontalAdvance(label)
        self.setFixedWidth(max(72 if compact else 82, tw + (40 if compact else 44)))

        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def _step(self):
        active = False
        if abs(self._target - self._h) >= 0.008:
            self._h += (self._target - self._h) * 0.25
            active = True
        else:
            self._h = self._target
        if self._press > 0.01:
            self._press *= 0.80
            active = True
        else:
            self._press = 0.0
        self.update()
        if not active:
            self._timer.stop()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            self._press = 1.0
            if not self._timer.isActive():
                self._timer.start()
            self.clicked.emit()
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        hv = self._h
        sc = 1.0 - self._press * 0.04

        p.save()
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        path = QPainterPath()
        path.addRoundedRect(rect, 8.5, 8.5)

        if self.primary:
            fill_c = QColor(int(163 + hv * 25), int(230 + hv * 18), int(53 + hv * 12), 255)
            p.fillPath(path, fill_c)
            col_hex = "#070907"
            txt_col = QColor("#070907")
        else:
            bg = QColor(int(18 + hv * 12), int(19 + hv * 12), int(23 + hv * 13), 255)
            p.fillPath(path, bg)
            p.setPen(QPen(QColor(255, 255, 255, int(22 + hv * 36)), 1.0))
            p.drawPath(path)
            col_hex = "#FFFFFF" if hv > 0.35 else "#D4D4D8"
            txt_col = QColor("#FFFFFF") if hv > 0.35 else QColor("#E4E4E7")

        isz = 13.5 if self.compact else 14.0
        px = 10.0 if self.compact else 11.0
        pix = render_common_icon(self.svg_tpl, col_hex, int(round(isz)), dpr=native_dpr(self))
        p.drawPixmap(int(round(px)), int(round((h - isz) * 0.5)), pix)

        f = QFont("Segoe UI Variable")
        f.setStyleName("Display Bold" if self.primary else "Text Semibold")
        f.setPointSizeF(8.3 if self.compact else 8.6)
        _draw_crisp_text(p, QRectF(px + isz + 6.0, 0.0, w - (px + isz + 14.0), h), False, f, txt_col, self.label)
        p.restore()
        p.end()


class _ToolIconBtn(QWidget):
    """
    Minimalist borderless iOS/Win11 icon button (invisible at rest):
      - Renders crisp filled or bold vector icon at clean size
      - Optional 'color_dot' bar shows loaded ink/highlighter color without cluttering bar
      - Clicking active tool / right-click / dropdown cue emits 'configure_requested'
    """
    clicked = Signal()
    configure_requested = Signal()

    def __init__(
        self,
        icon_key,
        tip_text="",
        coming_soon=False,
        accent="#a3e635",
        size_px=34,
        icon_px=17,
        configurable=False,
        color_dot=None,
        parent=None,
    ):
        super().__init__(parent)
        self.icon_key = icon_key
        self.coming_soon = coming_soon
        self.accent = accent
        self.icon_px = icon_px
        self.configurable = configurable
        self.color_dot = color_dot
        self.active = False
        self.enabled_btn = True
        self.setToolTip(tip_text)
        self.setFixedSize(size_px, size_px)
        self.setCursor(Qt.PointingHandCursor)
        self._h = 0.0
        self._t = 0.0
        self._press = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def set_color_dot(self, hex_col: str | None):
        self.color_dot = hex_col
        self.update()

    def set_active(self, flag: bool):
        self.active = bool(flag)
        self.update()

    def set_enabled_btn(self, flag: bool):
        self.enabled_btn = bool(flag)
        self.setCursor(Qt.PointingHandCursor if flag else Qt.ArrowCursor)
        self.update()

    def _step(self):
        act = False
        if abs(self._t - self._h) >= 0.008:
            self._h += (self._t - self._h) * 0.25
            act = True
        else:
            self._h = self._t
        if self._press > 0.01:
            self._press *= 0.80
            act = True
        else:
            self._press = 0.0
        self.update()
        if not act:
            self._timer.stop()

    def enterEvent(self, e):
        if self.enabled_btn:
            self._t = 1.0
            if not self._timer.isActive():
                self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._t = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if not self.enabled_btn:
            return
        if e.button() == Qt.RightButton and self.configurable:
            _play_asmr_tick()
            self.configure_requested.emit()
            e.accept()
            return
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            self._press = 1.0
            if not self._timer.isActive():
                self._timer.start()
            was_active = self.active
            self.clicked.emit()
            if was_active and self.configurable:
                self.configure_requested.emit()
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        hv = 1.0 if self.active else self._h
        sc = 1.0 - self._press * 0.06
        isz = self.icon_px

        p.save()
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        if not self.enabled_btn:
            pix = _render_lucide_pix(self.icon_key, "#464952", isz, dpr=native_dpr(self))
            p.drawPixmap(int(round((w - isz) * 0.5)), int(round((h - isz) * 0.5)), pix)
            p.restore()
            p.end()
            return

        path = QPainterPath()
        path.addRoundedRect(QRectF(1.0, 1.0, w - 2.0, h - 2.0), 8.5, 8.5)
        if self.active:
            p.fillPath(path, QColor(255, 255, 255, 26))
        elif hv > 0.02:
            p.fillPath(path, QColor(255, 255, 255, int(15 * hv)))

        ico_col = "#FFFFFF" if self.active else ("#FFFFFF" if hv > 0.35 else ("#9CA3AF" if self.coming_soon else "#C8CCD4"))
        iy_shift = -2.0 if self.color_dot else 0.0
        pix = _render_lucide_pix(self.icon_key, ico_col, isz, dpr=native_dpr(self))
        p.drawPixmap(int(round((w - isz) * 0.5)), int(round((h - isz) * 0.5 + iy_shift)), pix)

        # Clean Windows-11 Snipping Tool ink color indicator pill beneath configurable icon
        if self.color_dot:
            dot_col = QColor(self.color_dot)
            dp = QPainterPath()
            bar_w = 12.0 if self.active else 9.0
            dp.addRoundedRect(QRectF((w - bar_w) * 0.5, h - 6.0, bar_w, 2.5), 1.25, 1.25)
            p.fillPath(dp, dot_col)
            if self.configurable and self.active:
                # Subtle micro caret bottom-right indicating click-again opens colors & size flyout
                p.setBrush(QColor("#A1A7B3"))
                p.setPen(Qt.NoPen)
                tri = QPainterPath(QPointF(w - 6.5, h - 6.2))
                tri.lineTo(w - 3.3, h - 6.2)
                tri.lineTo(w - 4.9, h - 4.0)
                tri.closeSubpath()
                p.fillPath(tri, QColor(255, 255, 255, 165))
        p.restore()
        p.end()


class _ColorSwatch(QWidget):
    """Big, clear iOS circular color swatch (24x24) with subtle ring highlight."""
    selected = Signal(str)

    def __init__(self, hex_col, parent=None):
        super().__init__(parent)
        self.hex_col = hex_col
        self.active = False
        self.setFixedSize(24, 24)
        self.setCursor(Qt.PointingHandCursor)

    def set_active(self, flag: bool):
        self.active = bool(flag)
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            self.selected.emit(self.hex_col)
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        if self.active:
            p.setPen(QPen(QColor("#FFFFFF"), 1.8))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QRectF(1.5, 1.5, w - 3.0, h - 3.0))
        p.setBrush(QColor(self.hex_col))
        p.setPen(QPen(QColor(255, 255, 255, 58), 0.9))
        p.drawEllipse(QRectF(4.2, 4.2, w - 8.4, h - 8.4))
        p.end()


class _ToolConfigFlyout(QFrame):
    """
    Windows 11 Snipping Tool / iOS Markup Floating Popover:
      - Revealed cleanly on demand right under Pen, Highlighter, Type, Arrow, Shape, or Eraser
      - Houses 12 curated color circles (6x2 grid), live thickness preview slider, & Rect/Circle picker
    """
    color_picked = Signal(str)
    size_changed = Signal(int)
    shape_picked = Signal(str)

    def __init__(self, palette_colors, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setFixedWidth(214)
        self.setStyleSheet(
            "QFrame { background-color: rgba(12, 13, 16, 250); "
            "border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 14px; }"
        )

        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(10)

        # Shape picker strip (only visible for Shape tool)
        self.shape_row = QWidget(self)
        self.shape_row.setStyleSheet("background: transparent; border: none;")
        sh_l = QHBoxLayout(self.shape_row)
        sh_l.setContentsMargins(0, 0, 0, 2)
        sh_l.setSpacing(6)
        self.btn_rect = _ToolIconBtn("square", "Rectangle", size_px=32, icon_px=15, parent=self.shape_row)
        self.btn_circle = _ToolIconBtn("circle", "Circle", size_px=32, icon_px=15, parent=self.shape_row)
        self.btn_rect.set_active(True)
        self.btn_rect.clicked.connect(lambda: self.shape_picked.emit("rect"))
        self.btn_circle.clicked.connect(lambda: self.shape_picked.emit("ellipse"))
        sh_lbl = QLabel("SHAPE", self.shape_row)
        sh_lbl.setStyleSheet(
            "color: #71717A; font-size: 9px; font-weight: 700; letter-spacing: 0.9px; "
            "border: none; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        sh_l.addWidget(sh_lbl)
        sh_l.addStretch(1)
        sh_l.addWidget(self.btn_rect)
        sh_l.addWidget(self.btn_circle)
        self.shape_row.setVisible(False)
        lay.addWidget(self.shape_row)

        # 12 Colors 6x2 Grid
        self.colors_wrap = QWidget(self)
        self.colors_wrap.setStyleSheet("background: transparent; border: none;")
        cw_l = QVBoxLayout(self.colors_wrap)
        cw_l.setContentsMargins(0, 0, 0, 0)
        cw_l.setSpacing(6)
        hdr_c = QLabel("COLORS", self.colors_wrap)
        hdr_c.setStyleSheet(
            "color: #71717A; font-size: 9px; font-weight: 700; letter-spacing: 0.9px; "
            "border: none; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        cw_l.addWidget(hdr_c)

        grid = QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(7)
        grid.setVerticalSpacing(7)
        self.swatches = []
        for idx, col in enumerate(palette_colors):
            sw = _ColorSwatch(col, self.colors_wrap)
            sw.selected.connect(self.color_picked.emit)
            grid.addWidget(sw, idx // 6, idx % 6)
            self.swatches.append(sw)
        cw_l.addLayout(grid)
        lay.addWidget(self.colors_wrap)

        # Size Slider + Live Stroke Preview Dot
        self.size_wrap = QWidget(self)
        self.size_wrap.setStyleSheet("background: transparent; border: none;")
        sz_l = QVBoxLayout(self.size_wrap)
        sz_l.setContentsMargins(0, 2, 0, 0)
        sz_l.setSpacing(6)

        top_sz = QHBoxLayout()
        top_sz.setContentsMargins(0, 0, 0, 0)
        lbl_t = QLabel("SIZE", self.size_wrap)
        lbl_t.setStyleSheet(
            "color: #71717A; font-size: 9px; font-weight: 700; letter-spacing: 0.9px; "
            "border: none; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        self.lbl_px = QLabel("4px", self.size_wrap)
        self.lbl_px.setStyleSheet(
            "color: #E4E4E7; font-size: 10px; font-weight: 700; border: none; background: transparent; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        top_sz.addWidget(lbl_t)
        top_sz.addStretch(1)
        top_sz.addWidget(self.lbl_px)
        sz_l.addLayout(top_sz)

        sl_row = QHBoxLayout()
        sl_row.setContentsMargins(0, 0, 0, 0)
        sl_row.setSpacing(8)
        self.preview_dot = QLabel(self.size_wrap)
        self.preview_dot.setFixedSize(18, 18)
        self.preview_dot.setAlignment(Qt.AlignCenter)
        self.preview_dot.setStyleSheet("border: none; background: transparent;")
        sl_row.addWidget(self.preview_dot)

        self.slider = QSlider(Qt.Horizontal, self.size_wrap)
        self.slider.setRange(2, 26)
        self.slider.setValue(4)
        self.slider.setStyleSheet(
            "QSlider::groove:horizontal { height: 4px; background: rgba(255,255,255,0.12); border-radius: 2px; }"
            "QSlider::sub-page:horizontal { background: #a3e635; border-radius: 2px; }"
            "QSlider::handle:horizontal { width: 13px; height: 13px; margin: -4.5px 0; border-radius: 6.5px; "
            "background: #FFFFFF; border: 2px solid #a3e635; }"
        )
        self.slider.valueChanged.connect(self._on_val)
        sl_row.addWidget(self.slider, stretch=1)
        sz_l.addLayout(sl_row)
        lay.addWidget(self.size_wrap)

        self._cur_color = palette_colors[0]
        self._cur_size = 4
        self._refresh_dot()

    def _on_val(self, v):
        self._cur_size = int(v)
        self.lbl_px.setText(f"{v}px")
        self._refresh_dot()
        self.size_changed.emit(int(v))

    def _refresh_dot(self):
        dpr = native_dpr(self)
        px = max(1, int(round(18 * dpr)))
        pm = QPixmap(px, px)
        pm.fill(Qt.transparent)
        pt = QPainter(pm)
        pt.setRenderHint(QPainter.Antialiasing, True)
        d = max(3.5, min(15.0, 2.5 + (self._cur_size / 26.0) * 12.5)) * dpr
        r = QRectF((px - d) * 0.5, (px - d) * 0.5, d, d)
        pt.setBrush(QColor(self._cur_color))
        pt.setPen(QPen(QColor(255, 255, 255, 80), 0.9 * dpr))
        pt.drawEllipse(r)
        pt.end()
        pm.setDevicePixelRatio(dpr)
        self.preview_dot.setPixmap(pm)

    def sync_state(self, tool_id: str, color_hex: str, size_px: int, shape_kind: str):
        self._cur_color = color_hex
        self._cur_size = int(size_px)
        self.shape_row.setVisible(tool_id == "shape")
        self.colors_wrap.setVisible(tool_id != "eraser")
        self.btn_rect.set_active(shape_kind == "rect")
        self.btn_circle.set_active(shape_kind == "ellipse")
        for sw in self.swatches:
            sw.set_active(sw.hex_col.lower() == color_hex.lower())
        self.slider.blockSignals(True)
        self.slider.setValue(int(size_px))
        self.slider.blockSignals(False)
        self.lbl_px.setText(f"{int(size_px)}px")
        self._refresh_dot()
        self.adjustSize()


class _SnapEditorCanvas(QWidget):
    """
    Full-resolution annotated snap canvas:
      - Tools: doodle, marker, eraser, crop, arrow, shape ('rect'|'ellipse')
      - Supports drawing BOTH inside & outside the snap boundary (saved cleanly expanded)
      - Smooth wheel/button zoom (50%..400%) & subtle light-visible green border
    """
    state_changed = Signal()
    crop_rect_changed = Signal(bool)
    zoom_changed = Signal(int)
    interacted = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)
        self.setCursor(Qt.CrossCursor)

        self._base_pix = QPixmap()
        self._strokes = []
        self._undo_stack = []
        self._redo_stack = []

        self.tool = "doodle"
        self.pen_color = "#a3e635"
        self.pen_size = 4
        self.shape_kind = "rect"

        self._zoom = 1.0
        self._pan = QPointF(0.0, 0.0)
        self._panning = False
        self._pan_start = QPointF()

        self._drawing = False
        self._active_stroke = None
        self._crop_start = None
        self._crop_end = None
        self._img_draw_rect = QRectF()
        self._text_norm_pt = None
        self._text_pulse = 0.0

        self._text_box = QLineEdit(self)
        self._text_box.setVisible(False)
        self._text_box.setMaxLength(120)
        self._text_box.setPlaceholderText("Type here...")
        self._text_box.textEdited.connect(self._on_asmr_type)
        self._text_box.returnPressed.connect(self._commit_text)
        self._text_box.editingFinished.connect(self._commit_text)

        self._pulse_tm = QTimer(self)
        self._pulse_tm.setInterval(16)
        self._pulse_tm.timeout.connect(self._step_pulse)

    def _step_pulse(self):
        if self._text_pulse > 0.02:
            self._text_pulse *= 0.84
            self.update()
        else:
            self._text_pulse = 0.0
            self._pulse_tm.stop()

    def _on_asmr_type(self, _txt):
        _play_asmr_tick()
        self._text_pulse = 1.0
        if not self._pulse_tm.isActive():
            self._pulse_tm.start()
        if self._text_box.isVisible():
            fm = QFontMetrics(self._text_box.font())
            nw = max(130, min(420, fm.horizontalAdvance(self._text_box.text() or "Type here...") + 34))
            self._text_box.setFixedWidth(nw)
        self.update()

    def _begin_text_at(self, wpos: QPointF, npt: QPointF):
        self._commit_text()
        self._text_norm_pt = npt
        fpt = 11 + int(self.pen_size * 0.75)
        self._text_box.setStyleSheet(
            f"QLineEdit {{ background: rgba(10, 14, 10, 238); color: {self.pen_color}; "
            f"border: 1.5px solid #a3e635; border-radius: 8px; padding: 4px 10px; "
            f"font-size: {fpt}px; font-weight: 700; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }}"
        )
        self._text_box.setText("")
        self._text_box.setFixedSize(160, fpt + 20)
        tx = max(8, min(self.width() - 170, int(wpos.x())))
        ty = max(8, min(self.height() - (fpt + 26), int(wpos.y() - 14)))
        self._text_box.move(tx, ty)
        self._text_box.setVisible(True)
        self._text_box.setFocus()

    def _commit_text(self):
        if not self._text_box.isVisible():
            return
        txt = self._text_box.text().strip()
        self._text_box.setVisible(False)
        if txt and self._text_norm_pt is not None:
            self._push_undo()
            self._strokes.append({
                "type": "text",
                "color": self.pen_color,
                "size": self.pen_size,
                "pts": [self._text_norm_pt],
                "text": txt,
            })
            self.update()
        self._text_norm_pt = None

    def set_source_pixmap(self, pix: QPixmap):
        self._base_pix = pix.copy() if pix and not pix.isNull() else QPixmap()
        self._strokes = []
        self._undo_stack = []
        self._redo_stack = []
        self._zoom = 1.0
        self._pan = QPointF(0.0, 0.0)
        self._active_stroke = None
        self._crop_start = None
        self._crop_end = None
        self.zoom_changed.emit(100)
        self.state_changed.emit()
        self.crop_rect_changed.emit(False)
        self.update()

    def set_zoom(self, z: float):
        nz = max(0.5, min(4.0, float(z)))
        if abs(nz - 1.0) < 0.02:
            nz = 1.0
            self._pan = QPointF(0.0, 0.0)
        self._zoom = nz
        self.zoom_changed.emit(int(round(nz * 100)))
        self.update()

    def zoom_by(self, step: float):
        self.set_zoom(self._zoom + step)

    def can_undo(self):
        return len(self._undo_stack) > 0

    def can_redo(self):
        return len(self._redo_stack) > 0

    def _snapshot_state(self):
        return (self._base_pix.copy(), [dict(s, pts=list(s.get("pts", []))) for s in self._strokes])

    def _push_undo(self):
        self._undo_stack.append(self._snapshot_state())
        if len(self._undo_stack) > 30:
            self._undo_stack.pop(0)
        self._redo_stack.clear()
        self.state_changed.emit()

    def undo(self):
        if not self._undo_stack:
            return
        self._redo_stack.append(self._snapshot_state())
        base, strokes = self._undo_stack.pop()
        self._base_pix = base
        self._strokes = strokes
        self._crop_start = None
        self._crop_end = None
        self.crop_rect_changed.emit(False)
        self.state_changed.emit()
        self.update()

    def redo(self):
        if not self._redo_stack:
            return
        self._undo_stack.append(self._snapshot_state())
        base, strokes = self._redo_stack.pop()
        self._base_pix = base
        self._strokes = strokes
        self._crop_start = None
        self._crop_end = None
        self.crop_rect_changed.emit(False)
        self.state_changed.emit()
        self.update()

    def clear_crop_selection(self):
        self._crop_start = None
        self._crop_end = None
        self.crop_rect_changed.emit(False)
        self.update()

    def apply_crop(self):
        if not self._crop_start or not self._crop_end or self._base_pix.isNull():
            return False
        nx0 = min(self._crop_start.x(), self._crop_end.x())
        ny0 = min(self._crop_start.y(), self._crop_end.y())
        nx1 = max(self._crop_start.x(), self._crop_end.x())
        ny1 = max(self._crop_start.y(), self._crop_end.y())
        if (nx1 - nx0) < 0.03 or (ny1 - ny0) < 0.03:
            self.clear_crop_selection()
            return False

        self._push_undo()
        baked = self.render_final_pixmap()
        bw, bh = baked.width(), baked.height()
        rx = max(0, int(round(nx0 * bw)))
        ry = max(0, int(round(ny0 * bh)))
        rw = max(12, min(bw - rx, int(round((nx1 - nx0) * bw))))
        rh = max(12, min(bh - ry, int(round((ny1 - ny0) * bh))))
        cropped = baked.copy(rx, ry, rw, rh)
        cropped.setDevicePixelRatio(baked.devicePixelRatio())
        self._base_pix = cropped
        self._strokes = []
        self._crop_start = None
        self._crop_end = None
        self.crop_rect_changed.emit(False)
        self.state_changed.emit()
        self.update()
        return True

    def _compute_draw_rect(self) -> QRectF:
        if self._base_pix.isNull():
            return QRectF()
        dpr = max(1.0, float(self._base_pix.devicePixelRatio() or 1.0))
        lw = self._base_pix.width() / dpr
        lh = self._base_pix.height() / dpr
        # Leave clean outer canvas breathing room at 1.0x so users can annotate outside the image edge
        avw = max(80.0, float(self.width()) - 48.0)
        avh = max(60.0, float(self.height()) - 32.0)
        base_sc = min(avw / max(1.0, lw), avh / max(1.0, lh), 1.0)
        sc = base_sc * self._zoom
        dw = lw * sc
        dh = lh * sc
        cx = (self.width() - dw) * 0.5 + self._pan.x()
        cy = (self.height() - dh) * 0.5 + self._pan.y()
        return QRectF(cx, cy, dw, dh)

    def _widget_to_norm(self, pt: QPointF, clamp=False) -> QPointF:
        r = self._img_draw_rect
        if r.width() <= 1 or r.height() <= 1:
            return QPointF(0.5, 0.5)
        nx = (pt.x() - r.x()) / r.width()
        ny = (pt.y() - r.y()) / r.height()
        if clamp:
            nx = max(0.0, min(1.0, nx))
            ny = max(0.0, min(1.0, ny))
        return QPointF(nx, ny)

    def wheelEvent(self, e):
        delta = e.angleDelta().y()
        if delta != 0:
            self.zoom_by(0.15 if delta > 0 else -0.15)
            e.accept()
            return
        super().wheelEvent(e)

    def _erase_near(self, npt: QPointF):
        r = self._img_draw_rect
        thresh = max(0.018, (self.pen_size * 2.2) / max(80.0, r.width()))
        removed = False
        kept = []
        for s in self._strokes:
            hit = False
            pts = s.get("pts", [])
            for sp in pts:
                if math.hypot(sp.x() - npt.x(), sp.y() - npt.y()) <= thresh:
                    hit = True
                    break
            if not hit and s["type"] in ("arrow", "rect", "ellipse") and len(pts) == 2:
                x0, x1 = min(pts[0].x(), pts[1].x()) - thresh, max(pts[0].x(), pts[1].x()) + thresh
                y0, y1 = min(pts[0].y(), pts[1].y()) - thresh, max(pts[0].y(), pts[1].y()) + thresh
                if x0 <= npt.x() <= x1 and y0 <= npt.y() <= y1:
                    hit = True
            if hit:
                if not removed:
                    self._push_undo()
                    removed = True
            else:
                kept.append(s)
        if removed:
            self._strokes = kept
            self.update()

    def mousePressEvent(self, e):
        self.interacted.emit()
        if e.button() == Qt.MiddleButton:
            self._panning = True
            self._pan_start = e.position()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
            return
        if e.button() == Qt.LeftButton and not self._base_pix.isNull():
            self._img_draw_rect = self._compute_draw_rect()
            npt = self._widget_to_norm(e.position(), clamp=(self.tool == "crop"))
            if self.tool == "type":
                self._begin_text_at(e.position(), npt)
                e.accept()
                return
            self._commit_text()
            self._drawing = True
            if self.tool == "eraser":
                self._erase_near(npt)
            elif self.tool == "crop":
                self._crop_start = npt
                self._crop_end = npt
                self.crop_rect_changed.emit(False)
                self.update()
            elif self.tool in ("doodle", "marker"):
                self._push_undo()
                self._active_stroke = {
                    "type": self.tool,
                    "color": self.pen_color,
                    "size": self.pen_size,
                    "pts": [npt],
                }
                self._strokes.append(self._active_stroke)
                self.update()
            elif self.tool in ("arrow", "shape"):
                self._push_undo()
                stype = "arrow" if self.tool == "arrow" else self.shape_kind
                self._active_stroke = {
                    "type": stype,
                    "color": self.pen_color,
                    "size": self.pen_size,
                    "pts": [npt, npt],
                }
                self._strokes.append(self._active_stroke)
                self.update()
            e.accept()

    def mouseMoveEvent(self, e):
        if self._panning:
            diff = e.position() - self._pan_start
            self._pan += diff
            self._pan_start = e.position()
            self.update()
            e.accept()
            return
        if not self._drawing:
            return
        npt = self._widget_to_norm(e.position(), clamp=(self.tool == "crop"))
        if self.tool == "eraser":
            self._erase_near(npt)
        elif self.tool == "crop":
            self._crop_end = npt
            self.crop_rect_changed.emit(True)
            self.update()
        elif self._active_stroke:
            if self.tool in ("doodle", "marker"):
                self._active_stroke["pts"].append(npt)
            else:
                self._active_stroke["pts"][1] = npt
            self.update()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MiddleButton and self._panning:
            self._panning = False
            self.setCursor(Qt.CrossCursor)
            e.accept()
            return
        if e.button() == Qt.LeftButton and self._drawing:
            self._drawing = False
            self._active_stroke = None
            if self.tool == "crop" and self._crop_start and self._crop_end:
                has_box = abs(self._crop_end.x() - self._crop_start.x()) > 0.03 and abs(self._crop_end.y() - self._crop_start.y()) > 0.03
                self.crop_rect_changed.emit(has_box)
            self.update()
            e.accept()

    @staticmethod
    def _paint_strokes(p: QPainter, target_rect: QRectF, strokes, scale_factor=1.0):
        rx, ry, rw, rh = target_rect.x(), target_rect.y(), target_rect.width(), target_rect.height()

        def mp(npt: QPointF) -> QPointF:
            return QPointF(rx + npt.x() * rw, ry + npt.y() * rh)

        for s in strokes:
            pts = s.get("pts", [])
            if not pts:
                continue
            stype = s["type"]
            col = QColor(s["color"])
            sz = float(s["size"]) * scale_factor

            if stype == "marker":
                col.setAlpha(98)
                p.setPen(QPen(col, sz * 2.5, Qt.SolidLine, Qt.FlatCap, Qt.RoundJoin))
                p.setBrush(Qt.NoBrush)
                path = QPainterPath(mp(pts[0]))
                for pt in pts[1:]:
                    path.lineTo(mp(pt))
                p.drawPath(path)
            elif stype == "doodle":
                p.setPen(QPen(col, sz, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                p.setBrush(Qt.NoBrush)
                if len(pts) == 1:
                    p.drawPoint(mp(pts[0]))
                else:
                    path = QPainterPath(mp(pts[0]))
                    for i in range(1, len(pts)):
                        prev = mp(pts[i - 1])
                        cur = mp(pts[i])
                        mid = QPointF((prev.x() + cur.x()) * 0.5, (prev.y() + cur.y()) * 0.5)
                        path.quadTo(prev, mid)
                    path.lineTo(mp(pts[-1]))
                    p.drawPath(path)
            elif stype == "rect" and len(pts) >= 2:
                p.setPen(QPen(col, max(2.0, sz), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                p.setBrush(Qt.NoBrush)
                r = QRectF(mp(pts[0]), mp(pts[1])).normalized()
                p.drawRoundedRect(r, 5.0 * scale_factor, 5.0 * scale_factor)
            elif stype == "ellipse" and len(pts) >= 2:
                p.setPen(QPen(col, max(2.0, sz), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                p.setBrush(Qt.NoBrush)
                r = QRectF(mp(pts[0]), mp(pts[1])).normalized()
                p.drawEllipse(r)
            elif stype == "arrow" and len(pts) >= 2:
                a = mp(pts[0])
                b = mp(pts[1])
                dx = b.x() - a.x()
                dy = b.y() - a.y()
                dist = math.hypot(dx, dy)
                if dist > 4.0:
                    ux, uy = dx / dist, dy / dist
                    lw = max(2.2, sz)
                    hlen = min(dist * 0.65, max(13.0 * scale_factor, lw * 3.1))
                    half_w = hlen * 0.44
                    px_u, py_u = -uy, ux
                    # End shaft cleanly inside the arrowhead triangle so RoundCap never protrudes ahead of tip b
                    base_center = QPointF(b.x() - ux * (hlen * 0.78), b.y() - uy * (hlen * 0.78))
                    p1 = QPointF(base_center.x() + px_u * half_w, base_center.y() + py_u * half_w)
                    p2 = QPointF(base_center.x() - px_u * half_w, base_center.y() - py_u * half_w)
                    p.setPen(QPen(col, lw, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                    p.setBrush(Qt.NoBrush)
                    p.drawLine(a, base_center)
                    poly = QPainterPath(b)
                    poly.lineTo(p1)
                    poly.lineTo(p2)
                    poly.closeSubpath()
                    p.setPen(Qt.NoPen)
                    p.fillPath(poly, col)
            elif stype == "text" and pts:
                txt = str(s.get("text") or "")
                if not txt:
                    continue
                pt0 = mp(pts[0])
                f_txt = QFont("Segoe UI Variable")
                f_txt.setStyleName("Display Bold")
                f_txt.setPixelSize(max(13, int(round((11.0 + float(s.get("size", 4)) * 0.75) * scale_factor))))
                f_txt.setStyleStrategy(QFont.PreferAntialias | QFont.NoSubpixelAntialias)
                p.setFont(f_txt)
                off = max(1.2, 1.5 * scale_factor)
                p.setPen(QColor(0, 0, 0, 175))
                p.drawText(QPointF(pt0.x() + off, pt0.y() + off), txt)
                p.setPen(col)
                p.drawText(pt0, txt)

    def render_final_pixmap(self) -> QPixmap:
        if self._base_pix.isNull():
            return QPixmap()
        bw = float(self._base_pix.width())
        bh = float(self._base_pix.height())
        if not self._strokes:
            return self._base_pix.copy()

        disp_w = max(80.0, self._img_draw_rect.width() or bw)
        sf = bw / disp_w

        min_x, min_y = 0.0, 0.0
        max_x, max_y = bw, bh
        for s in self._strokes:
            pad = max(14.0, float(s.get("size", 4)) * sf * 2.5)
            pts = s.get("pts", [])
            if s.get("type") == "text" and pts:
                f_txt = QFont("Segoe UI Variable")
                f_txt.setStyleName("Display Bold")
                f_txt.setPixelSize(max(13, int(round((11.0 + float(s.get("size", 4)) * 0.75) * sf))))
                fm = QFontMetrics(f_txt)
                px, py = pts[0].x() * bw, pts[0].y() * bh
                tw = fm.horizontalAdvance(str(s.get("text") or "")) + 18.0
                th = fm.height() + 10.0
                min_x = min(min_x, px - 12.0)
                min_y = min(min_y, py - th)
                max_x = max(max_x, px + tw)
                max_y = max(max_y, py + 14.0)
                continue
            for pt in pts:
                px, py = pt.x() * bw, pt.y() * bh
                min_x = min(min_x, px - pad)
                min_y = min(min_y, py - pad)
                max_x = max(max_x, px + pad)
                max_y = max(max_y, py + pad)

        # Expand output canvas cleanly if user drew outside the image
        out_w = min(6000, max(int(round(bw)), int(math.ceil(max_x - min_x))))
        out_h = min(6000, max(int(round(bh)), int(math.ceil(max_y - min_y))))
        out = QPixmap(out_w, out_h)
        out.setDevicePixelRatio(self._base_pix.devicePixelRatio())
        out.fill(QColor(8, 9, 11))

        ox = -min_x
        oy = -min_y
        p = QPainter(out)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        p.drawPixmap(int(round(ox)), int(round(oy)), self._base_pix)
        self._paint_strokes(p, QRectF(ox, oy, bw, bh), self._strokes, scale_factor=sf)
        p.end()
        return out

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        # Studio matte background stage (supports annotations outside image)
        stage_path = QPainterPath()
        stage_path.addRoundedRect(QRectF(0.6, 0.6, self.width() - 1.2, self.height() - 1.2), 10.0, 10.0)
        p.fillPath(stage_path, QColor(8, 9, 11, 255))
        p.setPen(QPen(QColor(255, 255, 255, 16), 0.9))
        p.drawPath(stage_path)

        self._img_draw_rect = self._compute_draw_rect()
        dr = self._img_draw_rect
        if dr.isEmpty():
            p.end()
            return

        p.save()
        p.setClipPath(stage_path)

        clip_path = QPainterPath()
        clip_path.addRoundedRect(dr, 8.0, 8.0)
        p.save()
        p.setClipPath(clip_path)
        p.drawPixmap(dr.toRect(), self._base_pix)

        # Crop selection overlay
        if self.tool == "crop" and self._crop_start and self._crop_end:
            cr = QRectF(
                QPointF(dr.x() + self._crop_start.x() * dr.width(), dr.y() + self._crop_start.y() * dr.height()),
                QPointF(dr.x() + self._crop_end.x() * dr.width(), dr.y() + self._crop_end.y() * dr.height()),
            ).normalized()
            if cr.width() > 3 and cr.height() > 3:
                ov = QPainterPath()
                ov.addRect(dr)
                hole = QPainterPath()
                hole.addRect(cr)
                p.fillPath(ov.subtracted(hole), QColor(4, 4, 5, 145))
                p.setPen(QPen(QColor("#a3e635"), 1.6, Qt.DashLine))
                p.drawRect(cr)
        p.restore()

        # Subtle light-visible green border around original image area
        p.setPen(QPen(QColor(163, 230, 53, 62), 1.0))
        p.drawPath(clip_path)

        # Paint strokes unclipped across full studio canvas (both inside AND outside image!)
        self._paint_strokes(p, dr, self._strokes, scale_factor=self._zoom)
        p.restore()
        p.end()


class _SnipResultWindow(QWidget):
    """
    SUPER SNAP iOS-Minimalist Studio Editor (Windows 11 Snipping Tool Command Logic):
      - Header Tier 1: Vector 'SUPER SNAP' brand + Inline Name Bar | Save, Copy, Put in Box | Back, Home, Close (ZERO top-right #number!)
      - Header Tier 2: Floating Top Command Pill -> Pen, Highlighter, Type, Arrow, Shape, Eraser, Crop | Undo, Redo | AI, Re-Take, Share, SuperShare | Zoom
      - On-Demand Anchored Flyout Popover (_ToolConfigFlyout): 12 Curated Colors + Live Size Slider + Rect/Circle Switcher (Zero static color clutter!)
      - Canvas: Expansive full-height unobstructed studio stage (annotations inside & outside edge + wheel zoom + crisp non-protruding arrowheads)
    """
    retake_requested = Signal()

    PALETTE_COLORS = [
        "#a3e635", "#22C55E", "#06B6D4", "#3B82F6", "#8B5CF6", "#EC4899",
        "#EF4444", "#F97316", "#FACC15", "#FFFFFF", "#94A3B8", "#18181B",
    ]

    def __init__(self, status_popup, edge_popup, on_box_updated=None, on_back=None, on_main_menu=None, parent=None):
        super().__init__(
            parent,
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint,
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.status_popup = status_popup
        self.edge_popup = edge_popup
        self.on_box_updated = on_box_updated
        self.on_back = on_back
        self.on_main_menu = on_main_menu

        self._snap_pix = None
        self._screen = None
        self._snap_num = 1024
        self._flyer = _FlyingSnapImage()
        self._dragging = False
        self._drag_offset = QPoint()
        self._flyout_tool = None

        self._tool_prefs = {
            "doodle": {"color": "#a3e635", "size": 4},
            "marker": {"color": "#FACC15", "size": 10},
            "type":   {"color": "#FFFFFF", "size": 5},
            "arrow":  {"color": "#EF4444", "size": 4},
            "shape":  {"color": "#a3e635", "size": 4},
            "eraser": {"color": "#FFFFFF", "size": 8},
        }

        base_assets = os.path.join(BASE_DIR, "thesupermouse", "assets")
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        self._raw_logo = QImage(logo_fp) if os.path.exists(logo_fp) else None
        if self._raw_logo and not self._raw_logo.isNull():
            ldpr = _native_dpr(self)
            li = self._raw_logo.scaledToHeight(max(20, int(round(20 * ldpr))), Qt.SmoothTransformation)
            self.logo_pix = QPixmap.fromImage(li)
            self.logo_pix.setDevicePixelRatio(ldpr)
        else:
            self.logo_pix = None

        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(14, 0, 14, 14)
        root.setSpacing(6)

        # ─── 1. Tier-1 Minimalist Top Chrome: Brand + Name | Primary Actions | Back, Home, Close ─
        header = QWidget(self)
        header.setFixedHeight(50)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(136, 0, 0, 0)
        hdr.setSpacing(6)

        # Sleek inline Name capsule (no heavy outer box clutter)
        name_pill = QFrame(header)
        name_pill.setFixedHeight(30)
        name_pill.setFixedWidth(196)
        name_pill.setStyleSheet(
            "QFrame { background-color: #0B0C10; border: 1px solid rgba(255,255,255,0.08); border-radius: 9px; }"
            "QFrame:focus-within { border-color: rgba(163,230,53,0.45); background-color: #0F1115; }"
        )
        np_l = QHBoxLayout(name_pill)
        np_l.setContentsMargins(9, 0, 8, 0)
        np_l.setSpacing(6)
        np_ico = QLabel(name_pill)
        np_ico.setPixmap(render_common_icon("pencil", "#848A95", 13, dpr=native_dpr(self)))
        np_ico.setStyleSheet("border: none; background: transparent;")
        np_l.addWidget(np_ico)

        self.name_input = QLineEdit(name_pill)
        self.name_input.setPlaceholderText("Snap name...")
        self.name_input.setMaxLength(44)
        self.name_input.setStyleSheet(
            "QLineEdit { background: transparent; border: none; color: #F4F4F5; "
            "font-size: 11px; font-weight: 600; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
        )
        self.name_input.textEdited.connect(lambda _: _play_asmr_tick())
        np_l.addWidget(self.name_input, stretch=1)
        hdr.addWidget(name_pill, alignment=Qt.AlignVCenter)

        hdr.addStretch(1)

        self.btn_save = _ActionPillButton("Save", _LUCIDE_PIN_ICONS["save"], compact=True, parent=header)
        self.btn_copy = _ActionPillButton("Copy", _LUCIDE_PIN_ICONS["copy"], compact=True, parent=header)
        self.btn_box = _ActionPillButton("Put in Box", _LUCIDE_PIN_ICONS["package_plus"], primary=True, compact=True, parent=header)
        self.btn_save.clicked.connect(self._on_save_desktop)
        self.btn_copy.clicked.connect(self._on_copy)
        self.btn_box.clicked.connect(self._on_put_in_box)
        hdr.addWidget(self.btn_save, alignment=Qt.AlignVCenter)
        hdr.addWidget(self.btn_copy, alignment=Qt.AlignVCenter)
        hdr.addWidget(self.btn_box, alignment=Qt.AlignVCenter)

        hdr.addSpacing(4)
        hdr.addWidget(self._vdiv(16), alignment=Qt.AlignVCenter)
        hdr.addSpacing(2)

        # NO #number! Clean borderless Back, Home & Close right at top-right!
        self.btn_back = CleanHeaderIconButton("back", "Back to Super Snap & Pin", box_size=30, icon_size=15, on_press_tick=_play_asmr_tick, parent=header)
        self.btn_menu = CleanHeaderIconButton("home", "Main Menu", box_size=30, icon_size=15, on_press_tick=_play_asmr_tick, parent=header)
        self.btn_win_close = CleanCloseButton("Close Super Snap", box_size=30, icon_size=15, parent=header)
        self.btn_back.clicked.connect(self._go_back)
        self.btn_menu.clicked.connect(self._go_menu)
        self.btn_win_close.clicked.connect(self.hide)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)
        hdr.addWidget(self.btn_menu, alignment=Qt.AlignVCenter)
        hdr.addWidget(self.btn_win_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        # ─── 2. Tier-2 Centered Top Floating Markup Command Bar (All Tools Above Canvas!) ─
        cmd_wrap = QWidget(self)
        cmd_wrap.setFixedHeight(44)
        cw_l = QHBoxLayout(cmd_wrap)
        cw_l.setContentsMargins(0, 0, 0, 2)
        cw_l.setAlignment(Qt.AlignCenter)

        self.cmd_bar = QFrame(cmd_wrap)
        self.cmd_bar.setFixedHeight(42)
        self.cmd_bar.setStyleSheet(
            "QFrame { background-color: #0B0C10; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 13px; }"
        )
        cb_l = QHBoxLayout(self.cmd_bar)
        cb_l.setContentsMargins(8, 0, 10, 0)
        cb_l.setSpacing(3)

        self._tool_btns = {}
        for tid, ikey, tip, cfg in (
            ("doodle", "pen_line",       "Pen (Click again for 12 Colors & Size)",         True),
            ("marker", "highlighter",    "Highlighter (Click again for 12 Colors & Size)", True),
            ("type",   "type",           "Text (Click again for 12 Colors & Size)",        True),
            ("arrow",  "move_up_right",  "Arrow (Click again for 12 Colors & Size)",       True),
            ("shape",  "shapes",         "Shapes (Click again for Rect/Circle & Colors)",  True),
            ("eraser", "eraser",         "Eraser (Click again for Size)",                  True),
            ("crop",   "crop",           "Crop Frame",                                     False),
        ):
            dot = self._tool_prefs[tid]["color"] if tid in self._tool_prefs and tid != "eraser" else None
            btn = _ToolIconBtn(ikey, tip, size_px=34, icon_px=17, configurable=cfg, color_dot=dot, parent=self.cmd_bar)
            btn.clicked.connect(lambda k=tid: self._select_tool(k))
            if cfg:
                btn.configure_requested.connect(lambda k=tid: self._toggle_flyout_for(k))
            cb_l.addWidget(btn, alignment=Qt.AlignVCenter)
            self._tool_btns[tid] = btn

        cb_l.addSpacing(3)
        cb_l.addWidget(self._vdiv(18), alignment=Qt.AlignVCenter)
        cb_l.addSpacing(3)

        self.btn_undo = _ToolIconBtn("undo", "Undo (Ctrl+Z)", size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_redo = _ToolIconBtn("redo", "Redo (Ctrl+Y)", size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_undo.clicked.connect(self.canvas.undo if hasattr(self, "canvas") else lambda: None)
        self.btn_redo.clicked.connect(self.canvas.redo if hasattr(self, "canvas") else lambda: None)
        cb_l.addWidget(self.btn_undo, alignment=Qt.AlignVCenter)
        cb_l.addWidget(self.btn_redo, alignment=Qt.AlignVCenter)

        cb_l.addSpacing(3)
        cb_l.addWidget(self._vdiv(18), alignment=Qt.AlignVCenter)
        cb_l.addSpacing(3)

        self.btn_bg_remove = _ToolIconBtn("sparkles", "BG Remove (Coming Soon)", coming_soon=True, size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_scan_text = _ToolIconBtn("text_extractor", "Scan Text (Coming Soon)", coming_soon=True, size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_retake = _ToolIconBtn("rotate_ccw", "Re-Take Snap", size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_share = _ToolIconBtn("share", "Share Snap", size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_supershare = _ToolIconBtn("supershare", "SuperShare (Coming Soon)", coming_soon=True, size_px=32, icon_px=16, parent=self.cmd_bar)

        self.btn_bg_remove.clicked.connect(lambda: (self._hide_flyout(), self._show_coming_soon("BG REMOVE", "sparkles")))
        self.btn_scan_text.clicked.connect(lambda: (self._hide_flyout(), self._show_coming_soon("SCAN TEXT", "text_extractor")))
        self.btn_retake.clicked.connect(self._on_retake)
        self.btn_share.clicked.connect(self._on_share)
        self.btn_supershare.clicked.connect(lambda: (self._hide_flyout(), self._show_coming_soon("SUPERSHARE", "supershare")))

        for b in (self.btn_bg_remove, self.btn_scan_text, self.btn_retake, self.btn_share, self.btn_supershare):
            cb_l.addWidget(b, alignment=Qt.AlignVCenter)

        cb_l.addSpacing(3)
        cb_l.addWidget(self._vdiv(18), alignment=Qt.AlignVCenter)
        cb_l.addSpacing(4)

        # Minimalist Inline Zoom Controls (- 100% +) right inside Top Command Pill
        z_btn_qss = (
            "QPushButton { background: transparent; color: #9CA3AF; border: none; font-size: 13px; font-weight: 700; min-width: 20px; }"
            "QPushButton:hover { color: #FFFFFF; }"
        )
        btn_z_out = QPushButton("−", self.cmd_bar)
        btn_z_out.setCursor(Qt.PointingHandCursor)
        btn_z_out.setStyleSheet(z_btn_qss)
        btn_z_out.setToolTip("Zoom Out (Mouse Wheel Down)")
        btn_z_out.clicked.connect(lambda: self.canvas.zoom_by(-0.2))

        self.btn_z_pct = QPushButton("100%", self.cmd_bar)
        self.btn_z_pct.setCursor(Qt.PointingHandCursor)
        self.btn_z_pct.setStyleSheet(
            "QPushButton { background: transparent; color: #D4D4D8; border: none; font-size: 10.5px; font-weight: 700; min-width: 36px; }"
            "QPushButton:hover { color: #a3e635; }"
        )
        self.btn_z_pct.setToolTip("Reset Zoom & Pan to 100%")
        self.btn_z_pct.clicked.connect(lambda: self.canvas.set_zoom(1.0))

        btn_z_in = QPushButton("+", self.cmd_bar)
        btn_z_in.setCursor(Qt.PointingHandCursor)
        btn_z_in.setStyleSheet(z_btn_qss)
        btn_z_in.setToolTip("Zoom In (Mouse Wheel Up)")
        btn_z_in.clicked.connect(lambda: self.canvas.zoom_by(0.2))

        cb_l.addWidget(btn_z_out, alignment=Qt.AlignVCenter)
        cb_l.addWidget(self.btn_z_pct, alignment=Qt.AlignVCenter)
        cb_l.addWidget(btn_z_in, alignment=Qt.AlignVCenter)

        cw_l.addWidget(self.cmd_bar)
        root.addWidget(cmd_wrap)

        # ─── 3. Big Uncluttered Studio Canvas (Occupies Full Remaining Space!) ─
        self.canvas = _SnapEditorCanvas(self)
        self.canvas.state_changed.connect(self._sync_undo_redo)
        self.canvas.crop_rect_changed.connect(self._on_crop_ready)
        self.canvas.zoom_changed.connect(lambda pct: self.btn_z_pct.setText(f"{pct}%"))
        self.canvas.interacted.connect(self._hide_flyout)
        self.btn_undo.clicked.disconnect()
        self.btn_redo.clicked.disconnect()
        self.btn_undo.clicked.connect(lambda: (self._hide_flyout(), self.canvas.undo()))
        self.btn_redo.clicked.connect(lambda: (self._hide_flyout(), self.canvas.redo()))
        root.addWidget(self.canvas, stretch=1)

        # Floating Crop Confirmation Pill inside Canvas (only shown while Crop box drawn)
        self._crop_box = QFrame(self.canvas)
        self._crop_box.setStyleSheet(
            "QFrame { background-color: rgba(12, 13, 16, 244); border: 1px solid rgba(255,255,255,0.12); border-radius: 10px; }"
        )
        cr_l = QHBoxLayout(self._crop_box)
        cr_l.setContentsMargins(6, 5, 6, 5)
        cr_l.setSpacing(6)
        self.btn_crop_apply = _ActionPillButton("Apply Crop", _LUCIDE_PIN_ICONS["check"], primary=True, compact=True, parent=self._crop_box)
        self.btn_crop_apply.clicked.connect(self.canvas.apply_crop)
        self.btn_crop_cancel = _ToolIconBtn("x", "Clear Crop Selection", size_px=28, icon_px=14, parent=self._crop_box)
        self.btn_crop_cancel.clicked.connect(self.canvas.clear_crop_selection)
        cr_l.addWidget(self.btn_crop_apply)
        cr_l.addWidget(self.btn_crop_cancel)
        self._crop_box.adjustSize()
        self._crop_box.setVisible(False)

        # ─── 4. Windows 11 Snipping Tool Floating Flyout (12 Colors + Size + Shape) ─
        self.flyout = _ToolConfigFlyout(self.PALETTE_COLORS, parent=self)
        self.flyout.color_picked.connect(self._select_color)
        self.flyout.size_changed.connect(self._on_size_changed)
        self.flyout.shape_picked.connect(self._select_shape)
        self.flyout.setVisible(False)

        self._select_tool("doodle")
        self._sync_undo_redo()

    def _vdiv(self, h=18):
        d = QFrame(self)
        d.setFixedSize(1, h)
        d.setStyleSheet("background-color: rgba(255,255,255,0.09); border: none;")
        return d

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if hasattr(self, "_crop_box") and hasattr(self, "canvas"):
            self._crop_box.adjustSize()
            self._crop_box.move(max(12, self.canvas.width() - self._crop_box.width() - 14), 12)
        if hasattr(self, "flyout") and self.flyout.isVisible() and self._flyout_tool:
            self._position_flyout(self._flyout_tool)

    def _hide_flyout(self):
        if hasattr(self, "flyout") and self.flyout.isVisible():
            self.flyout.setVisible(False)
            self._flyout_tool = None

    def _position_flyout(self, tid: str):
        btn = self._tool_btns.get(tid)
        if not btn:
            return
        pt = btn.mapTo(self, QPoint(btn.width() // 2, btn.height()))
        self.flyout.adjustSize()
        fx = max(16, min(self.width() - self.flyout.width() - 16, pt.x() - self.flyout.width() // 2))
        fy = pt.y() + 8
        self.flyout.move(fx, fy)
        self.flyout.raise_()

    def _toggle_flyout_for(self, tid: str):
        if self.flyout.isVisible() and self._flyout_tool == tid:
            self._hide_flyout()
            return
        self._flyout_tool = tid
        pref = self._tool_prefs.get(tid, {"color": self.canvas.pen_color, "size": self.canvas.pen_size})
        self.flyout.sync_state(tid, pref["color"], pref["size"], self.canvas.shape_kind)
        self._position_flyout(tid)
        self.flyout.setVisible(True)
        self.flyout.raise_()

    def _select_color(self, hex_col):
        tid = self._flyout_tool or self.canvas.tool
        if tid in self._tool_prefs:
            self._tool_prefs[tid]["color"] = hex_col
        self.canvas.pen_color = hex_col
        if tid in self._tool_btns and tid != "eraser":
            self._tool_btns[tid].set_color_dot(hex_col)
        if hasattr(self, "flyout"):
            self.flyout.sync_state(
                tid,
                hex_col,
                self._tool_prefs.get(tid, {}).get("size", self.canvas.pen_size),
                self.canvas.shape_kind,
            )

    def _select_shape(self, kind):
        self.canvas.shape_kind = kind
        if hasattr(self, "flyout"):
            tid = self._flyout_tool or self.canvas.tool
            pref = self._tool_prefs.get(tid, {"color": self.canvas.pen_color, "size": self.canvas.pen_size})
            self.flyout.sync_state("shape", pref["color"], pref["size"], kind)

    def _on_size_changed(self, val):
        tid = self._flyout_tool or self.canvas.tool
        if tid in self._tool_prefs:
            self._tool_prefs[tid]["size"] = int(val)
        self.canvas.pen_size = int(val)

    def _select_tool(self, tid):
        if self._flyout_tool and self._flyout_tool != tid:
            self._hide_flyout()
        self.canvas.tool = tid
        self.canvas.setCursor(Qt.IBeamCursor if tid == "type" else Qt.CrossCursor)
        for k, b in self._tool_btns.items():
            b.set_active(k == tid)
        if tid in self._tool_prefs:
            pref = self._tool_prefs[tid]
            self.canvas.pen_color = pref["color"]
            self.canvas.pen_size = pref["size"]
        if tid != "crop":
            self.canvas.clear_crop_selection()

    def _on_crop_ready(self, ready):
        self._crop_box.adjustSize()
        self._crop_box.move(max(12, self.canvas.width() - self._crop_box.width() - 14), 12)
        self._crop_box.setVisible(bool(ready))
        if ready:
            self._crop_box.raise_()

    def _sync_undo_redo(self):
        self.btn_undo.set_enabled_btn(self.canvas.can_undo())
        self.btn_redo.set_enabled_btn(self.canvas.can_redo())

    def _show_coming_soon(self, title, ico_key):
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.status_popup.show_message(title, _LUCIDE_PIN_ICONS[ico_key], c, badge_text="COMING SOON", duration_ms=1700)

    def _fade_switch_out(self, cb=None):
        self._hide_flyout()
        if not self.isVisible():
            if callable(cb):
                cb()
            return
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        def _done():
            self.hide()
            self.setWindowOpacity(1.0)
            if callable(cb):
                cb()
        af.finished.connect(_done)
        self._fade_anim = af
        af.start()

    def _go_back(self):
        self._fade_switch_out(self.on_back)

    def _go_menu(self):
        self._fade_switch_out(self.on_main_menu)

    def show_snap(self, snap_pix, sel_global_rect, screen):
        self._hide_flyout()
        self.setWindowOpacity(1.0)
        self._snap_pix = snap_pix
        self._screen = screen or QApplication.primaryScreen()
        avail = self._screen.availableGeometry()

        self.canvas.set_source_pixmap(snap_pix)
        self._snap_num = next_snap_number()
        self.name_input.setText(_logical_snap_name(datetime.now(), ""))

        dpr = max(1.0, float(snap_pix.devicePixelRatio() or 1.0))
        img_w = snap_pix.width() / dpr
        img_h = snap_pix.height() / dpr

        win_w = max(920, min(int(avail.width() * 0.86), int(img_w + 90)))
        win_h = max(470, min(int(avail.height() * 0.84), int(img_h + 150)))
        self.setFixedSize(win_w, win_h)

        cx, cy = sel_global_rect.center().x(), sel_global_rect.center().y()
        x = max(avail.left() + 14, min(avail.right() - win_w - 14, cx - win_w // 2))
        y = max(avail.top() + 14, min(avail.bottom() - win_h - 14, cy - win_h // 2))

        self.move(x, y)
        self.show()
        self.raise_()
        self.activateWindow()

    def _baked_pix(self) -> QPixmap:
        pix = self.canvas.render_final_pixmap()
        return pix if not pix.isNull() else (self._snap_pix or QPixmap())

    def _on_retake(self):
        self._hide_flyout()
        self.hide()
        self.retake_requested.emit()

    def _on_share(self):
        self._hide_flyout()
        pix = self._baked_pix()
        copy_pixmap_to_clipboard(pix, hwnd=int(self.winId()) if self.winId() else None)
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.status_popup.show_message(
            "READY TO SHARE", _LUCIDE_PIN_ICONS["share"], c, badge_text="COPIED FOR SHARING", duration_ms=1700
        )

    def _on_copy(self):
        self._hide_flyout()
        pix = self._baked_pix()
        copy_pixmap_to_clipboard(pix, hwnd=int(self.winId()) if self.winId() else None)
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.hide()
        self.status_popup.show_message(
            "SNAP COPIED", _LUCIDE_PIN_ICONS["copy"], c, badge_text="COPIED TO CLIPBOARD", duration_ms=1700
        )

    def _on_save_desktop(self):
        self._hide_flyout()
        pix = self._baked_pix()
        if pix.isNull():
            self.hide()
            return
        desk = get_desktop_dir()
        safe_nm = "".join(c for c in self.name_input.text().strip() if c.isalnum() or c in (" ", "-", "_")).strip().replace(" ", "_")
        prefix = f"SuperSnap_{safe_nm}" if safe_nm else f"SuperSnap_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        fname = f"{prefix}.png"
        out_fp = os.path.join(desk, fname)
        if os.path.exists(out_fp):
            fname = f"{prefix}_{datetime.now().strftime('%H%M%S')}.png"
            out_fp = os.path.join(desk, fname)
        pix.save(out_fp, "PNG")
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.hide()
        self.status_popup.show_message(
            "SAVED TO DESKTOP", _LUCIDE_PIN_ICONS["save"], c, badge_text=fname, duration_ms=2000
        )

    def _on_put_in_box(self):
        self._hide_flyout()
        snap = self._baked_pix()
        if snap.isNull():
            self.hide()
            return
        ensure_box_dir()
        fname = f"BoxSnap_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        out_fp = os.path.join(BOX_DIR, fname)
        snap.save(out_fp, "PNG")

        custom_name = self.name_input.text().strip() or _logical_snap_name(datetime.now(), out_fp)
        save_custom_snap_meta(out_fp, self._snap_num, custom_name)
        if self.on_box_updated:
            self.on_box_updated()

        tl = self.canvas.mapToGlobal(QPoint(0, 0))
        img_rect = QRect(tl.x(), tl.y(), self.canvas.width(), self.canvas.height())
        scr = self._screen
        snap_lbl = f"#{self._snap_num} · {custom_name}"

        self.hide()
        self._flyer.fly_into_right_edge(
            snap,
            img_rect,
            scr,
            on_fully_inside=lambda yc: self.edge_popup.show_from_right(
                yc, out_fp, snap_pix=snap, screen=scr, snap_label=snap_lbl
            ),
        )

    def keyPressEvent(self, e):
        if e.modifiers() & Qt.ControlModifier:
            if e.key() == Qt.Key_Z:
                self.canvas.undo()
                e.accept()
                return
            if e.key() == Qt.Key_Y:
                self.canvas.redo()
                e.accept()
                return
        if e.key() == Qt.Key_Escape:
            if self.flyout.isVisible():
                self._hide_flyout()
            else:
                self.hide()
            e.accept()
        else:
            super().keyPressEvent(e)

    def mousePressEvent(self, e):
        if self.flyout.isVisible() and not self.flyout.geometry().contains(e.position().toPoint()):
            self._hide_flyout()
        if e.button() == Qt.LeftButton and e.position().y() <= 50.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
        elif e.button() == Qt.RightButton:
            self.hide()
        else:
            super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()
        else:
            super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)
            e.accept()
        else:
            super().mouseReleaseEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        path = QPainterPath()
        path.addRoundedRect(rect, 14.0, 14.0)
        p.fillPath(path, QColor(4, 4, 5, 254))
        p.setPen(QPen(QColor(255, 255, 255, 26), 1.0))
        p.drawPath(path)

        _draw_vector_brand(p, 16.0, 25.0, self.logo_pix, "SUPER", "SNAP", font_pt=11.4)
        p.end()


class _SnipOverlay(QWidget):
    """Fullscreen dimmed desktop snipping overlay with crosshair cursor."""
    snipped = Signal(object, QRect, object)
    cancelled = Signal()

    def __init__(self, parent=None):
        super().__init__(
            parent,
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint,
        )
        self.setAttribute(Qt.WA_TranslucentBackground, False)
        self.setCursor(Qt.CrossCursor)
        self.setMouseTracking(True)

        self._screen = None
        self._screen_pix = None
        self._dpr = 1.0
        self._selecting = False
        self._origin = QPoint()
        self._current = QPoint()

    def begin_snip(self):
        cur = QCursor.pos()
        scr = QApplication.screenAt(cur) or QApplication.primaryScreen()
        self._screen = scr
        self._screen_pix = scr.grabWindow(0)
        self._dpr = float(self._screen_pix.devicePixelRatio() or 1.0)
        self._selecting = False
        self._origin = QPoint()
        self._current = QPoint()

        self.setGeometry(scr.geometry())
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

    def _selection_rect(self):
        if not self._selecting:
            return QRect()
        return QRect(self._origin, self._current).normalized().intersected(self.rect())

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self._selecting = False
            self.hide()
            self.cancelled.emit()
            e.accept()
        else:
            super().keyPressEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._selecting = True
            self._origin = e.position().toPoint()
            self._current = self._origin
            self.update()
            e.accept()
        elif e.button() == Qt.RightButton:
            self._selecting = False
            self.hide()
            self.cancelled.emit()
            e.accept()

    def mouseMoveEvent(self, e):
        if self._selecting:
            self._current = e.position().toPoint()
            self.update()
            e.accept()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._selecting:
            self._current = e.position().toPoint()
            sel = self._selection_rect()
            self._selecting = False
            self.hide()

            if sel.width() >= 10 and sel.height() >= 10 and self._screen_pix:
                dpr = self._dpr
                src = QRect(
                    int(round(sel.x() * dpr)),
                    int(round(sel.y() * dpr)),
                    max(1, int(round(sel.width() * dpr))),
                    max(1, int(round(sel.height() * dpr))),
                )
                cropped = self._screen_pix.copy(src)
                cropped.setDevicePixelRatio(dpr)
                global_rect = QRect(self.mapToGlobal(sel.topLeft()), sel.size())
                self.snipped.emit(cropped, global_rect, self._screen)
            else:
                self.cancelled.emit()
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        if self._screen_pix and not self._screen_pix.isNull():
            p.drawPixmap(self.rect(), self._screen_pix)

        p.fillRect(self.rect(), QColor(0, 0, 0, 128))

        sel = self._selection_rect()
        if not sel.isEmpty() and sel.width() >= 2 and sel.height() >= 2 and self._screen_pix:
            dpr = self._dpr
            src = QRectF(sel.x() * dpr, sel.y() * dpr, sel.width() * dpr, sel.height() * dpr)
            p.drawPixmap(QRectF(sel), self._screen_pix, src)

            p.setPen(QPen(QColor("#a3e635"), 1.6))
            p.drawRect(QRectF(sel.x() + 0.5, sel.y() + 0.5, sel.width() - 1.0, sel.height() - 1.0))

            dim_txt = f"{int(round(sel.width() * dpr))} × {int(round(sel.height() * dpr))}"
            f_d = QFont("Segoe UI Variable", 8, QFont.Bold)
            p.setFont(f_d)
            tw = QFontMetrics(f_d).horizontalAdvance(dim_txt) + 14
            dy = sel.top() - 24 if sel.top() > 30 else sel.bottom() + 6
            dx = max(8, min(self.width() - tw - 8, sel.left()))
            dp = QPainterPath()
            dp.addRoundedRect(QRectF(dx, dy, tw, 18), 5.0, 5.0)
            p.fillPath(dp, QColor(5, 5, 6, 235))
            p.setPen(QPen(QColor(163, 230, 53, 140), 0.9))
            p.drawPath(dp)
            p.setPen(QColor("#a3e635"))
            p.drawText(QRect(dx, dy, tw, 18), Qt.AlignCenter, dim_txt)
        else:
            hint = "Drag to snip area  •  Esc to cancel"
            fh = QFont("Segoe UI Variable", 9, QFont.DemiBold)
            p.setFont(fh)
            hw = QFontMetrics(fh).horizontalAdvance(hint) + 28
            hr = QRectF((self.width() - hw) * 0.5, 22.0, hw, 30.0)
            hp = QPainterPath()
            hp.addRoundedRect(hr, 8.0, 8.0)
            p.fillPath(hp, QColor(5, 5, 6, 235))
            p.setPen(QPen(QColor(163, 230, 53, 130), 1.0))
            p.drawPath(hp)
            p.setPen(QColor("#E4E4E7"))
            p.drawText(hr, Qt.AlignCenter, hint)

        p.end()


class _CloseCircleBtn(CleanCloseButton):
    """Unified borderless common Cross ('X') close button across SuperPin/MyBox."""

    def __init__(self, tip="Close", parent=None):
        super().__init__(tip=tip, box_size=30, icon_size=15, parent=parent)


# ──────────────────────────────────────────────────────────────────────────────
#  MY BOX - BLACK SHOWCASE GALLERY (ChatGPT-Style Dates + Dynamic Search)
# ──────────────────────────────────────────────────────────────────────────────

class _PinLightboxDialog(QDialog):
    """Pure #040405 enlarged preview viewer when clicking any Pin inside MY BOX."""

    def __init__(self, image_path, title_text, parent=None):
        super().__init__(parent, Qt.FramelessWindowHint | Qt.Dialog | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.image_path = image_path
        self._pix = QPixmap(image_path)

        scr = (QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry()
        max_w = min(int(scr.width() * 0.78), max(480, self._pix.width() + 48))
        max_h = min(int(scr.height() * 0.80), max(350, self._pix.height() + 124))
        self.resize(max_w, max_h)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(10)

        hdr = QHBoxLayout()
        lbl = QLabel(title_text, self)
        lbl.setStyleSheet(
            "color: #F4F4F5; font-size: 13px; font-weight: 700; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; background: transparent;"
        )
        hdr.addWidget(lbl)
        hdr.addStretch()
        btn_x = _CloseCircleBtn("Close Preview", self)
        btn_x.clicked.connect(self.close)
        hdr.addWidget(btn_x)
        lay.addLayout(hdr)

        img_lbl = QLabel(self)
        img_lbl.setAlignment(Qt.AlignCenter)
        if not self._pix.isNull():
            dpr = _native_dpr(self)
            tw = int(round((max_w - 40) * dpr))
            th = int(round((max_h - 118) * dpr))
            src_img = self._pix.toImage()
            if src_img.width() > tw or src_img.height() > th:
                src_img = src_img.scaled(tw, th, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            scaled = QPixmap.fromImage(src_img)
            scaled.setDevicePixelRatio(dpr)
            img_lbl.setPixmap(scaled)
        img_lbl.setStyleSheet("background: #080809; border: 1px solid rgba(255,255,255,0.08); border-radius: 10px;")
        lay.addWidget(img_lbl, stretch=1)

        foot = QHBoxLayout()
        foot.setSpacing(8)
        foot.addStretch()
        b_copy = _ActionPillButton("Copy Image", _LUCIDE_PIN_ICONS["copy_fill"], primary=True, parent=self)
        b_copy.clicked.connect(lambda: (copy_pixmap_to_clipboard(self._pix, int(self.winId())), self.close()))
        b_save = _ActionPillButton("Save to Desktop", _LUCIDE_PIN_ICONS["save"], parent=self)
        b_save.clicked.connect(self._save_desktop)
        foot.addWidget(b_copy)
        foot.addWidget(b_save)
        lay.addLayout(foot)

    def _save_desktop(self):
        if not self._pix.isNull():
            out_fp = os.path.join(get_desktop_dir(), f"SuperSnap_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
            self._pix.save(out_fp, "PNG")
        self.close()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        rect = QRectF(0.6, 0.6, self.width() - 1.2, self.height() - 1.2)
        path = QPainterPath()
        path.addRoundedRect(rect, 14.0, 14.0)
        p.fillPath(path, QColor(4, 4, 5, 253))
        p.setPen(QPen(QColor(255, 255, 255, 34), 1.0))
        p.drawPath(path)
        p.end()


class _HeaderIconBtn(CleanHeaderIconButton):
    """Unified borderless fixed-size header slot (invisible box at rest, crisp common icon)."""

    def __init__(self, icon_key, tip_text="", parent=None):
        super().__init__(icon_key=icon_key, tip_text=tip_text, box_size=32, icon_size=16, on_press_tick=_play_asmr_tick, parent=parent)


class _HeaderTakeSnapBtn(QWidget):
    """Refined obsidian Take Snap pill with common Lucide scissors icon + crisp label."""
    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(104, 30)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Take a new Snap right away")
        self._h = 0.0
        self._t = 0.0
        self._press = 0.0
        self._tm = QTimer(self)
        self._tm.setInterval(16)
        self._tm.timeout.connect(self._step)

    def _step(self):
        act = False
        if abs(self._t - self._h) >= 0.008:
            self._h += (self._t - self._h) * 0.25
            act = True
        else:
            self._h = self._t
        if self._press > 0.01:
            self._press *= 0.80
            act = True
        else:
            self._press = 0.0
        self.update()
        if not act:
            self._tm.stop()

    def enterEvent(self, e):
        self._t = 1.0
        if not self._tm.isActive():
            self._tm.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._t = 0.0
        if not self._tm.isActive():
            self._tm.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            self._press = 1.0
            if not self._tm.isActive():
                self._tm.start()
            self.clicked.emit()
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        hv = self._h
        sc = 1.0 - self._press * 0.04
        p.save()
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        path = QPainterPath()
        path.addRoundedRect(QRectF(0.5, 0.5, w - 1.0, h - 1.0), 8.5, 8.5)
        p.fillPath(path, QColor(int(18 + hv * 10), int(19 + hv * 12), int(23 + hv * 8), 255))
        rim_col = QColor(
            int(255 * (1.0 - hv) + 163 * hv),
            int(255 * (1.0 - hv) + 230 * hv),
            int(255 * (1.0 - hv) + 53 * hv),
            int(26 + hv * 120),
        )
        p.setPen(QPen(rim_col, 1.0))
        p.drawPath(path)

        pix = _render_lucide_pix("take_snap", "#a3e635" if hv > 0.2 else "#E4E4E7", 15, dpr=_native_dpr(self))
        p.drawPixmap(10, int(round((h - 15) * 0.5)), pix)

        f = QFont("Segoe UI Variable")
        f.setStyleName("Text Semibold")
        f.setPointSizeF(8.8)
        _draw_crisp_text(
            p, QRectF(30.0, 0.0, w - 38.0, h), False, f,
            QColor("#FFFFFF") if hv > 0.3 else QColor("#E4E4E7"), "Take Snap",
        )
        p.restore()
        p.end()


class _FormatModeBar(QWidget):
    """
    Minimalist borderless view toggle (invisible icon slots, original 16px vector icons,
    subtle active indicator underline — zero boxy neon outlines!):
      - 'complete': Complete Show (grid view of all snaps nicely)
      - 'oneline':  One-Line Scroll (each date renders in one horizontal scrollable row)
    """
    mode_changed = Signal(str)

    def __init__(self, initial_mode="complete", parent=None):
        super().__init__(parent)
        self.mode = initial_mode
        self._hover = None
        self.setFixedSize(68, 34)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)

    def _rect_complete(self):
        return QRectF(0.0, 1.0, 32.0, 32.0)

    def _rect_oneline(self):
        return QRectF(36.0, 1.0, 32.0, 32.0)

    def mouseMoveEvent(self, e):
        pos = e.position()
        nh = "complete" if self._rect_complete().contains(pos) else ("oneline" if self._rect_oneline().contains(pos) else None)
        if nh != self._hover:
            self._hover = nh
            if nh == "complete":
                self.setToolTip("Complete Show — display all Snaps nicely")
            elif nh == "oneline":
                self.setToolTip("One-Line Scroll — horizontal row per date")
            self.update()

    def leaveEvent(self, e):
        self._hover = None
        self.update()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            pos = e.position()
            nm = "complete" if self._rect_complete().contains(pos) else ("oneline" if self._rect_oneline().contains(pos) else None)
            if nm and nm != self.mode:
                _play_asmr_tick()
                self.mode = nm
                self.update()
                self.mode_changed.emit(nm)
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        dpr = _native_dpr(self)
        for key, rect, ico in (
            ("complete", self._rect_complete(), "grid"),
            ("oneline", self._rect_oneline(), "oneline"),
        ):
            active = self.mode == key
            hov = self._hover == key
            if hov and not active:
                hp = QPainterPath()
                hp.addRoundedRect(rect.adjusted(2.0, 2.0, -2.0, -2.0), 8.0, 8.0)
                p.fillPath(hp, QColor(255, 255, 255, 16))
            col = "#FFFFFF" if active else ("#D4D4D8" if hov else "#71717A")
            pix = _render_lucide_pix(ico, col, 16, dpr=dpr)
            p.drawPixmap(int(round(rect.center().x() - 8.0)), int(round(rect.center().y() - 9.0)), pix)
            if active:
                bar = QPainterPath()
                bar.addRoundedRect(QRectF(rect.center().x() - 6.0, rect.bottom() - 4.0, 12.0, 2.0), 1.0, 1.0)
                p.fillPath(bar, QColor("#a3e635"))
        p.end()


class _HorizontalSnapStrip(QScrollArea):
    """Smooth wheel-enabled single-row horizontal container for One-Line Scroll format."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setFixedHeight(208)
        self.setStyleSheet(SLIM_SCROLLBAR_QSS)
        self.inner = QWidget()
        self.row_lay = QHBoxLayout(self.inner)
        self.row_lay.setContentsMargins(0, 0, 0, 8)
        self.row_lay.setSpacing(18)
        self.row_lay.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.setWidget(self.inner)

    def wheelEvent(self, e):
        sb = self.horizontalScrollBar()
        if sb.maximum() > 0:
            delta = e.angleDelta().y() or e.angleDelta().x()
            sb.setValue(sb.value() - delta)
            e.accept()
            return
        super().wheelEvent(e)


class _FramelessSnapTile(QWidget):
    """
    Open-Canvas Native-DPR Sharp Showcase Tile inside MY BOX (ZERO outer grey box container!):
      - Exact 1:1 native-DPR single-pass QImage sharp rounded thumbnail (zero 2x->1x blur)
      - Filled hover pill dock with Copy, SuperShare & Delete
      - Crisp '#X' snap number badge + logical editable name + filled pencil Edit button + timestamp
    """
    clicked = Signal(str, str)
    copy_clicked = Signal(str)
    supershare_clicked = Signal(str)
    delete_clicked = Signal(str)
    renamed = Signal(str, str)

    TILE_W = 224
    IMG_H = 132
    TILE_H = 188

    def __init__(self, image_path, dt, snap_num, snap_name, title_label, parent=None):
        super().__init__(parent)
        self.image_path = image_path
        self.dt = dt
        self.snap_num = snap_num
        self.snap_name = snap_name
        self.title_label = title_label
        self.time_str = dt.strftime("%I:%M %p").lstrip("0")

        self.setFixedSize(self.TILE_W, self.TILE_H)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)

        self._h = 0.0
        self._target = 0.0
        self._hover_btn = None  # 'copy' | 'share' | 'delete' | 'edit' | None
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

        # Inline name editor (hidden until pencil clicked / double click on title)
        self._edit_box = QLineEdit(self)
        self._edit_box.setVisible(False)
        self._edit_box.setMaxLength(44)
        self._edit_box.setStyleSheet(
            "QLineEdit { background-color: #111610; color: #FFFFFF; border: 1px solid #a3e635; "
            "border-radius: 6px; padding: 1px 6px; font-size: 11px; font-weight: 600; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
        )
        self._edit_box.textEdited.connect(lambda _t: _play_asmr_tick())
        self._edit_box.returnPressed.connect(self._commit_rename)
        self._edit_box.editingFinished.connect(self._commit_rename)

        # Native display DPR 1:1 thumbnail (avoids bilinear 2x -> 1x downsampling blur)
        self._dpr = _native_dpr(self)
        self._rendered_img = self._build_sharp_pixmap(image_path, self._dpr)

    def _build_sharp_pixmap(self, fp, dpr=1.0):
        src_img = QImage(fp)
        if src_img.isNull():
            return QPixmap()
        tw = max(1, int(round(self.TILE_W * dpr)))
        th = max(1, int(round(self.IMG_H * dpr)))
        out = QImage(tw, th, QImage.Format_ARGB32_Premultiplied)
        out.fill(QColor(8, 9, 11))

        sw, sh = src_img.width(), src_img.height()
        src_ratio = sw / max(1.0, float(sh))
        tgt_ratio = self.TILE_W / float(self.IMG_H)
        rel = src_ratio / tgt_ratio
        p = QPainter(out)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        if sw <= tw and sh <= th and 0.65 <= rel <= 1.85:
            # Small snap: draw cleanly centered at 1:1 without upscaling blur
            dx = (tw - sw) // 2
            dy = (th - sh) // 2
            p.drawImage(dx, dy, src_img)
        elif 0.62 <= rel <= 1.9:
            scaled = src_img.scaled(tw, th, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            sx = max(0, (scaled.width() - tw) // 2)
            sy = max(0, (scaled.height() - th) // 2)
            p.drawImage(0, 0, scaled, sx, sy, tw, th)
        else:
            scaled = src_img.scaled(tw, th, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            dx = (tw - scaled.width()) // 2
            dy = (th - scaled.height()) // 2
            p.drawImage(dx, dy, scaled)
        p.end()

        pix = QPixmap.fromImage(out)
        pix.setDevicePixelRatio(dpr)
        return pix

    def _action_rects(self):
        # Strictly placed in the BOTTOM metadata strip below the image (never overlapping image!)
        bw, bh, gap = 26.0, 24.0, 2.0
        x0 = float(self.width()) - (bw * 3.0 + gap * 2.0)
        y0 = float(self.IMG_H) + 30.0
        return (
            QRectF(x0, y0, bw, bh),
            QRectF(x0 + bw + gap, y0, bw, bh),
            QRectF(x0 + (bw + gap) * 2.0, y0, bw, bh),
        )

    def _rect_edit(self):
        return QRectF(self.width() - 24.0, float(self.IMG_H) + 6.0, 24.0, 22.0)

    def _begin_rename(self):
        self._edit_box.setGeometry(40, self.IMG_H + 6, self.width() - 44, 22)
        self._edit_box.setText(self.snap_name)
        self._edit_box.setVisible(True)
        self._edit_box.selectAll()
        self._edit_box.setFocus()

    def _commit_rename(self):
        if not self._edit_box.isVisible():
            return
        new_txt = self._edit_box.text().strip()
        self._edit_box.setVisible(False)
        if new_txt and new_txt != self.snap_name:
            self.snap_name = new_txt
            rename_snap_meta(self.image_path, new_txt)
            self.title_label = f"#{self.snap_num} · {new_txt}"
            self.renamed.emit(self.image_path, new_txt)
        self.update()

    def _step(self):
        if abs(self._target - self._h) < 0.008:
            self._h = self._target
            self._timer.stop()
        else:
            self._h += (self._target - self._h) * 0.25
        self.update()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        self._hover_btn = None
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mouseMoveEvent(self, e):
        pos = e.position()
        nh = None
        if self._rect_edit().contains(pos):
            nh = "edit"
        elif self._h > 0.22 and pos.y() >= self.IMG_H:
            rc, rs, rd = self._action_rects()
            if rc.contains(pos):
                nh = "copy"
            elif rs.contains(pos):
                nh = "share"
            elif rd.contains(pos):
                nh = "delete"
        if nh != self._hover_btn:
            self._hover_btn = nh
            tips = {
                "copy": "Copy Snap",
                "share": "SuperShare (Coming Soon)",
                "delete": "Delete Snap",
                "edit": "Rename Snap",
            }
            self.setToolTip(tips.get(nh, ""))
            self.update()
        super().mouseMoveEvent(e)

    def mouseDoubleClickEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() >= self.IMG_H:
            self._begin_rename()
            e.accept()
            return
        super().mouseDoubleClickEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            pos = e.position()
            if self._rect_edit().contains(pos):
                self._begin_rename()
                e.accept()
                return
            if self._h > 0.18 and pos.y() >= self.IMG_H:
                rc, rs, rd = self._action_rects()
                if rc.contains(pos):
                    _play_asmr_tick()
                    self.copy_clicked.emit(self.image_path)
                    e.accept()
                    return
                if rs.contains(pos):
                    _play_asmr_tick()
                    self.supershare_clicked.emit(self.image_path)
                    e.accept()
                    return
                if rd.contains(pos):
                    _play_asmr_tick()
                    self.delete_clicked.emit(self.image_path)
                    e.accept()
                    return
            if pos.y() <= self.IMG_H:
                self.clicked.emit(self.image_path, self.title_label)
                e.accept()
                return

    def paintEvent(self, e):
        cur_dpr = _native_dpr(self)
        if abs(cur_dpr - self._dpr) > 0.05:
            self._dpr = cur_dpr
            self._rendered_img = self._build_sharp_pixmap(self.image_path, cur_dpr)

        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w = float(self.width())
        hv = self._h

        # 1. Pure Unobstructed Crystal-Clear Image Surface (ZERO overlay icons, ZERO neon box!)
        img_rect = QRectF(0.5, 0.5, w - 1.0, self.IMG_H - 1.0)
        img_path = QPainterPath()
        img_path.addRoundedRect(img_rect, 11.0, 11.0)

        p.save()
        p.setClipPath(img_path)
        if not self._rendered_img.isNull():
            p.drawPixmap(0, 0, self._rendered_img)
        p.restore()

        # Calm obsidian hairline perimeter gently brightening to clean neutral pearl on hover
        rim_col = QColor(255, 255, 255, int(20 + hv * 58))
        p.setPen(QPen(rim_col, 1.0))
        p.drawPath(img_path)

        # 2. Restrained Neutral Index Tag ('#4' calm slate/zinc — zero bright green glare!)
        num_txt = f"#{self.snap_num}"
        f_num = QFont("Segoe UI Variable")
        f_num.setStyleName("Text Semibold")
        f_num.setPointSizeF(7.8)
        f_num.setHintingPreference(QFont.PreferNoHinting)
        num_w = max(28.0, float(QFontMetrics(f_num).horizontalAdvance(num_txt)) + 10.0)
        nr = QRectF(1.0, float(self.IMG_H) + 8.0, num_w, 17.0)
        np = QPainterPath()
        np.addRoundedRect(nr, 4.5, 4.5)
        p.fillPath(np, QColor(255, 255, 255, int(11 + hv * 11)))
        p.setPen(QPen(QColor(255, 255, 255, int(18 + hv * 24)), 0.75))
        p.drawPath(np)
        _draw_crisp_text(p, nr, True, f_num, QColor("#D4D4D8") if hv > 0.35 else QColor("#8E94A0"), num_txt)

        if not self._edit_box.isVisible():
            f_name = QFont("Segoe UI Variable")
            f_name.setStyleName("Text Semibold")
            f_name.setPointSizeF(9.3)
            f_name.setHintingPreference(QFont.PreferNoHinting)
            name_x = int(round(nr.right() + 7))
            name_rect = QRectF(float(name_x), float(self.IMG_H) + 6.5, w - name_x - 26.0, 20.0)
            elided = QFontMetrics(f_name).elidedText(self.snap_name, Qt.ElideRight, int(name_rect.width()))
            _draw_crisp_text(
                p, name_rect, False, f_name,
                QColor("#FFFFFF") if hv > 0.3 else QColor("#F4F4F5"), elided,
            )

            # Borderless Pencil Rename Icon inside invisible 24x22 hit-box
            er = self._rect_edit()
            ecol = "#FFFFFF" if self._hover_btn == "edit" else ("#B4BAC5" if hv > 0.25 else "#6E737D")
            epix = _render_lucide_pix("pencil", ecol, 13, dpr=cur_dpr)
            p.drawPixmap(int(round(er.center().x() - 6.5)), int(round(er.center().y() - 6.5)), epix)

        # 3. Bottom Strip Below Image: Calm Timestamp Left + Hover Action Icons Right
        f_time = QFont("Segoe UI Variable")
        f_time.setStyleName("Text Semibold")
        f_time.setPointSizeF(8.0)
        _draw_crisp_text(
            p, QRectF(2.0, float(self.IMG_H) + 32.0, w - 92.0, 18.0), False, f_time,
            QColor("#9CA3AF") if hv > 0.3 else QColor("#686D76"), self.time_str,
        )

        if hv > 0.02:
            p.save()
            p.setOpacity(hv)
            rc, rs, rd = self._action_rects()
            for key, rect, ico, col_idle, col_hov in (
                ("copy",   rc, "copy",       "#9CA3AF", "#a3e635"),
                ("share",  rs, "supershare", "#9CA3AF", "#FFFFFF"),
                ("delete", rd, "trash",      "#9CA3AF", "#F87171"),
            ):
                active = self._hover_btn == key
                col = col_hov if active else col_idle
                pix = _render_lucide_pix(ico, col, 14, dpr=cur_dpr)
                p.drawPixmap(int(round(rect.center().x() - 7.0)), int(round(rect.center().y() - 7.0)), pix)
            p.restore()
        p.end()


class MyBoxWindow(QWidget):
    """
    Sharp Pure-Black 'MY BOX' Showcase Window:
      - Header navigation: Back, Main Menu, vector 'MY BOX' brand, Take Snap, '{n} SNAP's', Close X
      - Dynamic real-time Search Bar + Icon-Only Format Switcher (Complete Show vs One-Line Scroll)
      - Frameless sharp images with '#XXXX' logical snap number, inline pencil rename & hover dock (Copy/SuperShare/Delete)
    """

    def __init__(
        self,
        status_popup=None,
        on_count_changed=None,
        on_back=None,
        on_main_menu=None,
        on_take_snap=None,
        parent=None,
    ):
        super().__init__(parent)
        self.status_popup = status_popup or _StatusPopup()
        self.on_count_changed = on_count_changed
        self.on_back = on_back
        self.on_main_menu = on_main_menu
        self.on_take_snap = on_take_snap
        self.view_mode = "complete"  # 'complete' | 'oneline'

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.resize(766, 588)
        from ui_theme import apply_window_identity
        apply_window_identity(self, "TheSuperMouse - My Box")

        ensure_box_dir()
        self._dragging = False
        self._drag_offset = QPoint()

        base_assets = os.path.join(BASE_DIR, "thesupermouse", "assets")
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        self._raw_logo = QImage(logo_fp) if os.path.exists(logo_fp) else None
        if self._raw_logo and not self._raw_logo.isNull():
            ldpr = _native_dpr(self)
            l_img = self._raw_logo.scaledToHeight(max(20, int(round(20 * ldpr))), Qt.SmoothTransformation)
            self.logo_pix = QPixmap.fromImage(l_img)
            self.logo_pix.setDevicePixelRatio(ldpr)
        else:
            self.logo_pix = None

        self._build_ui()
        self.refresh_gallery()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # 1. Header Navigation Bar (Back, Home | MY BOX | Take Snap, Count, Close)
        header = QWidget(self)
        header.setFixedHeight(54)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(14, 0, 14, 0)
        hdr.setSpacing(2)

        self.btn_back = _HeaderIconBtn("back", "Back", header)
        self.btn_back.clicked.connect(self._go_back)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)

        self.btn_menu = _HeaderIconBtn("home", "Main Menu", header)
        self.btn_menu.clicked.connect(self._go_main_menu)
        hdr.addWidget(self.btn_menu, alignment=Qt.AlignVCenter)

        hdr.addStretch()

        self.lbl_total = QLabel("0 Snaps", header)
        self.lbl_total.setStyleSheet(
            "color: #848A95; background: transparent; border: none; "
            "padding: 2px 6px; font-size: 11px; font-weight: 600; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        hdr.addWidget(self.lbl_total, alignment=Qt.AlignVCenter)
        hdr.addSpacing(4)

        self.btn_take_snap = _HeaderTakeSnapBtn(header)
        self.btn_take_snap.clicked.connect(self._trigger_take_snap)
        hdr.addWidget(self.btn_take_snap, alignment=Qt.AlignVCenter)
        hdr.addSpacing(4)

        self.btn_close = _CloseCircleBtn("Close My Box", header)
        self.btn_close.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(self.btn_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        # 2. Search + Borderless View Mode Icons Row
        ctrl_wrap = QWidget(self)
        ctrl_wrap.setFixedHeight(50)
        cw_lay = QHBoxLayout(ctrl_wrap)
        cw_lay.setContentsMargins(18, 4, 18, 10)
        cw_lay.setSpacing(10)

        self.search_box = QFrame(ctrl_wrap)
        self.search_box.setFixedHeight(34)
        self.search_box.setStyleSheet(
            "QFrame { background-color: #0B0C0F; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 10px; }"
            "QFrame:focus-within { border-color: rgba(163, 230, 53, 0.45); background-color: #0F1114; }"
        )
        sb_lay = QHBoxLayout(self.search_box)
        sb_lay.setContentsMargins(12, 0, 8, 0)
        sb_lay.setSpacing(8)

        s_ico = QLabel(self.search_box)
        s_ico.setPixmap(_render_lucide_pix("search", "#71717A", 14, dpr=_native_dpr(self)))
        s_ico.setStyleSheet("background: transparent; border: none;")
        sb_lay.addWidget(s_ico)

        self.search_input = QLineEdit(self.search_box)
        self.search_input.setPlaceholderText("Search Snaps by name, #number, Today, Yesterday...")
        self.search_input.setStyleSheet(
            "QLineEdit { background: transparent; border: none; color: #F4F4F5; "
            "font-size: 12px; font-weight: 500; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
        )
        self.search_input.textEdited.connect(lambda _t: _play_asmr_tick())
        self.search_input.textChanged.connect(self._on_search_changed)
        sb_lay.addWidget(self.search_input, stretch=1)

        self.btn_clear_search = QPushButton("", self.search_box)
        self.btn_clear_search.setFixedSize(22, 22)
        self.btn_clear_search.setIcon(QIcon(_render_lucide_pix("close", "#A1A7B3", 12, dpr=_native_dpr(self))))
        self.btn_clear_search.setIconSize(QSize(12, 12))
        self.btn_clear_search.setCursor(Qt.PointingHandCursor)
        self.btn_clear_search.setVisible(False)
        self.btn_clear_search.setStyleSheet(
            "QPushButton { background: transparent; border: none; border-radius: 11px; }"
            "QPushButton:hover { background: rgba(255,255,255,0.08); }"
        )
        self.btn_clear_search.clicked.connect(self.search_input.clear)
        sb_lay.addWidget(self.btn_clear_search)

        cw_lay.addWidget(self.search_box, stretch=1)

        self.format_bar = _FormatModeBar(initial_mode=self.view_mode, parent=ctrl_wrap)
        self.format_bar.mode_changed.connect(self._on_mode_changed)
        cw_lay.addWidget(self.format_bar)
        root.addWidget(ctrl_wrap)

        div = QFrame(self)
        div.setFixedHeight(1)
        div.setStyleSheet("background-color: rgba(255, 255, 255, 0.06); margin: 0px 18px;")
        root.addWidget(div)

        # 3. Date Showcase Scroll Canvas (Slim Translucent Pill Scrollbar)
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet(SLIM_SCROLLBAR_QSS)
        self.content = QWidget()
        self.content_lay = QVBoxLayout(self.content)
        self.content_lay.setContentsMargins(18, 14, 18, 18)
        self.content_lay.setSpacing(16)
        self.content_lay.setAlignment(Qt.AlignTop)
        self.scroll.setWidget(self.content)
        root.addWidget(self.scroll, stretch=1)

    def _go_back(self):
        if callable(self.on_back):
            self.switch_out_asmr_animation(on_finished=self.on_back)
        else:
            self.close_with_pull_animation()

    def _go_main_menu(self):
        if callable(self.on_main_menu):
            self.switch_out_asmr_animation(on_finished=self.on_main_menu)
        elif callable(self.on_back):
            self.switch_out_asmr_animation(on_finished=self.on_back)
        else:
            self.close_with_pull_animation()

    def _trigger_take_snap(self):
        if callable(self.on_take_snap):
            self.switch_out_asmr_animation(on_finished=lambda: QTimer.singleShot(55, self.on_take_snap))

    def _on_mode_changed(self, mode):
        self.view_mode = mode
        self.refresh_gallery(self.search_input.text())

    def _on_search_changed(self, text):
        self.btn_clear_search.setVisible(bool(text.strip()))
        self.refresh_gallery(text)

    @staticmethod
    def _group_label_for_dt(dt, now_dt=None):
        now_dt = now_dt or datetime.now()
        d = dt.date()
        today = now_dt.date()
        yesterday = today - timedelta(days=1)
        if d == today:
            return "Today"
        if d == yesterday:
            return "Yesterday"
        return dt.strftime("%b %d, %Y")

    def _fit_window_height_for_complete(self, groups, group_map):
        scr = (QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry()
        max_h = int(scr.height() * 0.85)
        if not groups:
            target_h = 440
        elif self.view_mode == "oneline":
            target_h = min(max_h, max(440, 126 + len(groups) * 234))
        else:
            total_h = 126
            for gl in groups:
                rows = max(1, (len(group_map[gl]) + 2) // 3)
                total_h += 38 + rows * (_FramelessSnapTile.TILE_H + 16)
            target_h = min(max_h, max(420, total_h))
        self.resize(766, target_h)

    def refresh_gallery(self, query=""):
        while self.content_lay.count():
            it = self.content_lay.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)
                w.deleteLater()

        entries = list_box_entries()
        self.lbl_total.setText(format_count_label(len(entries), "Snap", "Snaps"))

        q = (query or "").strip().lower()
        now_dt = datetime.now()
        groups = []
        group_map = {}

        for item in entries:
            dt = item["dt"]
            glabel = self._group_label_for_dt(dt, now_dt=now_dt)
            snum = item["snap_num"]
            sname = item["snap_name"]
            searchable = " ".join([
                glabel.lower(),
                dt.strftime("%B %d %Y %A %I:%M %p %H:%M").lower(),
                f"#{snum}",
                str(snum),
                sname.lower(),
                "snap",
            ])
            if q and q not in searchable:
                continue

            if glabel not in group_map:
                group_map[glabel] = []
                groups.append(glabel)
            group_map[glabel].append((
                item["path"],
                dt,
                snum,
                sname,
                f"#{snum} · {sname}  ({glabel} {dt.strftime('%I:%M %p').lstrip('0')})",
            ))

        self._fit_window_height_for_complete(groups, group_map)

        if not groups:
            empty = QWidget(self.content)
            el = QVBoxLayout(empty)
            el.setContentsMargins(0, 76, 0, 40)
            el.setAlignment(Qt.AlignCenter)
            el.setSpacing(10)
            ico = QLabel(empty)
            ico.setPixmap(_render_lucide_pix("my_box", "#787E88", 38, dpr=_native_dpr(self)))
            ico.setAlignment(Qt.AlignCenter)
            el.addWidget(ico)
            msg = QLabel("No matching Snaps found" if q else "Your Box has 0 Snaps yet", empty)
            msg.setStyleSheet(
                "color: #F4F4F5; font-size: 14px; font-weight: 700; "
                "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; background: transparent;"
            )
            msg.setAlignment(Qt.AlignCenter)
            sub = QLabel(
                "Try '#number', snap name, 'Today', 'Yesterday', or clear search."
                if q else "Click Take Snap above to capture & store Snaps cleanly here.",
                empty,
            )
            sub.setStyleSheet(
                "color: #848A95; font-size: 11.5px; "
                "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; background: transparent;"
            )
            sub.setAlignment(Qt.AlignCenter)
            el.addWidget(msg)
            el.addWidget(sub)
            self.content_lay.addWidget(empty)
            return

        for glabel in groups:
            items = group_map[glabel]
            sec = QWidget(self.content)
            sl = QVBoxLayout(sec)
            sl.setContentsMargins(0, 0, 0, 2)
            sl.setSpacing(10)

            # Clean Editorial Date Header (Today / Yesterday / Date)
            hdr_row = QHBoxLayout()
            hdr_row.setSpacing(6)
            lbl_g = QLabel(glabel, sec)
            lbl_g.setStyleSheet(
                "color: #F4F4F5; font-size: 12.5px; font-weight: 700; letter-spacing: 0.25px; "
                "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; background: transparent;"
            )
            hdr_row.addWidget(lbl_g)

            cnt_lbl = QLabel(f"·  {format_count_label(len(items), 'snap', 'snaps')}", sec)
            cnt_lbl.setStyleSheet(
                "color: #6E737D; background: transparent; border: none; "
                "font-size: 11px; font-weight: 500; "
                "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
            )
            hdr_row.addWidget(cnt_lbl)

            line = QFrame(sec)
            line.setFixedHeight(1)
            line.setStyleSheet("background-color: rgba(255, 255, 255, 0.06);")
            hdr_row.addWidget(line, stretch=1)
            sl.addLayout(hdr_row)

            if self.view_mode == "oneline":
                strip = _HorizontalSnapStrip(sec)
                for fp, dt, snum, sname, title_lbl in items:
                    tile = _FramelessSnapTile(fp, dt, snum, sname, title_lbl, parent=strip.inner)
                    self._connect_tile(tile)
                    strip.row_lay.addWidget(tile)
                sl.addWidget(strip)
            else:
                grid_w = QWidget(sec)
                grid = QGridLayout(grid_w)
                grid.setContentsMargins(0, 0, 0, 0)
                grid.setHorizontalSpacing(18)
                grid.setVerticalSpacing(16)
                grid.setAlignment(Qt.AlignTop | Qt.AlignLeft)
                for idx, (fp, dt, snum, sname, title_lbl) in enumerate(items):
                    tile = _FramelessSnapTile(fp, dt, snum, sname, title_lbl, parent=grid_w)
                    self._connect_tile(tile)
                    grid.addWidget(tile, idx // 3, idx % 3)
                sl.addWidget(grid_w)

            self.content_lay.addWidget(sec)

    def _connect_tile(self, tile: _FramelessSnapTile):
        tile.clicked.connect(self._open_preview)
        tile.copy_clicked.connect(self._copy_pin)
        tile.supershare_clicked.connect(self._on_supershare)
        tile.delete_clicked.connect(self._delete_pin)
        tile.renamed.connect(self._on_snap_renamed)

    def _on_snap_renamed(self, fp, new_name):
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.status_popup.show_message(
            new_name.upper(), _LUCIDE_PIN_ICONS["pencil_fill"], c, badge_text="SNAP RENAMED", duration_ms=1400
        )

    def _on_supershare(self, fp):
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.status_popup.show_message(
            "SUPERSHARE", _LUCIDE_PIN_ICONS["supershare_fill"], c, badge_text="COMING SOON", duration_ms=1700
        )

    def _open_preview(self, fp, title_lbl):
        if os.path.exists(fp):
            dlg = _PinLightboxDialog(fp, title_lbl, parent=self)
            dlg.exec()

    def _copy_pin(self, fp):
        if os.path.exists(fp):
            px = QPixmap(fp)
            copy_pixmap_to_clipboard(px, int(self.winId()) if self.winId() else None)
            c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
            self.status_popup.show_message(
                "SNAP COPIED", _LUCIDE_PIN_ICONS["copy_fill"], c, badge_text="COPIED TO CLIPBOARD", duration_ms=1500
            )

    def _delete_pin(self, fp):
        try:
            if os.path.exists(fp) and os.path.dirname(os.path.abspath(fp)) == os.path.abspath(BOX_DIR):
                os.remove(fp)
            delete_snap_meta(fp)
        except Exception:
            pass
        self.refresh_gallery(self.search_input.text())
        if self.on_count_changed:
            self.on_count_changed()

    def open_window(self):
        self.open_with_spring_animation()

    def open_asmr_switch(self):
        """Quick, silky normal fade-in at center when switching from menus (no vertical slide)."""
        self.refresh_gallery(self.search_input.text())
        screen = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        w, h = self.width(), self.height()
        tx = avail.center().x() - w // 2
        ty = avail.center().y() - h // 2

        self.setGeometry(QRect(tx, ty, w, h))
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(135)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        self.anim_in = af
        self.anim_in.start()

    def switch_out_asmr_animation(self, on_finished=None):
        """Quick, silky normal fade-out when returning to menus (no vertical bounce)."""
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        def _done():
            self.hide()
            if on_finished:
                on_finished()

        af.finished.connect(_done)
        self.anim_out = af
        self.anim_out.start()

    def open_with_spring_animation(self):
        self.refresh_gallery(self.search_input.text())
        screen = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        full = screen.geometry()

        w, h = self.width(), self.height()
        tx = avail.center().x() - w // 2
        ty = avail.center().y() - h // 2
        target_geom = QRect(tx, ty, w, h)
        start_geom = QRect(tx, full.bottom() + 20, w, h)

        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(400)
        ag.setStartValue(start_geom)
        ag.setEndValue(target_geom)
        ag.setEasingCurve(QEasingCurve.OutCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(330)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        self.anim_in = QParallelAnimationGroup(self)
        self.anim_in.addAnimation(ag)
        self.anim_in.addAnimation(af)
        self.anim_in.start()

    def close_with_pull_animation(self, on_finished=None):
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        screen = QApplication.screenAt(self.pos()) or QApplication.primaryScreen()
        full = screen.geometry()
        curr = self.geometry()
        end_geom = QRect(curr.x(), full.bottom() + 20, curr.width(), curr.height())

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(320)
        ag.setStartValue(curr)
        ag.setEndValue(end_geom)
        ag.setEasingCurve(QEasingCurve.InCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(280)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.InCubic)

        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(ag)
        self.anim_out.addAnimation(af)

        def _done():
            self.hide()
            if on_finished:
                on_finished()

        self.anim_out.finished.connect(_done)
        self.anim_out.start()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 54.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
            return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close_with_pull_animation()
            e.accept()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        card = QPainterPath()
        card.addRoundedRect(rect, 14.0, 14.0)

        p.fillPath(card, QColor(4, 4, 5, 254))
        p.setPen(QPen(QColor(255, 255, 255, 32), 1.0))
        p.drawPath(card)

        # Placed cleanly right of borderless Back (32) + Home (32)
        _draw_vector_brand(p, 88.0, 27.0, self.logo_pix, "MY", "BOX", font_pt=11.8)
        p.end()


# ──────────────────────────────────────────────────────────────────────────────
#  THE SUPER PIN - 4-ITEM HUB WINDOW (Matched 100% to Style #1 / Quick Menu)
# ──────────────────────────────────────────────────────────────────────────────

class _PinMenuItemRow(QWidget):
    """Boxless row matched 1:1 to Quick Menu V6 (Lucide outline + dual hover personality)."""
    clicked = Signal(dict)

    def __init__(self, item_data, idx=0, parent=None):
        super().__init__(parent)
        self.item = item_data
        self.idx = idx
        self._badge_override = None
        self.setFixedHeight(36)
        self.setCursor(Qt.PointingHandCursor)

        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self._shimmer = -0.25
        self._reveal = 1.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def set_badge_text(self, txt):
        self._badge_override = txt
        self.update()

    def start_reveal_animation(self):
        self._reveal = 1.0
        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self.update()

    def _begin_reveal(self):
        self._reveal = 1.0
        self.update()

    def _step(self):
        active = False
        if self._reveal < 1.0:
            self._reveal = min(1.0, self._reveal + 0.11)
            active = True
        if abs(self._target - self._h) >= 0.005:
            self._h += (self._target - self._h) * 0.23
            active = True
        elif self._h != self._target:
            self._h = self._target
        if self._press > 0.01:
            self._press *= 0.80
            active = True
        else:
            self._press = 0.0

        is_soon = bool(self.item.get("coming_soon"))
        if is_soon and (self._target > 0.0 or self._h > 0.02):
            self._shimmer += 0.011
            if self._shimmer > 1.35:
                self._shimmer = -0.25
            active = True
        elif is_soon:
            self._shimmer = -0.25

        self.update()
        if not active and self._reveal >= 1.0 and self._h == self._target and self._press == 0.0:
            self._timer.stop()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._press = 1.0
            if not self._timer.isActive():
                self._timer.start()
            self.clicked.emit(self.item)
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)

        rev = self._reveal
        if rev <= 0.01:
            p.end()
            return

        w, h = float(self.width()), float(self.height())
        hv = self._h
        is_soon = bool(self.item.get("coming_soon"))
        badge_text = self._badge_override if self._badge_override is not None else self.item.get("badge")
        sc = 1.0 - self._press * 0.016

        p.save()
        p.setOpacity(rev)
        p.translate(0.0, (1.0 - rev) * 7.0)
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        pill_rect = QRectF(10.0, 1.5, w - 20.0, h - 3.0)
        pill_path = QPainterPath()
        pill_path.addRoundedRect(pill_rect, 8.5, 8.5)

        if not is_soon:
            if hv > 0.008:
                p.fillPath(pill_path, QColor(18, 26, 15, int(235 * hv)))
                p.setPen(QPen(QColor(163, 230, 53, int(175 * hv)), 1.1))
                p.drawPath(pill_path)

                bar_h = 16.0 * hv
                bp = QPainterPath()
                bp.addRoundedRect(QRectF(10.0, (h - bar_h) * 0.5, 2.5, bar_h), 1.25, 1.25)
                p.fillPath(bp, QColor(163, 230, 53, int(245 * hv)))

            r_c = int(228 * (1.0 - hv) + 163 * hv)
            g_c = int(228 * (1.0 - hv) + 230 * hv)
            b_c = int(231 * (1.0 - hv) + 53 * hv)
            col_hex = f"#{r_c:02x}{g_c:02x}{b_c:02x}"

            ico_s = 16.0
            QSvgRenderer(QByteArray(self.item["svg"].replace("{col}", col_hex).encode("utf-8"))).render(
                p, QRectF(18.0 + hv * 2.5, (h - ico_s) * 0.5, ico_s, ico_s)
            )

            f = QFont("Segoe UI Variable")
            f.setStyleName("Text Semibold" if hv < 0.45 else "Display Bold")
            f.setPointSizeF(9.6)
            text_x = 44.0 + hv * 3.0
            right_m = 72.0 if badge_text else 20.0
            _draw_crisp_text(
                p, QRectF(text_x, 0.0, w - text_x - right_m, h), False, f,
                QColor("#FFFFFF") if hv > 0.3 else QColor("#EDEDEF"), self.item["label"],
            )

            if badge_text:
                pw, ph = 58.0, 15.5
                pr = QRectF(w - 18.0 - pw, (h - ph) * 0.5, pw, ph)
                pp = QPainterPath()
                pp.addRoundedRect(pr, 4.5, 4.5)
                p.fillPath(pp, QColor(163, 230, 53, int(18 + hv * 18)) if hv > 0.2 else QColor(255, 255, 255, 10))
                p.setPen(QPen(QColor(163, 230, 53, int(65 + hv * 95)) if hv > 0.2 else QColor(255, 255, 255, 24), 0.8))
                p.drawPath(pp)
                pf = QFont("Segoe UI Variable")
                pf.setStyleName("Display Bold")
                pf.setPointSizeF(5.6)
                pf.setLetterSpacing(QFont.AbsoluteSpacing, 0.3)
                _draw_crisp_text(p, pr, True, pf, QColor("#a3e635") if hv > 0.2 else QColor("#A1A7B3"), badge_text)
        else:
            if hv > 0.008:
                p.fillPath(pill_path, QColor(255, 255, 255, int(11 * hv)))
                p.setPen(QPen(QColor(255, 255, 255, int(28 * hv)), 0.9))
                p.drawPath(pill_path)

            v_ico = int(146 + hv * 58)
            col_hex = f"#{v_ico:02x}{v_ico:02x}{min(255, v_ico + 5):02x}"
            QSvgRenderer(QByteArray(self.item["svg"].replace("{col}", col_hex).encode("utf-8"))).render(
                p, QRectF(18.0, (h - 15.5) * 0.5, 15.5, 15.5)
            )

            f = QFont("Segoe UI Variable")
            f.setStyleName("Text Semibold")
            f.setPointSizeF(9.4)
            v_txt = int(172 + hv * 48)
            _draw_crisp_text(p, QRectF(44.0, 0.0, w - 44.0 - 84.0, h), False, f, QColor(v_txt, v_txt, v_txt + 4), self.item["label"])

            pill_w, pill_h = 62.0, 15.5
            pr = QRectF(w - 18.0 - pill_w, (h - pill_h) * 0.5, pill_w, pill_h)
            pp = QPainterPath()
            pp.addRoundedRect(pr, 4.5, 4.5)
            p.fillPath(pp, QColor(255, 255, 255, int(8 + hv * 8)))

            beam = self._shimmer
            if hv > 0.02:
                p.save()
                p.setClipPath(pp)
                sh_grad = QLinearGradient(pr.left(), pr.top(), pr.right(), pr.bottom())
                c0, c1, c2 = max(0.0, min(1.0, beam - 0.28)), max(0.0, min(1.0, beam)), max(0.0, min(1.0, beam + 0.28))
                sh_grad.setColorAt(0.0, QColor(255, 255, 255, 0))
                if c0 > 0.0:
                    sh_grad.setColorAt(c0, QColor(255, 255, 255, 0))
                sh_grad.setColorAt(c1, QColor(255, 255, 255, int(52 * hv)))
                if c2 < 1.0:
                    sh_grad.setColorAt(c2, QColor(255, 255, 255, 0))
                sh_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
                p.fillRect(pr, sh_grad)
                p.restore()

            p.setPen(QPen(QColor(255, 255, 255, int(20 + hv * 32)), 0.8))
            p.drawPath(pp)

            pf = QFont("Segoe UI Variable")
            pf.setStyleName("Display Bold")
            pf.setPointSizeF(5.5)
            pf.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
            p.setFont(pf)
            if hv > 0.02:
                tg = QLinearGradient(pr.left(), 0.0, pr.right(), 0.0)
                base_t, peak_t = QColor(142, 146, 154), QColor(255, 255, 255)
                tg.setColorAt(0.0, base_t)
                c0, c1, c2 = max(0.0, min(1.0, beam - 0.26)), max(0.0, min(1.0, beam)), max(0.0, min(1.0, beam + 0.26))
                if c0 > 0.0:
                    tg.setColorAt(c0, base_t)
                tg.setColorAt(c1, peak_t)
                if c2 < 1.0:
                    tg.setColorAt(c2, base_t)
                tg.setColorAt(1.0, base_t)
                p.setPen(QPen(QBrush(tg), 1.0))
            else:
                p.setPen(QColor(134, 138, 146))
            p.drawText(pr, Qt.AlignCenter, "COMING SOON")

        p.restore()
        p.end()


class SuperClipboardWindow(QWidget):
    """
    THE SUPER PIN 4-Item Hub Window (Image-1 / V6 Pure #040405 Style) + Orchestrator
    for Take Snap & My Box Window.
    """

    ITEMS = [
        {"id": "take_snap",      "label": "Take Snap",      "coming_soon": False, "badge": None,          "svg": _LUCIDE_PIN_ICONS["take_snap"]},
        {"id": "text_extractor", "label": "Text Extractor", "coming_soon": True,  "badge": "COMING SOON", "svg": _LUCIDE_PIN_ICONS["text_extractor"]},
        {"id": "store_text",     "label": "Store Text",     "coming_soon": True,  "badge": "COMING SOON", "svg": _LUCIDE_PIN_ICONS["store_text"]},
        {"id": "my_box",         "label": "My Box",         "coming_soon": False, "badge": "0 SAVED",     "svg": _LUCIDE_PIN_ICONS["my_box"]},
    ]

    def __init__(self, on_back_to_menu=None, parent=None):
        super().__init__(parent)
        self.on_back_to_menu = on_back_to_menu
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(316, 252)
        from ui_theme import apply_window_identity
        apply_window_identity(self, "TheSuperMouse - Super Snap & Pin")

        ensure_box_dir()
        self._dragging = False
        self._is_animating = False
        self._drag_offset = QPoint()
        self._rows = {}

        self.status_popup = _StatusPopup()
        self.my_box_window = MyBoxWindow(
            status_popup=self.status_popup,
            on_count_changed=self._refresh_box_count,
            on_back=self.open_asmr_switch,
            on_main_menu=lambda: self.on_back_to_menu() if self.on_back_to_menu else self.open_asmr_switch(),
            on_take_snap=self._start_snip_capture,
        )
        self.edge_popup = GotTheBoxEdgePopup(on_open_box=self.open_my_box_asmr)
        self.snip_overlay = _SnipOverlay()
        self.snip_result = _SnipResultWindow(
            self.status_popup,
            self.edge_popup,
            on_box_updated=self._on_box_saved,
            on_back=self.open_asmr_switch,
            on_main_menu=lambda: self.on_back_to_menu() if self.on_back_to_menu else self.open_asmr_switch(),
        )
        self.snip_overlay.snipped.connect(self.snip_result.show_snap)
        self.snip_overlay.cancelled.connect(self.open_asmr_switch)
        self.snip_result.retake_requested.connect(self._start_snip_capture)

        base_assets = os.path.join(BASE_DIR, "thesupermouse", "assets")
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        self._raw_logo = QImage(logo_fp) if os.path.exists(logo_fp) else None
        if self._raw_logo and not self._raw_logo.isNull():
            ldpr = _native_dpr(self)
            li = self._raw_logo.scaledToHeight(max(20, int(round(20 * ldpr))), Qt.SmoothTransformation)
            self.logo_pix = QPixmap.fromImage(li)
            self.logo_pix.setDevicePixelRatio(ldpr)
        else:
            self.logo_pix = None

        self._build_ui()
        self._refresh_box_count()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Seamless Header (y_c = 26)
        header = QWidget(self)
        header.setFixedHeight(52)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(12, 0, 14, 0)
        self.btn_back = CleanBackButton("Back to Quick Menu", box_size=30, icon_size=15, on_press_tick=_play_asmr_tick, parent=header)
        self.btn_back.clicked.connect(self._go_back_to_menu)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)
        hdr.addStretch()
        self.btn_close = _CloseCircleBtn("Close Super Snap & Pin", header)
        self.btn_close.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(self.btn_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        lbl_sec = QLabel("SNAP TOOLS", self)
        lbl_sec.setStyleSheet(
            "color: rgba(255, 255, 255, 0.42); font-size: 8px; font-weight: 700; "
            "letter-spacing: 1.4px; padding-left: 18px; background: transparent; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        root.addWidget(lbl_sec)
        root.addSpacing(4)

        for idx, item in enumerate(self.ITEMS):
            row = _PinMenuItemRow(item, idx=idx, parent=self)
            row.clicked.connect(self._on_item_clicked)
            root.addWidget(row)
            self._rows[item["id"]] = row

        root.addStretch(1)

        div2 = QFrame(self)
        div2.setFixedHeight(1)
        div2.setStyleSheet("background-color: rgba(255, 255, 255, 0.08); margin: 0px 18px;")
        root.addWidget(div2)

        lbl_ver = QLabel("THE SUPERMOUSE v1.01", self)
        lbl_ver.setAlignment(Qt.AlignCenter)
        lbl_ver.setFixedHeight(22)
        lbl_ver.setStyleSheet(
            "color: rgba(255, 255, 255, 0.34); font-size: 8px; font-weight: 600; "
            "letter-spacing: 0.9px; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        root.addWidget(lbl_ver)
        root.addSpacing(4)

    def _on_box_saved(self):
        self._refresh_box_count()
        if self.my_box_window.isVisible():
            self.my_box_window.refresh_gallery()

    def _refresh_box_count(self):
        n = count_box_items()
        if "my_box" in self._rows:
            self._rows["my_box"].set_badge_text(format_count_label(n, "Snap", "Snaps"))

    def _go_back_to_menu(self):
        self.switch_out_asmr_animation(on_finished=self.on_back_to_menu)

    def _start_snip_capture(self):
        self.snip_overlay.begin_snip()

    def start_snap_directly(self):
        """Invoke Take Snap cleanly from Quick Menu submenu without showing the 4-item window."""
        if self.isVisible():
            self.switch_out_asmr_animation(on_finished=lambda: QTimer.singleShot(55, self._start_snip_capture))
        else:
            QTimer.singleShot(55, self._start_snip_capture)

    def open_my_box(self):
        """Open pure-black MY BOX showcase window cleanly."""
        self.my_box_window.open_window()

    def open_my_box_asmr(self):
        """Open MY BOX with smooth ASMR transition when switching from options."""
        self.my_box_window.open_asmr_switch()

    def _on_item_clicked(self, item):
        oid = item["id"]
        center_pos = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        if oid == "take_snap":
            self.switch_out_asmr_animation(
                on_finished=lambda: QTimer.singleShot(55, self._start_snip_capture)
            )
        elif oid == "my_box":
            self.switch_out_asmr_animation(on_finished=self.open_my_box_asmr)
        else:
            self.status_popup.show_message(
                item["label"].upper(),
                item["svg"],
                center_pos,
                badge_text="COMING SOON",
                duration_ms=2100,
            )

    def _stop_anims(self):
        self._anim_gen = getattr(self, "_anim_gen", 0) + 1
        for attr in ("anim_in", "anim_out"):
            anim = getattr(self, attr, None)
            if anim is not None:
                try:
                    anim.stop()
                except Exception:
                    pass
        self._is_animating = False

    def open_at_cursor(self):
        self.open_with_spring_animation()

    def open_asmr_switch(self):
        """Quick, silky normal fade-in at cursor when switching with Quick Menu (no vertical slide)."""
        self._refresh_box_count()
        self._stop_anims()

        cur = QCursor.pos()
        screen = QApplication.screenAt(cur) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        w, h = self.width(), self.height()
        tx = max(avail.left() + 12, min(avail.right() - w - 12, cur.x() - w // 2))
        ty = max(avail.top() + 14, min(avail.bottom() - h - 14, cur.y() - h // 2))

        for r in self._rows.values():
            r.start_reveal_animation()
            r.show()

        self.setGeometry(QRect(tx, ty, w, h))
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        self._is_animating = True
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(135)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        af.finished.connect(lambda: setattr(self, "_is_animating", False))
        self.anim_in = af
        self.anim_in.start()

    def switch_out_asmr_animation(self, on_finished=None):
        """Quick, silky normal fade-out back to Cursor Menu (no vertical bounce)."""
        self._stop_anims()
        if not self.isVisible():
            if on_finished:
                on_finished()
            return

        gen = self._anim_gen
        self._is_animating = True
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        def _done():
            if getattr(self, "_anim_gen", 0) != gen:
                return
            self._is_animating = False
            self.hide()
            if on_finished:
                on_finished()

        af.finished.connect(_done)
        self.anim_out = af
        self.anim_out.start()

    def open_with_spring_animation(self):
        self._refresh_box_count()
        self._stop_anims()

        cur = QCursor.pos()
        screen = QApplication.screenAt(cur) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        full = screen.geometry()

        w, h = self.width(), self.height()
        target_x = max(avail.left() + 12, min(avail.right() - w - 12, cur.x() - w // 2))
        target_y = max(avail.top() + 14, min(avail.bottom() - h - 14, cur.y() - h // 2))

        target_geom = QRect(target_x, target_y, w, h)
        start_geom = QRect(target_x, full.bottom() + 15, w, h)

        for r in self._rows.values():
            r.start_reveal_animation()
            r.show()

        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        self._is_animating = True
        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(380)
        ag.setStartValue(start_geom)
        ag.setEndValue(target_geom)
        ag.setEasingCurve(QEasingCurve.OutCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(320)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        self.anim_in = QParallelAnimationGroup(self)
        self.anim_in.addAnimation(ag)
        self.anim_in.addAnimation(af)
        self.anim_in.finished.connect(lambda: setattr(self, "_is_animating", False))
        self.anim_in.start()

    def close_with_pull_animation(self, on_finished=None):
        self._stop_anims()
        if not self.isVisible():
            if on_finished:
                on_finished()
            return

        screen = QApplication.screenAt(self.pos()) or QApplication.primaryScreen()
        full = screen.geometry()
        curr = self.geometry()
        end_geom = QRect(curr.x(), full.bottom() + 15, curr.width(), curr.height())

        gen = self._anim_gen
        self._is_animating = True
        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(300)
        ag.setStartValue(curr)
        ag.setEndValue(end_geom)
        ag.setEasingCurve(QEasingCurve.InCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(270)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.InCubic)

        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(ag)
        self.anim_out.addAnimation(af)

        def _done():
            if getattr(self, "_anim_gen", 0) != gen:
                return
            self._is_animating = False
            self.hide()
            if on_finished:
                on_finished()

        self.anim_out.finished.connect(_done)
        self.anim_out.start()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 52.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
            return
        elif e.button() == Qt.RightButton:
            self.close_with_pull_animation()
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close_with_pull_animation()
            e.accept()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        card = QPainterPath()
        card.addRoundedRect(rect, 14.0, 14.0)

        p.fillPath(card, QColor(4, 4, 5, 253))
        p.setPen(QPen(QColor(255, 255, 255, 26), 1.0))
        p.drawPath(card)

        _draw_vector_brand(p, 48.0, 26.0, self.logo_pix, "THE", "SUPER SNAP & PIN", font_pt=10.2)
        p.end()
